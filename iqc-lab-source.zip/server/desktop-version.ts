export const APP_VERSION_INFO = {
  version: "1.0.0",
  releaseDate: "2026-08-13",
  notes: "Cập nhật tính năng báo cáo PDF có biểu đồ, phân quyền RBAC và giao diện Cài đặt phòng xét nghiệm.",
  downloadUrl: "https://github.com/thinhxu/iqc-lab-manager/releases"
};
