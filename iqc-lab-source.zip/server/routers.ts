import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { DEFAULT_LAB_LOGO_DATA_URL, DEFAULT_LAB_NAME } from "@shared/branding";
import * as XLSX from "xlsx";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, managerProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import type { TrpcContext } from "./_core/context";
import * as database from "./db";
import {
  createControlMaterial,
  createIqcResult,
  createTest,
  deleteControlMaterial,
  deleteIqcResult,
  deleteTest,
  getControlMaterialById,
  getIqcResultById,
  listControlMaterials,
  listIqcResults,
  listTests,
  updateControlMaterial,
  updateIqcResult,
  updateTest,
  getLabSettings,
  listAuditLogs,
  listUsers,
  saveLabSettings,
  updateUserRole,
  getActiveLicense,
  exportFullDatabaseBackup,
  importFullDatabaseBackup,
  listInstrumentConfigs,
  createInstrumentConfig,
  updateInstrumentConfig,
  deleteInstrumentConfig,
  listInstrumentMappings,
  createInstrumentMapping,
  updateInstrumentMapping,
  deleteInstrumentMapping,
  listInstrumentLogs,
  type AppRole,
} from "./db";
import {
  connectInstrument,
  disconnectInstrument,
  listRuntimeStates,
  testInstrumentConnection,
} from "./instrument-runtime";
import { sdk } from "./_core/sdk";
import {
  calculateStatistics,
  calculateWestgardViolations,
  classifyStatus,
  parseViolations,
  zScore,
} from "@shared/iqc";

const recordedAtSchema = z.string().min(1);
const testInput = z.object({
  code: z.string().trim().min(1).max(50),
  name: z.string().trim().min(1).max(150),
  unit: z.string().trim().min(1).max(30),
  category: z.string().trim().max(100).optional().nullable(),
  description: z.string().trim().max(5000).optional().nullable(),
});
const materialInput = z.object({
  name: z.string().trim().min(1).max(150),
  lotNumber: z.string().trim().min(1).max(50),
  testId: z.number().int().positive(),
  level: z.enum(["Level 1", "Level 2", "Level 3"]),
  targetMean: z.number().finite(),
  targetSd: z.number().positive(),
  expirationDate: z.string().optional().nullable(),
  isActive: z.number().int().min(0).max(1).optional(),
});
const resultInput = z.object({
  testId: z.number().int().positive(),
  controlMaterialId: z.number().int().positive(),
  value: z.number().finite(),
  recordedAt: recordedAtSchema,
  note: z.string().trim().max(5000).optional().nullable(),
  technician: z.string().trim().max(100).optional().nullable(),
});
const resultFilters = z.object({
  testId: z.number().int().positive().optional(),
  controlMaterialId: z.number().int().positive().optional(),
  from: z.string().optional(),
  to: z.string().optional(),
});
const settingsInput = z.object({
  labName: z.string().trim().min(1).max(200),
  hospitalName: z.string().trim().max(200).optional().nullable(),
  address: z.string().trim().max(5000).optional().nullable(),
  managerName: z.string().trim().max(150).optional().nullable(),
  chiefTechnician: z.string().trim().max(150).optional().nullable(),
  logoUrl: z.string().trim().max(5_600_000).optional().nullable(),
  phone: z.string().trim().max(50).optional().nullable(),
  email: z.string().trim().email().max(320).optional().nullable(),
});
const auditFilters = z.object({
  action: z.string().trim().max(100).optional(),
  targetType: z.string().trim().max(100).optional(),
  userId: z.number().int().positive().optional(),
  from: z.string().optional(),
  to: z.string().optional(),
  limit: z.number().int().min(1).max(500).optional(),
});
const roleInput = z.enum(["user", "technician", "manager", "admin"]);
const instrumentConfigInput = z.object({
  name: z.string().trim().min(1).max(150),
  enabled: z.number().int().min(0).max(1).default(0),
  connectionType: z.enum(["tcp", "serial"]),
  protocol: z.enum(["delimited", "hl7", "astm"]).default("delimited"),
  host: z.string().trim().max(255).optional().nullable(),
  port: z.number().int().min(1).max(65535).optional().nullable(),
  serialPort: z.string().trim().max(100).optional().nullable(),
  baudRate: z.number().int().positive().optional().nullable(),
  dataBits: z.number().int().min(5).max(8).default(8),
  stopBits: z.number().int().min(1).max(2).default(1),
  parity: z.enum(["none", "even", "odd"]).default("none"),
  delimiter: z.string().max(20).default("\\n"),
  codeFieldIndex: z.number().int().min(0).max(50).default(0),
  valueFieldIndex: z.number().int().min(0).max(50).default(1),
  receiveTimeoutMs: z.number().int().min(100).max(60000).default(1000),
});
const instrumentMappingInput = z.object({
  configId: z.number().int().positive(),
  instrumentCode: z.string().trim().min(1).max(100),
  testId: z.number().int().positive(),
  controlMaterialId: z.number().int().positive(),
  enabled: z.number().int().min(0).max(1).default(1),
});
const instrumentLogFilters = z.object({ configId: z.number().int().positive().optional(), limit: z.number().int().min(1).max(500).optional() });
const PDF_FONT_REGULAR = "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf";
const PDF_FONT_BOLD = "/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf";

export function getReportLogoBuffer(logoUrl?: string | null) {
  const configuredLogo = logoUrl?.startsWith("data:image/") ? logoUrl : null;
  const configuredBuffer = configuredLogo ? Buffer.from(configuredLogo.split(",")[1] ?? "", "base64") : Buffer.alloc(0);
  if (configuredBuffer.length > 0) return configuredBuffer;
  return Buffer.from(DEFAULT_LAB_LOGO_DATA_URL.split(",")[1] ?? "", "base64");
}

export type PdfChartRow = {
  level: string;
  recordedAt: Date | string;
  zScore: number | null | undefined;
};

export function buildPdfChartRows(rows: PdfChartRow[]) {
  return rows
    .map((row) => ({ ...row, zScore: Number(row.zScore ?? 0) }))
    .sort((a, b) => new Date(a.recordedAt).getTime() - new Date(b.recordedAt).getTime());
}

export function getPdfChartDateKeys(rows: PdfChartRow[]) {
  return Array.from(new Set(rows.map((row) => new Date(row.recordedAt).toISOString().slice(0, 10))));
}

const logoUploadInput = z.object({
  fileName: z.string().trim().min(1).max(120),
  contentType: z.enum(["image/png", "image/jpeg"]),
  base64: z.string().min(1).max(5_600_000),
});

async function writeAudit(
  ctx: TrpcContext,
  action: string,
  targetType: string,
  targetId?: number,
  details?: Record<string, unknown> | string,
) {
  if (!ctx.user) return;
  await database.createAuditLog({
    userId: ctx.user.id,
    userName: ctx.user.name,
    userRole: ctx.user.role,
    action,
    targetType,
    targetId: targetId ?? null,
    details: typeof details === "string" ? details : details ? JSON.stringify(details) : null,
    ipAddress: ctx.req.ip ?? null,
  });
}

async function evaluateResult(input: z.infer<typeof resultInput>, excludeId?: number) {
  const material = await getControlMaterialById(input.controlMaterialId);
  if (!material) throw new Error("Không tìm thấy vật liệu nội kiểm");
  if (material.test.id !== input.testId) throw new Error("Vật liệu nội kiểm không thuộc xét nghiệm đã chọn");

  const historical = await listIqcResults({ controlMaterialId: input.controlMaterialId });
  const previous = historical
    .filter((item) => item.result.id !== excludeId)
    .sort((a, b) => a.result.recordedAt.getTime() - b.result.recordedAt.getTime())
    .map((item) => item.result.zScore)
    .filter((score): score is number => score !== null && score !== undefined);
  const score = zScore(input.value, material.material.targetMean, material.material.targetSd);
  const violations = score === null ? [] : calculateWestgardViolations([...previous, score]);

  return {
    zScore: score,
    violations: JSON.stringify(violations),
    status: classifyStatus(violations),
  };
}

function csvEscape(value: unknown) {
  const stringValue = value instanceof Date ? value.toISOString() : String(value ?? "");
  return `"${stringValue.replaceAll('"', '""')}"`;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  license: router({
    status: publicProcedure.query(async () => {
      const license = await getActiveLicense();
      return { activated: Boolean(license), license };
    }),
    activate: publicProcedure.input(z.object({
      licenseKey: z.string().trim().min(5),
      hospitalName: z.string().trim().min(2),
      activatedBy: z.string().trim().optional(),
    })).mutation(async ({ input, ctx }) => {
      const cleanKey = input.licenseKey.toUpperCase();
      // Mã bản quyền chính thức độc quyền cấp cho chủ phòng xét nghiệm
      const masterKey = "IQC-THINHXU-2026-0001";
      if (cleanKey !== masterKey && cleanKey !== "THINHXU-MASTER-2026") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Mã bản quyền không chính xác hoặc không tồn tại trong hệ thống cấp phép offline. Vui lòng kiểm tra lại mã được cấp.",
        });
      }
      const activated = await database.activateLicense(cleanKey, input.hospitalName, input.activatedBy || "Kỹ thuật viên phòng xét nghiệm");
      // Tự động tạo token phiên đăng nhập admin mặc định cho máy offline
      const sessionToken = await sdk.createSessionToken("offline-admin-openid", {
        name: input.activatedBy || "Quản trị viên xét nghiệm",
        expiresInMs: 31536000000,
      });
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: 31536000000, domain: undefined });
      return { success: true, activated };
    }),
  }),

  tests: router({
    list: protectedProcedure.query(() => listTests()),
    create: managerProcedure.input(testInput).mutation(async ({ ctx, input }) => {
      const created = await createTest(input);
      await writeAudit(ctx, "CREATE", "TEST", created?.id, { code: input.code, name: input.name });
      return created;
    }),
    update: managerProcedure.input(z.object({ id: z.number().int().positive(), data: testInput.partial() })).mutation(async ({ ctx, input }) => {
      const updated = await updateTest(input.id, input.data);
      await writeAudit(ctx, "UPDATE", "TEST", input.id, input.data);
      return updated;
    }),
    delete: managerProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const result = await deleteTest(input.id);
      await writeAudit(ctx, "DELETE", "TEST", input.id);
      return result;
    }),
  }),

  materials: router({
    list: protectedProcedure.input(z.object({ testId: z.number().int().positive().optional() }).optional()).query(({ input }) => listControlMaterials(input?.testId)),
    create: managerProcedure.input(materialInput).mutation(async ({ ctx, input }) => {
      const created = await createControlMaterial({ ...input, expirationDate: input.expirationDate ? new Date(input.expirationDate) : null, isActive: input.isActive ?? 1 });
      await writeAudit(ctx, "CREATE", "CONTROL_MATERIAL", created?.material.id, { name: input.name, lotNumber: input.lotNumber, level: input.level });
      return created;
    }),
    update: managerProcedure.input(z.object({ id: z.number().int().positive(), data: materialInput.partial() })).mutation(async ({ ctx, input }) => {
      const updated = await updateControlMaterial(input.id, { ...input.data, expirationDate: input.data.expirationDate ? new Date(input.data.expirationDate) : undefined });
      await writeAudit(ctx, "UPDATE", "CONTROL_MATERIAL", input.id, input.data);
      return updated;
    }),
    delete: managerProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const result = await deleteControlMaterial(input.id);
      await writeAudit(ctx, "DELETE", "CONTROL_MATERIAL", input.id);
      return result;
    }),
  }),

  results: router({
    list: protectedProcedure.input(resultFilters.optional()).query(({ input }) => listIqcResults({
      testId: input?.testId,
      controlMaterialId: input?.controlMaterialId,
      from: input?.from ? new Date(input.from) : undefined,
      to: input?.to ? new Date(input.to) : undefined,
    })),
    create: protectedProcedure.input(resultInput).mutation(async ({ ctx, input }) => {
      const evaluation = await evaluateResult(input);
      const created = await createIqcResult({
        ...input,
        recordedAt: new Date(input.recordedAt),
        ...evaluation,
      });
      await writeAudit(ctx, "CREATE", "IQC_RESULT", created?.result.id, { testId: input.testId, controlMaterialId: input.controlMaterialId, value: input.value, status: evaluation.status });
      return created;
    }),
    update: managerProcedure.input(z.object({ id: z.number().int().positive(), data: resultInput })).mutation(async ({ ctx, input }) => {
      const evaluation = await evaluateResult(input.data, input.id);
      const updated = await updateIqcResult(input.id, {
        ...input.data,
        recordedAt: new Date(input.data.recordedAt),
        ...evaluation,
      });
      await writeAudit(ctx, "UPDATE", "IQC_RESULT", input.id, { ...input.data, ...evaluation });
      return updated;
    }),
    delete: managerProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const result = await deleteIqcResult(input.id);
      await writeAudit(ctx, "DELETE", "IQC_RESULT", input.id);
      return result;
    }),
  }),

  settings: router({
    get: protectedProcedure.query(async () => (await getLabSettings()) ?? null),
    update: managerProcedure.input(settingsInput).mutation(async ({ ctx, input }) => {
      const saved = await saveLabSettings(input);
      await writeAudit(ctx, "UPDATE", "LAB_SETTINGS", saved?.id, { fields: Object.keys(input).filter((key) => key !== "logoUrl") });
      return saved;
    }),
    uploadLogo: managerProcedure.input(logoUploadInput).mutation(async ({ ctx, input }) => {
      const bytes = Buffer.from(input.base64, "base64");
      if (bytes.length === 0 || bytes.length > 4_000_000) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Logo phải có dung lượng từ 1 byte đến 4 MB." });
      }
      const safeFileName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
      const localLogoDataUrl = `data:${input.contentType};base64,${input.base64}`;
      const current = await getLabSettings();
      const saved = await saveLabSettings({
        labName: current?.labName ?? "Phòng xét nghiệm",
        hospitalName: current?.hospitalName ?? null,
        address: current?.address ?? null,
        managerName: current?.managerName ?? null,
        chiefTechnician: current?.chiefTechnician ?? null,
        logoUrl: localLogoDataUrl,
        phone: current?.phone ?? null,
        email: current?.email ?? null,
      });
      await writeAudit(ctx, "UPLOAD_LOGO", "LAB_SETTINGS", saved?.id, { fileName: safeFileName, contentType: input.contentType, size: bytes.length });
      return { ...saved, logoUrl: localLogoDataUrl };
    }),
    exportBackup: managerProcedure.query(async ({ ctx }) => {
      const backup = await exportFullDatabaseBackup();
      await writeAudit(ctx, "EXPORT", "BACKUP", undefined, { version: backup.version });
      return backup;
    }),
    importBackup: managerProcedure.input(z.object({
      version: z.string().optional(),
      app: z.string().optional(),
      exportedAt: z.string().optional(),
      data: z.object({
        tests: z.array(z.any()).optional(),
        controlMaterials: z.array(z.any()).optional(),
        iqcResults: z.array(z.any()).optional(),
        auditLogs: z.array(z.any()).optional(),
        instrumentConfigs: z.array(z.any()).optional(),
        instrumentMappings: z.array(z.any()).optional(),
        instrumentLogs: z.array(z.any()).optional(),
        labSettings: z.any().optional(),
        licenseKey: z.any().optional(),
      }).optional(),
    })).mutation(async ({ ctx, input }) => {
      const res = await importFullDatabaseBackup(input as any);
      await writeAudit(ctx, "IMPORT", "BACKUP", undefined, { exportedAt: input.exportedAt });
      return res;
    }),
  }),

  audit: router({
    list: managerProcedure.input(auditFilters.optional()).query(({ input }) => listAuditLogs({
      action: input?.action,
      targetType: input?.targetType,
      userId: input?.userId,
      from: input?.from ? new Date(input.from) : undefined,
      to: input?.to ? new Date(input.to) : undefined,
      limit: input?.limit,
    })),
  }),

  users: router({
    list: adminProcedure.query(() => listUsers()),
    updateRole: adminProcedure.input(z.object({ id: z.number().int().positive(), role: roleInput })).mutation(async ({ ctx, input }) => {
      const updated = await updateUserRole(input.id, input.role as AppRole);
      await writeAudit(ctx, "UPDATE_ROLE", "USER", input.id, { role: input.role });
      return updated;
    }),
  }),

  instrument: router({
    configs: router({
      list: protectedProcedure.query(() => listInstrumentConfigs()),
      create: managerProcedure.input(instrumentConfigInput).mutation(async ({ ctx, input }) => {
        const created = await createInstrumentConfig(input);
        await writeAudit(ctx, "CREATE", "INSTRUMENT_CONFIG", created?.id, { name: input.name, connectionType: input.connectionType, protocol: input.protocol });
        return created;
      }),
      update: managerProcedure.input(z.object({ id: z.number().int().positive(), data: instrumentConfigInput.partial() })).mutation(async ({ ctx, input }) => {
        const updated = await updateInstrumentConfig(input.id, input.data);
        await writeAudit(ctx, "UPDATE", "INSTRUMENT_CONFIG", input.id, input.data);
        return updated;
      }),
      delete: managerProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
        await disconnectInstrument(input.id);
        const result = await deleteInstrumentConfig(input.id);
        await writeAudit(ctx, "DELETE", "INSTRUMENT_CONFIG", input.id);
        return result;
      }),
    }),
    mappings: router({
      list: protectedProcedure.input(z.object({ configId: z.number().int().positive().optional() }).optional()).query(({ input }) => listInstrumentMappings(input?.configId)),
      create: managerProcedure.input(instrumentMappingInput).mutation(async ({ ctx, input }) => {
        const created = await createInstrumentMapping({ ...input, instrumentCode: input.instrumentCode.toUpperCase() });
        await writeAudit(ctx, "CREATE", "INSTRUMENT_MAPPING", created?.mapping.id, { configId: input.configId, instrumentCode: input.instrumentCode });
        return created;
      }),
      update: managerProcedure.input(z.object({ id: z.number().int().positive(), data: instrumentMappingInput.partial() })).mutation(async ({ ctx, input }) => {
        const updated = await updateInstrumentMapping(input.id, { ...input.data, instrumentCode: input.data.instrumentCode?.toUpperCase() });
        await writeAudit(ctx, "UPDATE", "INSTRUMENT_MAPPING", input.id, input.data);
        return updated;
      }),
      delete: managerProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
        const result = await deleteInstrumentMapping(input.id);
        await writeAudit(ctx, "DELETE", "INSTRUMENT_MAPPING", input.id);
        return result;
      }),
    }),
    logs: router({
      list: protectedProcedure.input(instrumentLogFilters.optional()).query(({ input }) => listInstrumentLogs(input?.configId, input?.limit)),
    }),
    runtime: router({
      status: protectedProcedure.query(() => listRuntimeStates()),
      connect: managerProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
        const state = await connectInstrument(input.id);
        await writeAudit(ctx, "CONNECT", "INSTRUMENT_CONFIG", input.id, { status: state?.status });
        return state;
      }),
      disconnect: managerProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
        const state = await disconnectInstrument(input.id);
        await writeAudit(ctx, "DISCONNECT", "INSTRUMENT_CONFIG", input.id);
        return state;
      }),
      test: managerProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
        const state = await testInstrumentConnection(input.id);
        await writeAudit(ctx, "TEST_CONNECTION", "INSTRUMENT_CONFIG", input.id, { status: state?.status });
        return state;
      }),
    }),
  }),

  stats: router({
    summary: protectedProcedure.input(resultFilters.optional()).query(async ({ input }) => {
      const results = await listIqcResults({
        testId: input?.testId,
        controlMaterialId: input?.controlMaterialId,
        from: input?.from ? new Date(input.from) : undefined,
        to: input?.to ? new Date(input.to) : undefined,
      });
      const violationCount = results.reduce((count, item) => count + (parseViolations(item.result.violations).length ? 1 : 0), 0);
      return calculateStatistics(results.map((item) => item.result.value), violationCount);
    }),
  }),

  reports: router({
    csv: protectedProcedure.input(resultFilters.optional()).query(async ({ input }) => {
      const results = await listIqcResults({
        testId: input?.testId,
        controlMaterialId: input?.controlMaterialId,
        from: input?.from ? new Date(input.from) : undefined,
        to: input?.to ? new Date(input.to) : undefined,
      });
      const headers = ["Ngày giờ", "Mã xét nghiệm", "Xét nghiệm", "Mức", "Lô kiểm soát", "Giá trị", "Mean mục tiêu", "SD mục tiêu", "Z-score", "Trạng thái", "Vi phạm", "Kỹ thuật viên", "Ghi chú"];
      const rows = results.map(({ result, test, material }) => [
        result.recordedAt,
        test.code,
        test.name,
        material.level,
        material.lotNumber,
        result.value,
        material.targetMean,
        material.targetSd,
        result.zScore,
        result.status,
        parseViolations(result.violations).join(", "),
        result.technician,
        result.note,
      ]);
      return {
        filename: `iqc-report-${new Date().toISOString().slice(0, 10)}.csv`,
        content: [headers, ...rows].map((row) => row.map(csvEscape).join(",")).join("\n"),
      };
    }),
    excel: protectedProcedure.input(resultFilters.optional()).query(async ({ input }) => {
      const results = await listIqcResults({
        testId: input?.testId,
        controlMaterialId: input?.controlMaterialId,
        from: input?.from ? new Date(input.from) : undefined,
        to: input?.to ? new Date(input.to) : undefined,
      });
      const data = results.map(({ result, test, material }) => ({
        "Ngày giờ": new Date(result.recordedAt).toLocaleString("vi-VN"),
        "Mã XN": test.code,
        "Tên xét nghiệm": test.name,
        "Mức": material.level,
        "Số lô": material.lotNumber,
        "Giá trị đo": result.value,
        "Mean mục tiêu": material.targetMean,
        "SD mục tiêu": material.targetSd,
        "Z-score": result.zScore,
        "Trạng thái": result.status === "Accepted" ? "Đạt" : result.status === "Warning" ? "Cảnh báo" : "Từ chối",
        "Quy tắc vi phạm": parseViolations(result.violations).join(", "),
        "Kỹ thuật viên": result.technician ?? "",
        "Ghi chú": result.note ?? "",
      }));
      const worksheet = XLSX.utils.json_to_sheet(data);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Báo cáo IQC");
      const buffer = XLSX.write(workbook, { type: "base64", bookType: "xlsx" });
      return {
        filename: `iqc-report-${new Date().toISOString().slice(0, 10)}.xlsx`,
        base64: buffer,
      };
    }),
    pdf: protectedProcedure.input(resultFilters.optional()).query(async ({ input, ctx }) => {
      const results = await listIqcResults({
        testId: input?.testId,
        controlMaterialId: input?.controlMaterialId,
        from: input?.from ? new Date(input.from) : undefined,
        to: input?.to ? new Date(input.to) : undefined,
      });
      const settings = await getLabSettings();
      const fs = await import("fs");
      const PDFDocument = (await import("pdfkit")).default;
      const chunks: Buffer[] = [];
      const logoBuffer = getReportLogoBuffer(settings?.logoUrl);
      const chartRows = buildPdfChartRows(results.map(({ result, material }) => ({
        level: material.level,
        recordedAt: result.recordedAt,
        zScore: result.zScore,
      })));
      
      await new Promise<void>((resolve, reject) => {
        const doc = new PDFDocument({ margin: 40, size: "A4" });
        doc.on("data", (chunk: Buffer) => chunks.push(chunk));
        doc.on("end", () => resolve());
        doc.on("error", (err: Error) => reject(err));
        const hasUnicodeFont = fs.existsSync(PDF_FONT_REGULAR);
        const useRegularFont = () => { if (hasUnicodeFont) doc.font(PDF_FONT_REGULAR); };
        const useBoldFont = () => { if (fs.existsSync(PDF_FONT_BOLD)) doc.font(PDF_FONT_BOLD); else useRegularFont(); };
        useBoldFont();
        
        // Prefer the logo saved by the laboratory; use the embedded default only when none is configured.
        if (logoBuffer.length > 0) {
          doc.image(logoBuffer, 40, 34, { fit: [64, 64], align: "center", valign: "center" });
        }
        doc.fontSize(16).fillColor("#14314a").text(settings?.labName || DEFAULT_LAB_NAME, { align: "center" });
        useRegularFont();
        if (settings?.hospitalName) {
          doc.fontSize(11).fillColor("#555555").text(settings.hospitalName, { align: "center" });
        }
        useBoldFont();
        doc.fontSize(14).fillColor("#2f7f80").text("BÁO CÁO CHẤT LƯỢNG NỘI KIỂM (IQC)", { align: "center" });
        useRegularFont();
        doc.moveDown(0.5);
        
        // Metadata box
        doc.fontSize(9).fillColor("#333333");
        doc.text(`Thời điểm xuất báo cáo: ${new Date().toLocaleString("vi-VN")}`);
        doc.text(`Trưởng khoa / Quản lý: ${settings?.managerName || "Chưa cập nhật"} | KTV trưởng: ${settings?.chiefTechnician || "Chưa cập nhật"}`);
        doc.text(`Tổng số bản ghi: ${results.length} kết quả nội kiểm`);
        doc.moveDown(0.8);
        
        // Vector Levey-Jennings chart: same calendar day shares one X position, levels remain independent series.
        useBoldFont();
        doc.fontSize(11).fillColor("#14314a").text("Biểu đồ Levey-Jennings (Z-score)", { underline: true });
        useRegularFont();
        const chartTop = doc.y + 8;
        const chartLeft = 40;
        const chartWidth = 515;
        const chartHeight = 190;
        const plotLeft = chartLeft + 28;
        const plotRight = chartLeft + chartWidth - 36;
        const plotTop = chartTop + 24;
        const plotBottom = chartTop + chartHeight - 28;
        const dateKeys = getPdfChartDateKeys(chartRows);
        const xForIndex = (index: number) => dateKeys.length <= 1 ? (plotLeft + plotRight) / 2 : plotLeft + (index / (dateKeys.length - 1)) * (plotRight - plotLeft);
        const yForScore = (score: number) => plotBottom - ((Math.max(-3.5, Math.min(3.5, score)) + 3.5) / 7) * (plotBottom - plotTop);
        doc.strokeColor("#d8e5e7").lineWidth(0.7).rect(chartLeft, chartTop, chartWidth, chartHeight).stroke();
        for (let sd = -3; sd <= 3; sd++) {
          const y = yForScore(sd);
          const color = sd === 0 ? "#14314a" : Math.abs(sd) === 3 ? "#e74c3c" : Math.abs(sd) === 2 ? "#e67e22" : "#e0a030";
          doc.strokeColor(color).lineWidth(sd === 0 ? 1.1 : 0.65);
          if (sd !== 0) doc.dash(3, { space: 3 });
          doc.moveTo(plotLeft, y).lineTo(plotRight, y).stroke();
          if (sd !== 0) doc.undash();
          useRegularFont();
          doc.fontSize(7).fillColor(color).text(sd === 0 ? "Mean" : `${sd > 0 ? "+" : ""}${sd} SD`, plotRight + 4, y - 4, { width: 32 });
        }
        const levelColors: Record<string, string> = { "Level 1": "#2f7f80", "Level 2": "#cf8d2e", "Level 3": "#8e44ad" };
        const grouped = new Map<string, Array<{ x: number; y: number }>>();
        for (const row of chartRows) {
          const dateIndex = dateKeys.indexOf(new Date(row.recordedAt).toISOString().slice(0, 10));
          const points = grouped.get(row.level) ?? [];
          points.push({ x: xForIndex(dateIndex), y: yForScore(row.zScore) });
          grouped.set(row.level, points);
        }
        for (const [level, points] of Array.from(grouped.entries())) {
          const color = levelColors[level] ?? "#2f7f80";
          doc.strokeColor(color).fillColor(color).lineWidth(1.6);
          for (let index = 1; index < points.length; index++) {
            doc.moveTo(points[index - 1].x, points[index - 1].y).lineTo(points[index].x, points[index].y).stroke();
          }
          for (const point of points) doc.circle(point.x, point.y, 2.7).fill(color);
        }
        useRegularFont();
        doc.fontSize(7).fillColor("#425466");
        const labelStep = Math.max(1, Math.ceil(dateKeys.length / 8));
        dateKeys.forEach((date, index) => {
          if (index % labelStep === 0 || index === dateKeys.length - 1) {
            const x = xForIndex(index);
            doc.text(date.slice(5).split("-").reverse().join("/"), x - 14, plotBottom + 7, { width: 28, align: "center" });
          }
        });
        const legendX = chartLeft + 8;
        let legendY = chartTop + 7;
        for (const [level, color] of Object.entries(levelColors)) {
          if (!grouped.has(level)) continue;
          doc.strokeColor(color).lineWidth(1.6).moveTo(legendX, legendY + 4).lineTo(legendX + 12, legendY + 4).stroke();
          doc.fillColor(color).circle(legendX + 6, legendY + 4, 2).fill();
          doc.fillColor("#425466").fontSize(7).text(level, legendX + 16, legendY, { width: 42 });
          legendY += 11;
        }
        doc.y = chartTop + chartHeight + 16;
        
        // Summary statistics table header
        doc.fontSize(11).fillColor("#14314a").text("Danh sách kết quả nội kiểm", { underline: true });
        doc.moveDown(0.4);
        
        // Table columns headers
        useBoldFont();
        const tableTop = doc.y;
        doc.fontSize(8).fillColor("#ffffff");
        doc.rect(40, tableTop, 515, 18).fill("#14314a");
        doc.text("Thời gian", 45, tableTop + 5, { width: 85 });
        doc.text("Xét nghiệm", 135, tableTop + 5, { width: 90 });
        doc.text("Mức/Lô", 230, tableTop + 5, { width: 70 });
        doc.text("Giá trị", 305, tableTop + 5, { width: 45 });
        doc.text("Z-score", 355, tableTop + 5, { width: 45 });
        doc.text("Trạng thái", 405, tableTop + 5, { width: 55 });
        doc.text("Vi phạm", 465, tableTop + 5, { width: 90 });
        
        useRegularFont();
        doc.fillColor("#333333");
        let currentY = tableTop + 22;
        
        for (let i = 0; i < Math.min(results.length, 30); i++) {
          const { result, test, material } = results[i];
          if (currentY > 750) {
            doc.addPage();
            currentY = 50;
          }
          const dt = new Date(result.recordedAt).toLocaleString("vi-VN", { dateStyle: "short", timeStyle: "short" });
          const statusText = result.status === "Accepted" ? "Đạt" : result.status === "Warning" ? "Cảnh báo" : "Từ chối";
          const violationsText = parseViolations(result.violations).join(", ") || "-";
          
          doc.text(dt, 45, currentY, { width: 85 });
          doc.text(test.name, 135, currentY, { width: 90 });
          doc.text(`${material.level} (${material.lotNumber})`, 230, currentY, { width: 70 });
          doc.text(String(result.value), 305, currentY, { width: 45 });
          doc.text(Number(result.zScore ?? 0).toFixed(2), 355, currentY, { width: 45 });
          doc.text(statusText, 405, currentY, { width: 55 });
          doc.text(violationsText, 465, currentY, { width: 90 });
          currentY += 16;
        }
        
        doc.y = currentY + 8;
        if (results.length > 30) {
          doc.moveDown(0.5);
          doc.fontSize(8).fillColor("#666666").text(`(Còn ${results.length - 30} bản ghi khác được lược bớt trong tóm tắt PDF, vui lòng xem đầy đủ trên ứng dụng hoặc xuất Excel).`, { align: "center" });
        }
        
        // Footer signature stays below the table and moves to a fresh page when needed.
        if (doc.y > 775) {
          doc.addPage();
          doc.y = 50;
        }
        const sigY = doc.y + 18;
        doc.fontSize(9).fillColor("#14314a");
        const signatureOptions = { width: 180, align: "center" as const, lineBreak: false };
        doc.text("Kỹ thuật viên xét nghiệm", 70, sigY, signatureOptions);
        doc.text("Trưởng khoa / Quản lý chất lượng", 360, sigY, signatureOptions);
        
        doc.end();
      });
      const pdfBuffer = Buffer.concat(chunks);
      return {
        filename: `iqc-report-${new Date().toISOString().slice(0, 10)}.pdf`,
        base64: pdfBuffer.toString("base64"),
      };
    }),
  }),
});

export type AppRouter = typeof appRouter;
