import { describe, expect, it } from "vitest";
import { parseInstrumentMessage } from "./instrument-parser";

describe("instrument protocol parser", () => {
  it("parses a delimited result using configured fields", () => {
    const frames = parseInstrumentMessage("GLU|105.4|mg/dL\n", { protocol: "delimited", delimiter: "\\n", codeFieldIndex: 0, valueFieldIndex: 1 });
    expect(frames).toHaveLength(1);
    expect(frames[0].results[0]).toMatchObject({ instrumentCode: "GLU", value: 105.4, unit: "mg/dL" });
  });

  it("parses HL7 OBX numeric results from an MLLP frame", () => {
    const message = "\u000bMSH|^~\\&|ANALYZER|LAB|LIS|LAB|20261001120000||ORU^R01|MSG-1|P|2.3\rOBX|1|NM|GLU^Glucose||105.4|mg/dL||||F\r\u001c\r";
    const frames = parseInstrumentMessage(message, { protocol: "hl7" });
    expect(frames[0]).toMatchObject({ protocol: "hl7", messageId: "MSG-1" });
    expect(frames[0].results[0]).toMatchObject({ instrumentCode: "GLU", value: 105.4, unit: "mg/dL" });
  });

  it("parses ASTM R records and normalizes the analyte code", () => {
    const message = "\u0002H|\\^&|||ANALYZER|||||P\rO|1|SAMPLE-1||20261001120000||||||||||||\rR|1|^^^GLU|105.4|mg/dL||||F\r\u0003\r\n";
    const frames = parseInstrumentMessage(message, { protocol: "astm" });
    expect(frames[0]).toMatchObject({ protocol: "astm" });
    expect(frames[0].results[0]).toMatchObject({ instrumentCode: "GLU", value: 105.4, sampleId: "SAMPLE-1" });
  });
});
