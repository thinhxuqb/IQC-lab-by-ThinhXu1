CREATE TABLE `control_materials` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(150) NOT NULL,
	`lotNumber` varchar(50) NOT NULL,
	`testId` int NOT NULL,
	`level` enum('Level 1','Level 2','Level 3') NOT NULL,
	`targetMean` float NOT NULL,
	`targetSd` float NOT NULL,
	`expirationDate` date,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `control_materials_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `iqc_results` (
	`id` int AUTO_INCREMENT NOT NULL,
	`testId` int NOT NULL,
	`controlMaterialId` int NOT NULL,
	`value` float NOT NULL,
	`recordedAt` timestamp NOT NULL,
	`zScore` float,
	`violations` text,
	`status` enum('Accepted','Rejected','Warning') NOT NULL DEFAULT 'Accepted',
	`note` text,
	`technician` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `iqc_results_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(50) NOT NULL,
	`name` varchar(150) NOT NULL,
	`unit` varchar(30) NOT NULL,
	`category` varchar(100),
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tests_id` PRIMARY KEY(`id`),
	CONSTRAINT `tests_code_unique` UNIQUE(`code`)
);
