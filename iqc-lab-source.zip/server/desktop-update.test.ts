import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const packageJson = JSON.parse(readFileSync("package.json", "utf8")) as {
  main: string;
  version: string;
  build: {
    publish: { provider: string; owner: string; repo: string };
    files: string[];
  };
};
const workflow = readFileSync(".github/workflows/build-win.yml", "utf8");

describe("Electron auto-update release configuration", () => {
  it("uses the CommonJS main process and packages the preload bridge", () => {
    expect(packageJson.main).toBe("electron.cjs");
    expect(packageJson.build.files).toContain("preload.cjs");
  });

  it("targets the IQC Lab GitHub repository for update releases", () => {
    expect(packageJson.build.publish.provider).toBe("github");
    expect(packageJson.build.publish.owner).toBe("thinhxuqb");
    expect(packageJson.build.publish.repo).toBe("IQC-lab-by-ThinhXu1");
  });

  it("publishes tagged builds and verifies updater metadata", () => {
    expect(workflow).toContain("tags: ['v*']");
    expect(workflow).toContain("--publish always");
    expect(workflow).toContain("release/latest*.yml");
    expect(workflow).toContain("Expected latest.yml metadata");
  });
});
