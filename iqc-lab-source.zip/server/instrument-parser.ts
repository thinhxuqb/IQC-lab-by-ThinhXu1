import {
  decodeDelimiter,
  normalizeInstrumentCode,
  type InstrumentProtocol,
  type ParsedInstrumentFrame,
  type ParsedInstrumentResult,
} from "@shared/instrument";

function parseDate(value: string | undefined) {
  const clean = String(value ?? "").trim();
  if (!clean) return null;
  const compact = clean.match(/^(\d{4})(\d{2})(\d{2})(\d{2})?(\d{2})?(\d{2})?/);
  if (compact) {
    const [, year, month, day, hour = "00", minute = "00", second = "00"] = compact;
    const result = new Date(`${year}-${month}-${day}T${hour}:${minute}:${second}`);
    if (!Number.isNaN(result.getTime())) return result;
  }
  const result = new Date(clean);
  return Number.isNaN(result.getTime()) ? null : result;
}

function numericValue(value: unknown) {
  const parsed = Number.parseFloat(String(value ?? "").replace(",", ".").trim());
  return Number.isFinite(parsed) ? parsed : null;
}

function splitFrames(raw: string, protocol: InstrumentProtocol, delimiter: string) {
  const normalized = raw.replaceAll("\u0000", "");
  if (protocol === "hl7") {
    const mllpFrames = normalized.split("\u001c").map((frame) => frame.replace(/^\u000b/, "").replace(/^\r+|\r+$/g, "").trim()).filter(Boolean);
    return mllpFrames.length ? mllpFrames : [normalized.replace(/^\u000b|\u001c\r?$/g, "").trim()];
  }
  if (protocol === "astm") {
    return normalized
      .split(/\u0003(?:\r?\n?|\r)/)
      .map((frame) => frame.replace(/[\u0002\u0004\u0005\u0006\u0017]/g, "").trim())
      .filter(Boolean);
  }
  return normalized.split(decodeDelimiter(delimiter)).map((frame) => frame.trim()).filter(Boolean);
}

function parseDelimitedFrame(frame: string, codeFieldIndex: number, valueFieldIndex: number): ParsedInstrumentResult[] {
  const separator = frame.includes("\t") ? "\t" : frame.includes(";") ? ";" : frame.includes("|") ? "|" : ",";
  const fields = frame.split(separator).map((field) => field.trim());
  const keyValues = new Map(fields.map((field) => {
    const index = field.indexOf("=");
    return index > 0 ? [field.slice(0, index).trim().toLowerCase(), field.slice(index + 1).trim()] as const : ["", ""] as const;
  }).filter(([key]) => Boolean(key)));
  const code = keyValues.get("code") || keyValues.get("test") || keyValues.get("analyte") || fields[codeFieldIndex];
  const value = keyValues.get("value") || keyValues.get("result") || fields[valueFieldIndex];
  const parsed = numericValue(value);
  if (!code || parsed === null) return [];
  return [{
    instrumentCode: normalizeInstrumentCode(code),
    value: parsed,
    unit: keyValues.get("unit") || fields[valueFieldIndex + 1] || null,
    measuredAt: parseDate(keyValues.get("time") || keyValues.get("datetime")),
    sampleId: keyValues.get("sample") || keyValues.get("sampleid") || null,
    messageId: keyValues.get("id") || null,
  }];
}

function parseHl7Frame(frame: string): ParsedInstrumentFrame {
  const segments = frame.split(/\r?\n|\r/).filter(Boolean).map((segment) => segment.split("|"));
  const header = segments.find((fields) => fields[0] === "MSH");
  const messageId = segments.find((fields) => fields[0] === "MSH")?.[9] || null;
  const measuredAt = parseDate(header?.[6]);
  const sampleId = segments.find((fields) => fields[0] === "OBR")?.[3] || segments.find((fields) => fields[0] === "SPM")?.[2] || null;
  const results = segments.filter((fields) => fields[0] === "OBX").flatMap((fields) => {
    const identifier = fields[3] || fields[2] || "";
    const instrumentCode = normalizeInstrumentCode(identifier.split("^")[0] || identifier.split("^").filter(Boolean).at(-1));
    const value = numericValue(fields[5]);
    if (!instrumentCode || value === null) return [];
    return [{ instrumentCode, value, unit: fields[6] || null, measuredAt, sampleId, messageId }];
  });
  return { protocol: "hl7", messageId, results };
}

function parseAstmFrame(frame: string): ParsedInstrumentFrame {
  const records = frame.split(/\r?\n|\r/).filter(Boolean).map((segment) => segment.split("|"));
  const header = records.find((fields) => fields[0].endsWith("H"));
  const messageId = header?.[1] || null;
  const measuredAt = parseDate(records.find((fields) => fields[0].endsWith("O"))?.[7]);
  const sampleId = records.find((fields) => fields[0].endsWith("O"))?.[2] || null;
  const results = records.filter((fields) => fields[0].endsWith("R")).flatMap((fields) => {
    const identifier = fields[2] || fields[3] || "";
    const instrumentCode = normalizeInstrumentCode(identifier.split("^").filter(Boolean).at(-1) || identifier);
    const value = numericValue(fields[3] || fields[4]);
    if (!instrumentCode || value === null) return [];
    return [{ instrumentCode, value, unit: fields[4] || fields[5] || null, measuredAt, sampleId, messageId }];
  });
  return { protocol: "astm", messageId, results };
}

export function parseInstrumentMessage(
  raw: string,
  options: { protocol: InstrumentProtocol; delimiter?: string; codeFieldIndex?: number; valueFieldIndex?: number },
): ParsedInstrumentFrame[] {
  const frames = splitFrames(raw, options.protocol, options.delimiter || "\\n");
  if (options.protocol === "hl7") return frames.map(parseHl7Frame);
  if (options.protocol === "astm") return frames.map(parseAstmFrame);
  return frames.map((frame) => ({
    protocol: "delimited",
    messageId: null,
    results: parseDelimitedFrame(frame, options.codeFieldIndex ?? 0, options.valueFieldIndex ?? 1),
  }));
}
