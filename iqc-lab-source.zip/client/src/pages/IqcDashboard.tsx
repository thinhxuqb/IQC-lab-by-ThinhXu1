import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  BarChart3,
  CalendarDays,
  Check,
  ChevronDown,
  ClipboardCheck,
  Download,
  Edit3,
  FileSpreadsheet,
  FileText,
  Filter,
  FlaskConical,
  Gauge,
  History,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Trash2,
  TrendingUp,
  Upload,
  XCircle,
} from "lucide-react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { calculateStatistics, formatNumber, formatRuleLabel, parseViolations, toLocalDateTimeInput, WESTGARD_RULE_DESCRIPTIONS, type WestgardRule } from "@shared/iqc";
import SettingsPage from "@/pages/SettingsPage";
import AuditTrailPage from "@/pages/AuditTrailPage";

const ruleColors: Record<string, string> = {
  "1-2s": "bg-amber-50 text-amber-700 border-amber-200",
  "1-3s": "bg-rose-50 text-rose-700 border-rose-200",
  "2-2s": "bg-rose-50 text-rose-700 border-rose-200",
  "R-4s": "bg-rose-50 text-rose-700 border-rose-200",
  "4-1s": "bg-rose-50 text-rose-700 border-rose-200",
  "10x": "bg-rose-50 text-rose-700 border-rose-200",
};

type TestRow = {
  id: number;
  code: string;
  name: string;
  unit: string;
  category: string | null;
  description: string | null;
};
type MaterialRow = {
  material: {
    id: number;
    name: string;
    lotNumber: string;
    testId: number;
    level: "Level 1" | "Level 2" | "Level 3";
    targetMean: number;
    targetSd: number;
    expirationDate: Date | null;
    isActive: number;
  };
  test: TestRow;
};
type ResultRow = {
  result: {
    id: number;
    testId: number;
    controlMaterialId: number;
    value: number;
    recordedAt: Date;
    zScore: number | null;
    violations: string | null;
    status: "Accepted" | "Rejected" | "Warning";
    note: string | null;
    technician: string | null;
  };
  test: TestRow;
  material: MaterialRow["material"];
};

function dateLabel(date: Date | string | null | undefined) {
  if (!date) return "—";
  return new Date(date).toLocaleString("vi-VN", { dateStyle: "medium", timeStyle: "short" });
}

function dayLabel(date: Date | string) {
  return new Date(date).toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit" });
}

function StatusBadge({ status }: { status: ResultRow["result"]["status"] }) {
  const config = {
    Accepted: { label: "Đạt", className: "bg-emerald-50 text-emerald-700 border-emerald-200", icon: Check },
    Warning: { label: "Cảnh báo", className: "bg-amber-50 text-amber-700 border-amber-200", icon: AlertTriangle },
    Rejected: { label: "Không đạt", className: "bg-rose-50 text-rose-700 border-rose-200", icon: XCircle },
  }[status];
  const Icon = config.icon;
  return <Badge variant="outline" className={`gap-1.5 font-medium ${config.className}`}><Icon className="h-3.5 w-3.5" />{config.label}</Badge>;
}

function RuleBadges({ violations }: { violations: string | null }) {
  const rules = parseViolations(violations);
  if (!rules.length) return <span className="text-muted-foreground">Không có</span>;
  return <div className="flex flex-wrap gap-1">{rules.map((rule) => <Badge key={rule} variant="outline" className={`px-1.5 py-0 text-[10px] ${ruleColors[rule] ?? ""}`} title={WESTGARD_RULE_DESCRIPTIONS[rule as WestgardRule]}>{formatRuleLabel(rule)}</Badge>)}</div>;
}

function PageHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: React.ReactNode }) {
  return <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
    <div>
      <div className="mb-2 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary/80"><span className="h-1.5 w-1.5 rounded-full bg-primary" />{eyebrow}</div>
      <h1 className="text-3xl font-semibold tracking-[-0.03em] text-[#14314a] md:text-4xl">{title}</h1>
      <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">{description}</p>
    </div>
    {action}
  </div>;
}

function EmptyState({ icon: Icon, title, description, action }: { icon: typeof FlaskConical; title: string; description: string; action?: React.ReactNode }) {
  return <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-[#cddfe2] bg-[#fbfdfd] px-6 py-16 text-center"><div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#e9f5f3] text-primary"><Icon className="h-6 w-6" /></div><h3 className="text-base font-semibold text-[#18364b]">{title}</h3><p className="mt-2 max-w-md text-sm leading-6 text-muted-foreground">{description}</p>{action ? <div className="mt-5">{action}</div> : null}</div>;
}

function IqcShell({ children }: { children: React.ReactNode }) {
  return <DashboardLayout><div className="min-h-[calc(100vh-2rem)] bg-[#f5f9f9] px-1 py-1 sm:px-3 lg:px-6">{children}</div></DashboardLayout>;
}

function useIqcData() {
  const auth = trpc.auth.me.useQuery();
  const enabled = Boolean(auth.data);
  const testsQuery = trpc.tests.list.useQuery(undefined, { enabled });
  const materialsQuery = trpc.materials.list.useQuery(undefined, { enabled });
  const resultsQuery = trpc.results.list.useQuery(undefined, { enabled });
  const statsQuery = trpc.stats.summary.useQuery(undefined, { enabled });
  const utils = trpc.useUtils();
  return {
    auth,
    enabled,
    tests: (testsQuery.data ?? []) as TestRow[],
    materials: (materialsQuery.data ?? []) as MaterialRow[],
    results: (resultsQuery.data ?? []) as ResultRow[],
    stats: statsQuery.data,
    isLoading: testsQuery.isLoading || materialsQuery.isLoading || resultsQuery.isLoading,
    refresh: async () => {
      await Promise.all([utils.tests.list.invalidate(), utils.materials.list.invalidate(), utils.results.list.invalidate(), utils.stats.summary.invalidate()]);
    },
  };
}

function StatCard({ label, value, detail, icon: Icon, accent }: { label: string; value: string | number; detail: string; icon: typeof Activity; accent: string }) {
  return <Card className="overflow-hidden border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardContent className="relative p-5"><div className={`absolute right-0 top-0 h-20 w-20 -translate-y-5 translate-x-5 rounded-full opacity-60 ${accent}`} /><div className="relative flex items-start justify-between"><div><p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">{label}</p><p className="mt-3 text-3xl font-semibold tracking-[-0.04em] text-[#14314a]">{value}</p><p className="mt-1 text-xs text-muted-foreground">{detail}</p></div><div className="rounded-xl bg-[#eef7f6] p-2.5 text-primary"><Icon className="h-5 w-5" /></div></div></CardContent></Card>;
}

function DashboardHome({ data }: { data: ReturnType<typeof useIqcData> }) {
  const recent = data.results.slice(0, 5);
  const stats = data.stats;
  return <IqcShell><div className="mx-auto max-w-[1440px] space-y-7 py-4">
    <PageHeading eyebrow="Quality intelligence · 01" title="Tổng quan nội kiểm" description="Theo dõi tín hiệu chất lượng, độ ổn định của hệ thống và các điểm cần xử lý trong ngày hôm nay." action={<Button className="h-10 gap-2 rounded-xl bg-[#14314a] px-4 shadow-lg shadow-[#14314a]/15 hover:bg-[#214a67]"><Plus className="h-4 w-4" />Ghi nhận kết quả</Button>} />
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><StatCard label="Xét nghiệm" value={data.tests.length} detail="Đang được theo dõi" icon={FlaskConical} accent="bg-[#bde8df]" /><StatCard label="Vật liệu kiểm soát" value={data.materials.length} detail="Theo lô & mức kiểm chứng" icon={ShieldCheck} accent="bg-[#dce9f4]" /><StatCard label="Điểm dữ liệu" value={stats?.count ?? data.results.length} detail="Trong toàn bộ lịch sử" icon={Activity} accent="bg-[#f7e5b8]" /><StatCard label="Điểm vi phạm" value={stats?.violationCount ?? 0} detail="Cần xem xét / xử lý" icon={AlertTriangle} accent="bg-[#f4d0d0]" /></div>
    <div className="grid gap-5 xl:grid-cols-[1.45fr_0.8fr]">
      <Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="flex flex-row items-start justify-between space-y-0 border-b border-[#edf3f3] pb-4"><div><CardTitle className="text-base text-[#14314a]">Hoạt động nội kiểm gần đây</CardTitle><p className="mt-1 text-xs text-muted-foreground">Các kết quả mới nhất được ghi nhận trong hệ thống</p></div><Button variant="ghost" className="gap-1 text-xs text-primary" onClick={() => window.location.assign("/history")}>Xem lịch sử <ArrowUpRight className="h-3.5 w-3.5" /></Button></CardHeader><CardContent className="p-0">{recent.length ? <Table><TableHeader><TableRow className="hover:bg-transparent"><TableHead className="pl-6">Xét nghiệm</TableHead><TableHead>Mức / lô</TableHead><TableHead>Thời gian</TableHead><TableHead>Trạng thái</TableHead><TableHead className="pr-6 text-right">Giá trị</TableHead></TableRow></TableHeader><TableBody>{recent.map((row) => <TableRow key={row.result.id}><TableCell className="pl-6"><div className="font-medium text-[#18364b]">{row.test.name}</div><div className="text-xs text-muted-foreground">{row.test.code} · {row.test.unit}</div></TableCell><TableCell><div className="text-sm">{row.material.level}</div><div className="text-xs text-muted-foreground">Lot {row.material.lotNumber}</div></TableCell><TableCell className="text-xs text-muted-foreground">{dateLabel(row.result.recordedAt)}</TableCell><TableCell><StatusBadge status={row.result.status} /></TableCell><TableCell className="pr-6 text-right font-mono text-sm">{formatNumber(row.result.value)}</TableCell></TableRow>)}</TableBody></Table> : <div className="p-6"><EmptyState icon={ClipboardCheck} title="Chưa có kết quả nội kiểm" description="Bắt đầu ghi nhận kết quả đầu tiên để theo dõi chất lượng và tạo biểu đồ Levey–Jennings." action={<Button onClick={() => window.location.assign("/results")} className="gap-2 rounded-xl"><Plus className="h-4 w-4" />Nhập kết quả đầu tiên</Button>} /></div>}</CardContent></Card>
      <Card className="border-0 bg-[#14314a] text-white shadow-[0_10px_30px_rgba(20,49,74,0.16)]"><CardHeader><div className="flex items-center justify-between"><CardTitle className="text-base font-medium">Sức khỏe hệ thống</CardTitle><span className="flex items-center gap-1.5 text-xs text-[#bde8df]"><span className="h-2 w-2 rounded-full bg-[#72d4bf]" />Đang hoạt động</span></div></CardHeader><CardContent className="space-y-5"><div className="rounded-2xl border border-white/10 bg-white/5 p-4"><div className="flex items-center gap-3"><div className="rounded-xl bg-white/10 p-2"><Gauge className="h-5 w-5 text-[#bde8df]" /></div><div><p className="text-xs text-white/55">Mức độ sẵn sàng</p><p className="mt-1 text-2xl font-semibold">{data.results.length ? "Theo dõi" : "Chờ dữ liệu"}</p></div></div><div className="mt-4 h-1.5 overflow-hidden rounded-full bg-white/10"><div className="h-full w-[78%] rounded-full bg-[#72d4bf]" /></div><p className="mt-2 text-[11px] text-white/45">Theo dõi liên tục theo cấu hình kiểm soát</p></div><div className="grid grid-cols-2 gap-3"><div className="rounded-2xl border border-white/10 p-3"><p className="text-xs text-white/50">Mean thực tế</p><p className="mt-1 text-lg font-semibold">{formatNumber(stats?.mean)}</p></div><div className="rounded-2xl border border-white/10 p-3"><p className="text-xs text-white/50">CV%</p><p className="mt-1 text-lg font-semibold">{stats?.cv === null || stats?.cv === undefined ? "—" : `${stats.cv.toFixed(2)}%`}</p></div></div><Button variant="outline" className="w-full rounded-xl border-white/15 bg-transparent text-white hover:bg-white/10 hover:text-white" onClick={() => window.location.assign("/analytics")}>Mở phân tích chất lượng <ArrowUpRight className="ml-2 h-4 w-4" /></Button></CardContent></Card>
    </div>
  </div></IqcShell>;
}

function TestDialog({ edit, onDone }: { edit?: TestRow; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ code: edit?.code ?? "", name: edit?.name ?? "", unit: edit?.unit ?? "", category: edit?.category ?? "", description: edit?.description ?? "" });
  const createMutation = trpc.tests.create.useMutation();
  const updateMutation = trpc.tests.update.useMutation();
  const mutationPending = createMutation.isPending || updateMutation.isPending;
  const utils = trpc.useUtils();
  const submit = async () => {
    try {
      if (edit) await updateMutation.mutateAsync({ id: edit.id, data: form });
      else await createMutation.mutateAsync(form);
      toast.success(edit ? "Đã cập nhật xét nghiệm" : "Đã thêm xét nghiệm");
      await utils.tests.list.invalidate(); setOpen(false); onDone();
    } catch (error) { toast.error(error instanceof Error ? error.message : "Không thể lưu xét nghiệm"); }
  };
  return <Dialog open={open} onOpenChange={setOpen}><DialogTrigger asChild>{edit ? <Button variant="ghost" size="icon" className="h-8 w-8"><Edit3 className="h-4 w-4" /></Button> : <Button className="h-10 gap-2 rounded-xl bg-[#14314a] px-4 hover:bg-[#214a67]"><Plus className="h-4 w-4" />Thêm xét nghiệm</Button>}</DialogTrigger><DialogContent className="sm:max-w-[540px]"><DialogHeader><DialogTitle>{edit ? "Chỉnh sửa xét nghiệm" : "Khai báo xét nghiệm mới"}</DialogTitle><DialogDescription>Thiết lập thông tin nhận diện và đơn vị đo của xét nghiệm.</DialogDescription></DialogHeader><div className="grid gap-4 py-3 sm:grid-cols-2"><Field label="Mã xét nghiệm" value={form.code} onChange={(value) => setForm({ ...form, code: value })} placeholder="VD: GLU" /><Field label="Tên xét nghiệm" value={form.name} onChange={(value) => setForm({ ...form, name: value })} placeholder="VD: Glucose máu" /><Field label="Đơn vị đo" value={form.unit} onChange={(value) => setForm({ ...form, unit: value })} placeholder="VD: mmol/L" /><Field label="Nhóm xét nghiệm" value={form.category} onChange={(value) => setForm({ ...form, category: value })} placeholder="VD: Sinh hóa" /><div className="sm:col-span-2"><Label>Mô tả</Label><Textarea className="mt-2 min-h-24" value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} placeholder="Ghi chú tùy chọn về phương pháp, máy xét nghiệm..." /></div></div><DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Hủy</Button><Button onClick={submit} disabled={mutationPending}>{mutationPending ? "Đang lưu..." : "Lưu thông tin"}</Button></DialogFooter></DialogContent></Dialog>;
}

function Field({ label, value, onChange, placeholder, type = "text" }: { label: string; value: string | number; onChange: (value: string) => void; placeholder?: string; type?: string }) {
  return <div><Label>{label}</Label><Input type={type} className="mt-2" value={value} placeholder={placeholder} onChange={(event) => onChange(event.target.value)} /></div>;
}

function TestsPage({ data }: { data: ReturnType<typeof useIqcData> }) {
  const canManage = data.auth.data?.role === "manager" || data.auth.data?.role === "admin";
  const deleteMutation = trpc.tests.delete.useMutation();
  const [search, setSearch] = useState("");
  const filtered = data.tests.filter((test) => `${test.code} ${test.name} ${test.category ?? ""}`.toLowerCase().includes(search.toLowerCase()));
  const remove = async (id: number) => { if (!window.confirm("Xóa xét nghiệm này? Các dữ liệu liên quan có thể không còn hiển thị đúng.")) return; try { await deleteMutation.mutateAsync({ id }); await data.refresh(); toast.success("Đã xóa xét nghiệm"); } catch (error) { toast.error(error instanceof Error ? error.message : "Không thể xóa xét nghiệm"); } };
  return <IqcShell><div className="mx-auto max-w-[1440px] space-y-7 py-4"><PageHeading eyebrow="Master data · 02" title="Danh mục xét nghiệm" description="Chuẩn hóa mã, tên, đơn vị và nhóm xét nghiệm để mọi kết quả nội kiểm được truy vết nhất quán." action={canManage ? <TestDialog onDone={() => data.refresh()} /> : <Badge variant="outline" className="w-fit border-[#dcebea] bg-white text-muted-foreground">Chỉ xem</Badge>} /><Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="flex flex-col gap-4 border-b border-[#edf3f3] pb-5 md:flex-row md:items-center md:justify-between"><div><CardTitle className="text-base text-[#14314a]">Danh sách xét nghiệm</CardTitle><p className="mt-1 text-xs text-muted-foreground">{data.tests.length} xét nghiệm đang được cấu hình</p></div><div className="relative w-full md:w-72"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Tìm theo mã hoặc tên..." className="h-9 rounded-xl border-[#dce9e9] pl-9" /></div></CardHeader><CardContent className="p-0">{filtered.length ? <Table><TableHeader><TableRow><TableHead className="pl-6">Mã</TableHead><TableHead>Tên xét nghiệm</TableHead><TableHead>Đơn vị</TableHead><TableHead>Nhóm</TableHead><TableHead className="pr-6 text-right">Thao tác</TableHead></TableRow></TableHeader><TableBody>{filtered.map((test) => <TableRow key={test.id}><TableCell className="pl-6 font-mono text-xs font-semibold text-primary">{test.code}</TableCell><TableCell><div className="font-medium text-[#18364b]">{test.name}</div><div className="max-w-sm truncate text-xs text-muted-foreground">{test.description || "Chưa có mô tả"}</div></TableCell><TableCell>{test.unit}</TableCell><TableCell><Badge variant="outline" className="border-[#d9e9e9] bg-[#f8fbfb] font-normal">{test.category || "Chưa phân nhóm"}</Badge></TableCell><TableCell className="pr-6 text-right">{canManage ? <div className="flex justify-end gap-1"><TestDialog edit={test} onDone={() => data.refresh()} /><Button variant="ghost" size="icon" className="h-8 w-8 text-rose-600 hover:bg-rose-50 hover:text-rose-700" onClick={() => remove(test.id)}><Trash2 className="h-4 w-4" /></Button></div> : <span className="text-xs text-muted-foreground">Chỉ xem</span>}</TableCell></TableRow>)}</TableBody></Table> : <div className="p-6"><EmptyState icon={FlaskConical} title="Chưa có xét nghiệm" description="Khai báo xét nghiệm đầu tiên để bắt đầu thiết lập các mức kiểm chứng mục tiêu." action={canManage ? <TestDialog onDone={() => data.refresh()} /> : <Badge variant="outline" className="w-fit border-[#dcebea] bg-white text-muted-foreground">Chỉ xem</Badge>} /></div>}</CardContent></Card></div></IqcShell>;
}

function MaterialDialog({ tests, edit, onDone }: { tests: TestRow[]; edit?: MaterialRow; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: edit?.material.name ?? "", lotNumber: edit?.material.lotNumber ?? "", testId: String(edit?.material.testId ?? tests[0]?.id ?? ""), level: edit?.material.level ?? "Level 1" as "Level 1" | "Level 2" | "Level 3", targetMean: String(edit?.material.targetMean ?? ""), targetSd: String(edit?.material.targetSd ?? ""), expirationDate: edit?.material.expirationDate ? new Date(edit.material.expirationDate).toISOString().slice(0, 10) : "" });
  const createMutation = trpc.materials.create.useMutation();
  const updateMutation = trpc.materials.update.useMutation();
  const mutationPending = createMutation.isPending || updateMutation.isPending;
  const utils = trpc.useUtils();
  const submit = async () => {     try { const payload = { name: form.name, lotNumber: form.lotNumber, testId: Number(form.testId), level: form.level, targetMean: Number(form.targetMean), targetSd: Number(form.targetSd), expirationDate: form.expirationDate || null }; if (edit) await updateMutation.mutateAsync({ id: edit.material.id, data: payload }); else await createMutation.mutateAsync(payload); toast.success(edit ? "Đã cập nhật vật liệu" : "Đã thêm vật liệu kiểm soát"); await utils.materials.list.invalidate(); setOpen(false); onDone(); } catch (error) { toast.error(error instanceof Error ? error.message : "Không thể lưu vật liệu"); } };
  return <Dialog open={open} onOpenChange={setOpen}><DialogTrigger asChild>{edit ? <Button variant="ghost" size="icon" className="h-8 w-8"><Edit3 className="h-4 w-4" /></Button> : <Button className="h-10 gap-2 rounded-xl bg-[#14314a] px-4 hover:bg-[#214a67]"><Plus className="h-4 w-4" />Thêm vật liệu</Button>}</DialogTrigger><DialogContent className="sm:max-w-[600px]"><DialogHeader><DialogTitle>{edit ? "Chỉnh sửa vật liệu kiểm soát" : "Khai báo vật liệu kiểm soát"}</DialogTitle><DialogDescription>Gắn lô kiểm soát với xét nghiệm và nhập Mean/SD mục tiêu.</DialogDescription></DialogHeader><div className="grid gap-4 py-3 sm:grid-cols-2"><Field label="Tên vật liệu" value={form.name} onChange={(value) => setForm({ ...form, name: value })} placeholder="VD: Chemistry Control" /><Field label="Số lô" value={form.lotNumber} onChange={(value) => setForm({ ...form, lotNumber: value })} placeholder="VD: 12345" /><div><Label>Xét nghiệm</Label><Select value={form.testId} onValueChange={(value) => setForm({ ...form, testId: value })}><SelectTrigger className="mt-2"><SelectValue placeholder="Chọn xét nghiệm" /></SelectTrigger><SelectContent>{tests.map((test) => <SelectItem key={test.id} value={String(test.id)}>{test.code} · {test.name}</SelectItem>)}</SelectContent></Select></div><div><Label>Mức kiểm chứng</Label><Select value={form.level} onValueChange={(value: "Level 1" | "Level 2" | "Level 3") => setForm({ ...form, level: value })}><SelectTrigger className="mt-2"><SelectValue /></SelectTrigger><SelectContent>{["Level 1", "Level 2", "Level 3"].map((level) => <SelectItem key={level} value={level}>{level}</SelectItem>)}</SelectContent></Select></div><Field label="Mean mục tiêu" value={form.targetMean} onChange={(value) => setForm({ ...form, targetMean: value })} placeholder="0.00" type="number" /><Field label="SD mục tiêu" value={form.targetSd} onChange={(value) => setForm({ ...form, targetSd: value })} placeholder="0.00" type="number" /><Field label="Hạn sử dụng" value={form.expirationDate} onChange={(value) => setForm({ ...form, expirationDate: value })} type="date" /></div><DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Hủy</Button><Button onClick={submit} disabled={mutationPending || !tests.length}>{mutationPending ? "Đang lưu..." : "Lưu vật liệu"}</Button></DialogFooter></DialogContent></Dialog>;
}

function MaterialsPage({ data }: { data: ReturnType<typeof useIqcData> }) {
  const canManage = data.auth.data?.role === "manager" || data.auth.data?.role === "admin";
  const deleteMutation = trpc.materials.delete.useMutation();
  const remove = async (id: number) => { if (!window.confirm("Xóa vật liệu kiểm soát này?")) return; try { await deleteMutation.mutateAsync({ id }); await data.refresh(); toast.success("Đã xóa vật liệu"); } catch (error) { toast.error(error instanceof Error ? error.message : "Không thể xóa vật liệu"); } };
  return <IqcShell><div className="mx-auto max-w-[1440px] space-y-7 py-4"><PageHeading eyebrow="Control materials · 03" title="Vật liệu kiểm soát" description="Quản lý lô, hạn sử dụng và các giá trị mục tiêu cho từng mức kiểm chứng của mỗi xét nghiệm." action={canManage ? <MaterialDialog tests={data.tests} onDone={() => data.refresh()} /> : <Badge variant="outline" className="w-fit border-[#dcebea] bg-white text-muted-foreground">Chỉ xem</Badge>} /><div className="grid gap-4 sm:grid-cols-3"><StatCard label="Tổng vật liệu" value={data.materials.length} detail="Theo xét nghiệm & mức" icon={ShieldCheck} accent="bg-[#bde8df]" /><StatCard label="Level 1" value={data.materials.filter((row) => row.material.level === "Level 1").length} detail="Mức nồng độ thấp" icon={SlidersHorizontal} accent="bg-[#dce9f4]" /><StatCard label="Đang hoạt động" value={data.materials.filter((row) => row.material.isActive === 1).length} detail="Sẵn sàng ghi nhận" icon={Check} accent="bg-[#f7e5b8]" /></div><Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardContent className="p-0">{data.materials.length ? <Table><TableHeader><TableRow><TableHead className="pl-6">Vật liệu / lô</TableHead><TableHead>Xét nghiệm</TableHead><TableHead>Mức</TableHead><TableHead>Mean / SD</TableHead><TableHead>Hạn sử dụng</TableHead><TableHead className="pr-6 text-right">Thao tác</TableHead></TableRow></TableHeader><TableBody>{data.materials.map((row) => <TableRow key={row.material.id}><TableCell className="pl-6"><div className="font-medium text-[#18364b]">{row.material.name}</div><div className="text-xs text-muted-foreground">Lot {row.material.lotNumber}</div></TableCell><TableCell><div className="text-sm">{row.test.name}</div><div className="text-xs text-muted-foreground">{row.test.code} · {row.test.unit}</div></TableCell><TableCell><Badge variant="outline" className="border-[#d9e9e9] bg-[#f8fbfb] font-normal">{row.material.level}</Badge></TableCell><TableCell className="font-mono text-xs">{formatNumber(row.material.targetMean)} <span className="text-muted-foreground">/</span> {formatNumber(row.material.targetSd)}</TableCell><TableCell className="text-sm text-muted-foreground">{row.material.expirationDate ? new Date(row.material.expirationDate).toLocaleDateString("vi-VN") : "—"}</TableCell><TableCell className="pr-6 text-right">{canManage ? <div className="flex justify-end gap-1"><MaterialDialog tests={data.tests} edit={row} onDone={() => data.refresh()} /><Button variant="ghost" size="icon" className="h-8 w-8 text-rose-600 hover:bg-rose-50 hover:text-rose-700" onClick={() => remove(row.material.id)}><Trash2 className="h-4 w-4" /></Button></div> : <span className="text-xs text-muted-foreground">Chỉ xem</span>}</TableCell></TableRow>)}</TableBody></Table> : <div className="p-6"><EmptyState icon={ShieldCheck} title="Chưa có vật liệu kiểm soát" description="Thêm lô kiểm soát và gán vào một xét nghiệm cụ thể để bắt đầu theo dõi." action={canManage ? <MaterialDialog tests={data.tests} onDone={() => data.refresh()} /> : <Badge variant="outline" className="w-fit border-[#dcebea] bg-white text-muted-foreground">Chỉ xem</Badge>} /></div>}</CardContent></Card></div></IqcShell>;
}

function ResultEntryForm({ data, onDone }: { data: ReturnType<typeof useIqcData>; onDone: () => void }) {
  const [form, setForm] = useState({ testId: String(data.tests[0]?.id ?? ""), controlMaterialId: "", value: "", recordedAt: toLocalDateTimeInput(), note: "", technician: "" });
  const materials = data.materials.filter((row) => row.material.testId === Number(form.testId));
  const mutation = trpc.results.create.useMutation();
  const selectedMaterial = data.materials.find((row) => row.material.id === Number(form.controlMaterialId));
  const [errors, setErrors] = useState<{ testId?: string; controlMaterialId?: string; value?: string }>({});

  const submit = async () => {
    const newErrors: { testId?: string; controlMaterialId?: string; value?: string } = {};
    if (!form.testId) newErrors.testId = "Vui lòng chọn xét nghiệm.";
    if (!form.controlMaterialId) newErrors.controlMaterialId = "Vui lòng chọn vật liệu kiểm soát.";
    if (form.value === "" || isNaN(Number(form.value))) newErrors.value = "Vui lòng nhập giá trị số hợp lệ.";
    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;

    try {
      await mutation.mutateAsync({
        testId: Number(form.testId),
        controlMaterialId: Number(form.controlMaterialId),
        value: Number(form.value),
        recordedAt: new Date(form.recordedAt).toISOString(),
        note: form.note || null,
        technician: form.technician || null,
      });
      toast.success("Đã ghi nhận kết quả nội kiểm");
      setForm({ ...form, value: "", note: "", recordedAt: toLocalDateTimeInput() });
      setErrors({});
      await onDone();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Không thể ghi nhận kết quả");
    }
  };
  return <Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="border-b border-[#edf3f3] pb-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#e9f5f3] p-2.5 text-primary"><ClipboardCheck className="h-5 w-5" /></div><div><CardTitle className="text-base text-[#14314a]">Ghi nhận kết quả mới</CardTitle><p className="mt-1 text-xs text-muted-foreground">Hệ thống tự động đánh giá Z-score và quy tắc Westgard sau khi lưu.</p></div></div></CardHeader><CardContent className="space-y-5 p-5"><div className="grid gap-4 md:grid-cols-2"><div><Label>Xét nghiệm</Label><Select value={form.testId} onValueChange={(value) => setForm({ ...form, testId: value, controlMaterialId: "" })}><SelectTrigger className="mt-2 h-11"><SelectValue placeholder="Chọn xét nghiệm" /></SelectTrigger><SelectContent>{data.tests.map((test) => <SelectItem key={test.id} value={String(test.id)}>{test.code} · {test.name}</SelectItem>)}</SelectContent></Select>{errors.testId && <p className="mt-1 text-xs text-rose-500">{errors.testId}</p>}</div><div><Label>Mức / vật liệu kiểm soát</Label><Select value={form.controlMaterialId} onValueChange={(value) => setForm({ ...form, controlMaterialId: value })}><SelectTrigger className="mt-2 h-11"><SelectValue placeholder="Chọn mức kiểm chứng" /></SelectTrigger><SelectContent>{materials.map((row) => <SelectItem key={row.material.id} value={String(row.material.id)}>{row.material.level} · Lot {row.material.lotNumber}</SelectItem>)}</SelectContent></Select>{errors.controlMaterialId && <p className="mt-1 text-xs text-rose-500">{errors.controlMaterialId}</p>}</div><div><Field label={`Giá trị đo được${selectedMaterial ? ` · mục tiêu ${formatNumber(selectedMaterial.material.targetMean)} ${data.tests.find((t) => t.id === selectedMaterial.material.testId)?.unit ?? ""}` : ""}`} value={form.value} onChange={(value) => setForm({ ...form, value })} placeholder="Nhập kết quả" type="number" />{errors.value && <p className="mt-1 text-xs text-rose-500">{errors.value}</p>}</div><div><Label>Ngày giờ thực hiện</Label><Input type="datetime-local" className="mt-2 h-11" value={form.recordedAt} onChange={(event) => setForm({ ...form, recordedAt: event.target.value })} /></div><Field label="Kỹ thuật viên" value={form.technician} onChange={(value) => setForm({ ...form, technician: value })} placeholder="Tên người thực hiện" /></div><div><Label>Ghi chú / hành động khắc phục</Label><Textarea className="mt-2 min-h-24" value={form.note} onChange={(event) => setForm({ ...form, note: event.target.value })} placeholder="Ghi nhận tình trạng máy, thuốc thử hoặc hành động xử lý nếu cần..." /></div><div className="flex flex-col gap-3 rounded-2xl border border-[#dcebea] bg-[#f7fbfb] p-4 text-sm sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-3"><div className="rounded-full bg-white p-2 text-primary shadow-sm"><Activity className="h-4 w-4" /></div><div><p className="font-medium text-[#18364b]">Tự động kiểm tra Westgard</p><p className="text-xs text-muted-foreground">1-2s · 1-3s · 2-2s · R-4s · 4-1s · 10x</p></div></div><Button onClick={submit} disabled={mutation.isPending || !form.testId || !form.controlMaterialId || !form.value} className="h-10 rounded-xl bg-[#14314a] px-5 hover:bg-[#214a67]">{mutation.isPending ? "Đang phân tích..." : "Lưu & phân tích"}</Button></div></CardContent></Card>;
}

function EditResultDialog({ row, onDone }: { row: ResultRow; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ value: String(row.result.value), recordedAt: toLocalDateTimeInput(new Date(row.result.recordedAt)), technician: row.result.technician ?? "", note: row.result.note ?? "" });
  const mutation = trpc.results.update.useMutation();
  const submit = async () => {
    try {
      await mutation.mutateAsync({
        id: row.result.id,
        data: {
          testId: row.test.id,
          controlMaterialId: row.material.id,
          value: Number(form.value),
          recordedAt: new Date(form.recordedAt).toISOString(),
          technician: form.technician || null,
          note: form.note || null,
        },
      });
      toast.success("Đã cập nhật kết quả nội kiểm");
      setOpen(false);
      onDone();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Không thể cập nhật kết quả");
    }
  };
  return <Dialog open={open} onOpenChange={setOpen}><DialogTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8 text-primary hover:bg-[#eef7f6]"><Edit3 className="h-4 w-4" /></Button></DialogTrigger><DialogContent className="sm:max-w-[500px]"><DialogHeader><DialogTitle>Chỉnh sửa kết quả nội kiểm</DialogTitle><DialogDescription>Cập nhật giá trị đo, thời gian hoặc ghi chú cho lần chạy này.</DialogDescription></DialogHeader><div className="grid gap-4 py-3"><Field label="Giá trị đo được" value={form.value} onChange={(value) => setForm({ ...form, value })} type="number" /><Field label="Thời gian thực hiện" value={form.recordedAt} onChange={(value) => setForm({ ...form, recordedAt: value })} type="datetime-local" /><Field label="Kỹ thuật viên" value={form.technician} onChange={(value) => setForm({ ...form, technician: value })} /><div className="space-y-2"><Label>Ghi chú</Label><Textarea value={form.note} onChange={(event) => setForm({ ...form, note: event.target.value })} className="min-h-20" /></div></div><DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Hủy</Button><Button onClick={submit} disabled={mutation.isPending}>{mutation.isPending ? "Đang lưu..." : "Lưu thay đổi"}</Button></DialogFooter></DialogContent></Dialog>;
}

function ResultsTable({ rows, onRefresh, canManage }: { rows: ResultRow[]; onRefresh: () => void; canManage: boolean }) {
  const deleteMutation = trpc.results.delete.useMutation();
  const remove = async (id: number) => { if (!window.confirm("Xóa kết quả này khỏi lịch sử?")) return; try { await deleteMutation.mutateAsync({ id }); await onRefresh(); toast.success("Đã xóa kết quả"); } catch (error) { toast.error(error instanceof Error ? error.message : "Không thể xóa kết quả"); } };
  return rows.length ? <div className="overflow-x-auto"><Table><TableHeader><TableRow><TableHead className="pl-6">Thời gian</TableHead><TableHead>Xét nghiệm</TableHead><TableHead>Mức / lô</TableHead><TableHead>Giá trị</TableHead><TableHead>Trạng thái</TableHead><TableHead>Vi phạm</TableHead><TableHead className="pr-6 text-right">Thao tác</TableHead></TableRow></TableHeader><TableBody>{rows.map((row) => <TableRow key={row.result.id}><TableCell className="whitespace-nowrap pl-6 text-xs text-muted-foreground">{dateLabel(row.result.recordedAt)}</TableCell><TableCell><div className="font-medium text-[#18364b]">{row.test.name}</div><div className="text-xs text-muted-foreground">{row.test.code}</div></TableCell><TableCell><div className="text-sm">{row.material.level}</div><div className="text-xs text-muted-foreground">Lot {row.material.lotNumber}</div></TableCell><TableCell className="font-mono text-sm">{formatNumber(row.result.value)} <span className="text-[10px] text-muted-foreground">z {formatNumber(row.result.zScore)}</span></TableCell><TableCell><StatusBadge status={row.result.status} /></TableCell><TableCell><RuleBadges violations={row.result.violations} /></TableCell><TableCell className="pr-6 text-right">{canManage ? <div className="flex justify-end gap-1"><EditResultDialog row={row} onDone={onRefresh} /><Button variant="ghost" size="icon" className="h-8 w-8 text-rose-600 hover:bg-rose-50 hover:text-rose-700" onClick={() => remove(row.result.id)}><Trash2 className="h-4 w-4" /></Button></div> : <span className="text-xs text-muted-foreground">Chỉ xem</span>}</TableCell></TableRow>)}</TableBody></Table></div> : <EmptyState icon={Activity} title="Chưa có dữ liệu phù hợp" description="Kết quả nội kiểm sẽ xuất hiện tại đây sau khi bạn ghi nhận hoặc điều chỉnh bộ lọc." />;
}

function ResultsPage({ data }: { data: ReturnType<typeof useIqcData> }) {
  const canManage = data.auth.data?.role === "manager" || data.auth.data?.role === "admin";
  return <IqcShell><div className="mx-auto max-w-[1440px] space-y-7 py-4"><PageHeading eyebrow="Daily operation · 04" title="Nhập kết quả nội kiểm" description="Ghi nhận kết quả hằng ngày với đánh giá tự động theo mục tiêu Mean/SD và các quy tắc Westgard." /><ResultEntryForm data={data} onDone={data.refresh} /><Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="flex flex-row items-center justify-between border-b border-[#edf3f3] pb-5"><div><CardTitle className="text-base text-[#14314a]">Kết quả gần đây</CardTitle><p className="mt-1 text-xs text-muted-foreground">Hiển thị 20 kết quả mới nhất</p></div><Button variant="outline" className="h-9 gap-2 rounded-xl" onClick={data.refresh}><RefreshCw className="h-3.5 w-3.5" />Làm mới</Button></CardHeader><CardContent className="p-0"><ResultsTable rows={data.results.slice(0, 20)} onRefresh={data.refresh} canManage={canManage} /></CardContent></Card></div></IqcShell>;
}

function FilterBar({ data, testId, setTestId, materialId, setMaterialId, from, setFrom, to, setTo }: { data: ReturnType<typeof useIqcData>; testId: string; setTestId: (value: string) => void; materialId: string; setMaterialId: (value: string) => void; from: string; setFrom: (value: string) => void; to: string; setTo: (value: string) => void }) {
  const materials = data.materials.filter((row) => !testId || testId === "all" || row.material.testId === Number(testId));
  return <div className="grid gap-3 rounded-2xl border border-[#dcebea] bg-[#f8fbfb] p-4 md:grid-cols-2 xl:grid-cols-5"><div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.12em] text-primary xl:col-span-1"><Filter className="h-4 w-4" />Bộ lọc dữ liệu</div><Select value={testId} onValueChange={(value) => { setTestId(value); setMaterialId("all"); }}><SelectTrigger className="h-10 bg-white"><SelectValue placeholder="Tất cả xét nghiệm" /></SelectTrigger><SelectContent><SelectItem value="all">Tất cả xét nghiệm</SelectItem>{data.tests.map((test) => <SelectItem key={test.id} value={String(test.id)}>{test.code} · {test.name}</SelectItem>)}</SelectContent></Select><Select value={materialId} onValueChange={setMaterialId}><SelectTrigger className="h-10 bg-white"><SelectValue placeholder="Tất cả mức / lô" /></SelectTrigger><SelectContent><SelectItem value="all">Tất cả mức / lô</SelectItem>{materials.map((row) => <SelectItem key={row.material.id} value={String(row.material.id)}>{row.material.level} · Lot {row.material.lotNumber}</SelectItem>)}</SelectContent></Select><Input type="date" value={from} onChange={(event) => setFrom(event.target.value)} className="h-10 bg-white" /><Input type="date" value={to} onChange={(event) => setTo(event.target.value)} className="h-10 bg-white" /></div>;
}

function AnalyticsPage({ data }: { data: ReturnType<typeof useIqcData> }) {
  const [testId, setTestId] = useState("all");
  const [materialId, setMaterialId] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const filter = useMemo(() => ({ testId: testId === "all" ? undefined : Number(testId), controlMaterialId: materialId === "all" ? undefined : Number(materialId), from: from ? new Date(`${from}T00:00:00`).toISOString() : undefined, to: to ? new Date(`${to}T23:59:59`).toISOString() : undefined }), [testId, materialId, from, to]);
  const query = trpc.results.list.useQuery(filter, { enabled: data.enabled });
  const rows = (query.data ?? []) as ResultRow[];
  const selectedMaterial = materialId === "all" ? undefined : data.materials.find((row) => row.material.id === Number(materialId))?.material;
  const levelColors: Record<ResultRow["material"]["level"], string> = { "Level 1": "#2f7f80", "Level 2": "#cf8d2e", "Level 3": "#c15368" };
  const levelOrder: Record<ResultRow["material"]["level"], number> = { "Level 1": 1, "Level 2": 2, "Level 3": 3 };
  const series = useMemo(() => {
    const groups = new Map<ResultRow["material"]["level"], ResultRow[]>();
    rows.forEach((row) => {
      const existing = groups.get(row.material.level) ?? [];
      existing.push(row);
      groups.set(row.material.level, existing);
    });
    return Array.from(groups.entries()).sort(([left], [right]) => levelOrder[left] - levelOrder[right]).map(([level, group]) => {
      const material = group[0].material;
      return {
        key: `level_${level.toLowerCase().replaceAll(" ", "_")}`,
        label: level,
        color: levelColors[level],
        material,
      };
    });
  }, [rows]);
  const chartData = useMemo(() => {
    type ChartPoint = {
      label: string;
      sortKey: string;
      meta: Record<string, { result: ResultRow["result"]; material: ResultRow["material"] }>;
      [key: string]: unknown;
    };

    const points = new Map<string, ChartPoint>();
    [...rows]
      .sort((a, b) => new Date(a.result.recordedAt).getTime() - new Date(b.result.recordedAt).getTime())
      .forEach((row) => {
        const recordedAt = new Date(row.result.recordedAt);
        const dateKey = `${recordedAt.getFullYear()}-${String(recordedAt.getMonth() + 1).padStart(2, "0")}-${String(recordedAt.getDate()).padStart(2, "0")}`;
        const levelKey = `level_${row.material.level.toLowerCase().replaceAll(" ", "_")}`;
        const point = points.get(dateKey) ?? {
          label: dayLabel(row.result.recordedAt),
          sortKey: dateKey,
          meta: {},
        };
        point[levelKey] = row.material.targetSd > 0
          ? (row.result.value - row.material.targetMean) / row.material.targetSd
          : null;
        point.meta[levelKey] = { result: row.result, material: row.material };
        points.set(dateKey, point);
      });

    return Array.from(points.values()).sort((a, b) => a.sortKey.localeCompare(b.sortKey));
  }, [rows]);
  const localStats = calculateStatistics(rows.map((row) => row.result.value), rows.filter((row) => parseViolations(row.result.violations).length).length);
  const chartLimit = Math.max(
    3.5,
    ...chartData.flatMap((point) => series.map((item) => Math.abs(Number(point[item.key]) || 0) + 0.5)),
  );
  return (
    <IqcShell>
      <div className="mx-auto max-w-[1440px] space-y-7 py-4">
        <PageHeading eyebrow="Quality analytics · 05" title="Biểu đồ & thống kê" description="Phân tích độ ổn định theo thời gian trên biểu đồ Levey–Jennings với các dải Mean và SD mục tiêu." />
        <FilterBar data={data} testId={testId} setTestId={setTestId} materialId={materialId} setMaterialId={setMaterialId} from={from} setFrom={setFrom} to={to} setTo={setTo} />
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard label="Mean thực tế" value={formatNumber(localStats.mean)} detail="Từ dữ liệu đang lọc" icon={TrendingUp} accent="bg-[#bde8df]" />
          <StatCard label="SD thực tế" value={formatNumber(localStats.sd)} detail="Độ phân tán mẫu" icon={BarChart3} accent="bg-[#dce9f4]" />
          <StatCard label="CV%" value={localStats.cv === null ? "—" : `${localStats.cv.toFixed(2)}%`} detail="Hệ số biến thiên" icon={Activity} accent="bg-[#f7e5b8]" />
          <StatCard label="Vi phạm" value={localStats.violationCount} detail="Theo bộ lọc hiện tại" icon={AlertTriangle} accent="bg-[#f4d0d0]" />
        </div>
        <Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]">
          <CardHeader className="flex flex-col gap-3 border-b border-[#edf3f3] pb-5 md:flex-row md:items-center md:justify-between">
            <div>
              <CardTitle className="text-base text-[#14314a]">Levey–Jennings chuẩn hóa · {selectedMaterial ? `${selectedMaterial.level} / Lot ${selectedMaterial.lotNumber}` : series.length ? "Tất cả mức / lô" : "Chưa có dữ liệu"}</CardTitle>
              <p className="mt-1 text-xs text-muted-foreground">Trục tung chuẩn hóa theo SD: Mean tại 0, các dải ±1SD, ±2SD, ±3SD. Các điểm QC cùng ngày nằm trên một vị trí X; mỗi mức chỉ nối với chính mức đó.</p>
            </div>
            <div className="flex flex-wrap gap-2 text-[11px]">
              {series.map((item) => <Badge key={item.key} variant="outline" className="gap-1.5 border-[#dce6ec] bg-white"><span className="h-2 w-2 rounded-full" style={{ backgroundColor: item.color }} />{item.label}</Badge>)}
            </div>
          </CardHeader>
          <CardContent className="p-5">
            {chartData.length && series.length ? <div className="h-[390px] w-full"><ResponsiveContainer width="100%" height="100%"><LineChart data={chartData} margin={{ top: 10, right: 18, left: 8, bottom: 5 }}><CartesianGrid stroke="#e6efef" vertical={false} />              <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#75909c" }} tickLine={false} axisLine={false} interval="preserveStartEnd" /><YAxis tick={{ fontSize: 11, fill: "#58707d" }} tickLine={false} axisLine={false} width={58} domain={[-chartLimit, chartLimit]} ticks={[-3, -2, -1, 0, 1, 2, 3]} tickFormatter={(value) => value === 0 ? "Mean" : `${value > 0 ? "+" : ""}${value}SD`} /><Tooltip contentStyle={{ borderRadius: 14, border: "1px solid #dcebea", boxShadow: "0 12px 30px rgba(20,49,74,.12)", fontSize: 12 }} formatter={(value, name) => [typeof value === "number" ? `${value >= 0 ? "+" : ""}${value.toFixed(2)} SD` : value, String(name)]} labelFormatter={(label) => `Ngày ${label}`} /><ReferenceLine y={0} stroke="#2a9d8f" strokeWidth={2} label={{ value: "Mean", position: "insideTopRight", fill: "#2a9d8f", fontSize: 11 }} /><ReferenceLine y={1} stroke="#8cbeb8" strokeDasharray="4 4" /><ReferenceLine y={-1} stroke="#8cbeb8" strokeDasharray="4 4" /><ReferenceLine y={2} stroke="#e9a23b" strokeDasharray="5 5" /><ReferenceLine y={-2} stroke="#e9a23b" strokeDasharray="5 5" /><ReferenceLine y={3} stroke="#d95d5d" strokeDasharray="5 5" /><ReferenceLine y={-3} stroke="#d95d5d" strokeDasharray="5 5" />{series.map((item) => <Line key={item.key} type="linear" dataKey={item.key} name={item.label} stroke={item.color} strokeWidth={2.5} connectNulls dot={(props) => { const payload = (props as { payload?: { meta?: Record<string, { result?: { status?: string } }> } }).payload; const status = payload?.meta?.[item.key]?.result?.status; const color = status === "Rejected" ? "#d95d5d" : status === "Warning" ? "#e9a23b" : item.color; return <circle cx={(props as { cx?: number }).cx} cy={(props as { cy?: number }).cy} r={5} fill={color} stroke="white" strokeWidth={2} />; }} />)}</LineChart></ResponsiveContainer></div> : <EmptyState icon={BarChart3} title="Chưa đủ dữ liệu để vẽ biểu đồ" description="Chọn xét nghiệm và vật liệu có kết quả đã ghi nhận. Mỗi mức QC sẽ được chuẩn hóa theo Mean/SD riêng trước khi vẽ." />}
          </CardContent>
        </Card>
      </div>
    </IqcShell>
  );
}

function HistoryPage({ data }: { data: ReturnType<typeof useIqcData> }) {
  const canManage = data.auth.data?.role === "manager" || data.auth.data?.role === "admin";
  const [testId, setTestId] = useState("all"); const [materialId, setMaterialId] = useState("all"); const [from, setFrom] = useState(""); const [to, setTo] = useState("");
  const filter = useMemo(() => ({ testId: testId === "all" ? undefined : Number(testId), controlMaterialId: materialId === "all" ? undefined : Number(materialId), from: from ? new Date(`${from}T00:00:00`).toISOString() : undefined, to: to ? new Date(`${to}T23:59:59`).toISOString() : undefined }), [testId, materialId, from, to]);
  const query = trpc.results.list.useQuery(filter, { enabled: data.enabled });
  const rows = (query.data ?? []) as ResultRow[];
  return <IqcShell><div className="mx-auto max-w-[1440px] space-y-7 py-4"><PageHeading eyebrow="Traceability · 06" title="Lịch sử kết quả" description="Tra cứu, lọc và truy vết toàn bộ kết quả nội kiểm theo xét nghiệm, lô kiểm soát và khoảng thời gian." /><FilterBar data={data} testId={testId} setTestId={setTestId} materialId={materialId} setMaterialId={setMaterialId} from={from} setFrom={setFrom} to={to} setTo={setTo} /><Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="flex flex-row items-center justify-between border-b border-[#edf3f3] pb-5"><div><CardTitle className="text-base text-[#14314a]">Bảng lịch sử</CardTitle><p className="mt-1 text-xs text-muted-foreground">{rows.length} kết quả phù hợp với bộ lọc</p></div><div className="flex items-center gap-2 text-xs text-muted-foreground"><CalendarDays className="h-4 w-4" />Lưu trữ có truy vết</div></CardHeader><CardContent className="p-0"><ResultsTable rows={rows} onRefresh={data.refresh} canManage={canManage} /></CardContent></Card></div></IqcShell>;
}

function ReportsPage({ data }: { data: ReturnType<typeof useIqcData> }) {
  const [testId, setTestId] = useState("all"); const [materialId, setMaterialId] = useState("all"); const [from, setFrom] = useState(""); const [to, setTo] = useState("");

  const applyPreset = (preset: "thisMonth" | "lastMonth" | "thisQuarter" | "all") => {
    const now = new Date();
    if (preset === "all") {
      setFrom("");
      setTo("");
    } else if (preset === "thisMonth") {
      const start = new Date(now.getFullYear(), now.getMonth(), 1);
      const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      setFrom(start.toISOString().slice(0, 10));
      setTo(end.toISOString().slice(0, 10));
    } else if (preset === "lastMonth") {
      const start = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const end = new Date(now.getFullYear(), now.getMonth(), 0);
      setFrom(start.toISOString().slice(0, 10));
      setTo(end.toISOString().slice(0, 10));
    } else if (preset === "thisQuarter") {
      const quarterStartMonth = Math.floor(now.getMonth() / 3) * 3;
      const start = new Date(now.getFullYear(), quarterStartMonth, 1);
      const end = new Date(now.getFullYear(), quarterStartMonth + 3, 0);
      setFrom(start.toISOString().slice(0, 10));
      setTo(end.toISOString().slice(0, 10));
    }
  };

  const filter = useMemo(() => ({ testId: testId === "all" ? undefined : Number(testId), controlMaterialId: materialId === "all" ? undefined : Number(materialId), from: from ? new Date(`${from}T00:00:00`).toISOString() : undefined, to: to ? new Date(`${to}T23:59:59`).toISOString() : undefined }), [testId, materialId, from, to]);
  const csvReport = trpc.reports.csv.useQuery(filter, { enabled: false });
  const excelReport = trpc.reports.excel.useQuery(filter, { enabled: false });
  const pdfReport = trpc.reports.pdf.useQuery(filter, { enabled: false });

  const downloadCsv = async () => { try { const result = await csvReport.refetch(); if (!result.data) return; const blob = new Blob([`\ufeff${result.data.content}`], { type: "text/csv;charset=utf-8" }); const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = result.data.filename; link.click(); URL.revokeObjectURL(url); toast.success("Đã xuất báo cáo CSV"); } catch (error) { toast.error(error instanceof Error ? error.message : "Không thể xuất CSV"); } };
  const downloadExcel = async () => { try { const result = await excelReport.refetch(); if (!result.data) return; const byteCharacters = atob(result.data.base64); const byteNumbers = new Array(byteCharacters.length); for (let i = 0; i < byteCharacters.length; i++) { byteNumbers[i] = byteCharacters.charCodeAt(i); } const byteArray = new Uint8Array(byteNumbers); const blob = new Blob([byteArray], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }); const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = result.data.filename; link.click(); URL.revokeObjectURL(url); toast.success("Đã xuất báo cáo Excel (.xlsx)"); } catch (error) { toast.error(error instanceof Error ? error.message : "Không thể xuất Excel"); } };
  const downloadPdf = async () => { try { const result = await pdfReport.refetch(); if (!result.data) return; const byteCharacters = atob(result.data.base64); const byteNumbers = new Array(byteCharacters.length); for (let i = 0; i < byteCharacters.length; i++) { byteNumbers[i] = byteCharacters.charCodeAt(i); } const byteArray = new Uint8Array(byteNumbers); const blob = new Blob([byteArray], { type: "application/pdf" }); const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = result.data.filename; link.click(); URL.revokeObjectURL(url); toast.success("Đã xuất báo cáo PDF kèm biểu đồ"); } catch (error) { toast.error(error instanceof Error ? error.message : "Không thể xuất PDF"); } };

  return <IqcShell><div className="mx-auto max-w-[1200px] space-y-7 py-4"><PageHeading eyebrow="Reporting · 07" title="Báo cáo nội kiểm" description="Tạo báo cáo theo tháng hoặc quý, sẵn sàng lưu trữ, chia sẻ và xuất định dạng Excel chuẩn." /><Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="border-b border-[#edf3f3] pb-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#e9f5f3] p-2.5 text-primary"><FileSpreadsheet className="h-5 w-5" /></div><div><CardTitle className="text-base text-[#14314a]">Thiết lập phạm vi báo cáo</CardTitle><p className="mt-1 text-xs text-muted-foreground">Xuất dữ liệu toàn diện kèm Z-score, trạng thái và quy tắc vi phạm theo bộ lọc.</p></div></div></CardHeader><CardContent className="space-y-5 p-5"><FilterBar data={data} testId={testId} setTestId={setTestId} materialId={materialId} setMaterialId={setMaterialId} from={from} setFrom={setFrom} to={to} setTo={setTo} /><div className="flex flex-wrap items-center gap-2 rounded-2xl border border-[#dcebea] bg-[#f8fbfb] p-3 text-xs"><span className="font-semibold text-primary">Chọn nhanh kỳ:</span><Button variant="outline" size="sm" className="h-8 rounded-lg bg-white" onClick={() => applyPreset("thisMonth")}>Tháng này</Button><Button variant="outline" size="sm" className="h-8 rounded-lg bg-white" onClick={() => applyPreset("lastMonth")}>Tháng trước</Button><Button variant="outline" size="sm" className="h-8 rounded-lg bg-white" onClick={() => applyPreset("thisQuarter")}>Quý này</Button><Button variant="outline" size="sm" className="h-8 rounded-lg bg-white" onClick={() => applyPreset("all")}>Toàn bộ thời gian</Button></div><div className="grid gap-4 md:grid-cols-3"><div className="rounded-2xl border border-[#dcebea] bg-[#f8fbfb] p-5"><p className="text-xs font-semibold uppercase tracking-[0.12em] text-primary">Kỳ báo cáo</p><p className="mt-2 text-sm leading-6 text-muted-foreground">Chọn ngày bắt đầu và kết thúc trong bộ lọc để lọc chính xác khoảng thời gian.</p></div><div className="rounded-2xl border border-[#dcebea] bg-[#f8fbfb] p-5"><p className="text-xs font-semibold uppercase tracking-[0.12em] text-primary">Nội dung chi tiết</p><p className="mt-2 text-sm leading-6 text-muted-foreground">Bao gồm giá trị đo, Mean/SD mục tiêu, Z-score, trạng thái và quy tắc vi phạm.</p></div><div className="rounded-2xl border border-[#dcebea] bg-[#f8fbfb] p-5"><p className="text-xs font-semibold uppercase tracking-[0.12em] text-primary">Định dạng hỗ trợ</p><p className="mt-2 text-sm leading-6 text-muted-foreground">Hỗ trợ cả Excel (.xlsx) chuẩn và CSV để tích hợp với mọi hệ thống LIS.</p></div></div><div className="flex flex-col gap-3 rounded-2xl bg-[#14314a] p-5 text-white sm:flex-row sm:items-center sm:justify-between"><div><p className="font-medium">Sẵn sàng xuất file báo cáo</p><p className="mt-1 text-xs text-white/55">Dữ liệu lọc hiện tại sẽ được đóng gói vào file.</p></div><div className="flex flex-wrap gap-3"><Button onClick={downloadCsv} disabled={csvReport.isFetching} variant="outline" className="h-10 gap-2 rounded-xl border-white/20 bg-transparent text-white hover:bg-white/10 hover:text-white"><Download className="h-4 w-4" />{csvReport.isFetching ? "Đang tạo..." : "Xuất CSV"}</Button><Button onClick={downloadExcel} disabled={excelReport.isFetching} variant="outline" className="h-10 gap-2 rounded-xl border-white/20 bg-transparent text-white hover:bg-white/10 hover:text-white"><FileSpreadsheet className="h-4 w-4" />{excelReport.isFetching ? "Đang tạo Excel..." : "Xuất Excel"}</Button><Button onClick={downloadPdf} disabled={pdfReport.isFetching} className="h-10 gap-2 rounded-xl bg-[#72d4bf] px-4 text-[#14314a] hover:bg-[#8be1cf]"><FileText className="h-4 w-4" />{pdfReport.isFetching ? "Đang tạo PDF..." : "Xuất PDF có biểu đồ"}</Button></div></div></CardContent></Card></div></IqcShell>;
}

export default function IqcDashboard() {
  const [location] = useLocation();
  const data = useIqcData();
  if (location === "/results") return <ResultsPage data={data} />;
  if (location === "/tests") return <TestsPage data={data} />;
  if (location === "/materials") return <MaterialsPage data={data} />;
  if (location === "/analytics") return <AnalyticsPage data={data} />;
  if (location === "/history") return <HistoryPage data={data} />;
  if (location === "/reports") return <ReportsPage data={data} />;
  if (location === "/settings") return <IqcShell><SettingsPage /></IqcShell>;
  if (location === "/audit-trail") return <IqcShell><AuditTrailPage /></IqcShell>;
  return <DashboardHome data={data} />;
}
