# Verification notes

- Screenshot verification at `/settings` and `/audit-trail` completed at desktop 1280x900. Both pages render inside the existing dashboard sidebar with the expected clinical teal/navy visual language, responsive cards, filters, empty state, and role controls.
- Settings page shows laboratory information fields, logo upload panel, admin role selector, and permissions summary. Audit Trail page shows action/object/date filters and a clear empty state when no audit records match.
- `pnpm check` passed with no TypeScript errors.
- `pnpm test` passed: 4 test files and 9 tests, including RBAC tests.
- `pnpm build` passed; Vite emitted only the existing large-chunk advisory.
- The uploaded logo is now rendered in the dashboard sidebar when `settings.logoUrl` exists; otherwise the FlaskConical fallback remains.

## PDF có biểu đồ — xác minh 13/08/2026

- Endpoint `reports.pdf` trả HTTP 200 và trình duyệt tải được file PDF.
- Bản PDF đầu tiên dùng font PDFKit mặc định làm tiếng Việt bị lỗi; đã thay bằng Noto Sans Regular/Bold và loại bỏ phụ thuộc Python/PNG.
- Bản PDF mới nhất `/home/ubuntu/Downloads/iqc-report-2026-08-13 (1).pdf` có 1 trang A4, kích thước 25 KB, tiếng Việt hiển thị đúng.
- Biểu đồ Levey–Jennings được vẽ vector trực tiếp trong PDFKit, có Mean, ±1SD, ±2SD, ±3SD, chuỗi Level 1/Level 2 màu riêng và trục X theo ngày.
- Toast giao diện xác nhận “Đã xuất báo cáo PDF kèm biểu đồ”; bảng kết quả và khu vực chữ ký hiển thị đúng bố cục cơ bản.

- Bản PDF sau khi chỉnh chữ ký từng tách thành trang riêng; đã khóa `lineBreak: false` và dùng cùng tọa độ. Bản cuối `/home/ubuntu/Downloads/iqc-report-2026-08-13 (4).pdf` còn 1 trang A4, chữ ký kỹ thuật viên và quản lý nằm cùng hàng dưới bảng.
