import { and, desc, eq, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  controlMaterials,
  InsertControlMaterial,
  InsertIqcResult,
  InsertTest,
  InsertLabSetting,
  InsertAuditLog,
  auditLogs,
  iqcResults,
  labSettings,
  tests,
  InsertUser,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listTests() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(tests).orderBy(tests.name);
}

export async function createTest(data: InsertTest) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(tests).values(data);
  return getTestById(Number(result[0].insertId));
}

export async function getTestById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(tests).where(eq(tests.id, id)).limit(1);
  return result[0];
}

export async function updateTest(id: number, data: Partial<InsertTest>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(tests).set(data).where(eq(tests.id, id));
  return getTestById(id);
}

export async function deleteTest(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(tests).where(eq(tests.id, id));
  return { success: true } as const;
}

export async function listControlMaterials(testId?: number) {
  const db = await getDb();
  if (!db) return [];
  const condition = testId ? eq(controlMaterials.testId, testId) : undefined;
  return db
    .select({ material: controlMaterials, test: tests })
    .from(controlMaterials)
    .innerJoin(tests, eq(controlMaterials.testId, tests.id))
    .where(condition)
    .orderBy(tests.name, controlMaterials.level);
}

export async function createControlMaterial(data: InsertControlMaterial) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(controlMaterials).values(data);
  return getControlMaterialById(Number(result[0].insertId));
}

export async function getControlMaterialById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select({ material: controlMaterials, test: tests })
    .from(controlMaterials)
    .innerJoin(tests, eq(controlMaterials.testId, tests.id))
    .where(eq(controlMaterials.id, id))
    .limit(1);
  return result[0];
}

export async function updateControlMaterial(id: number, data: Partial<InsertControlMaterial>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(controlMaterials).set(data).where(eq(controlMaterials.id, id));
  return getControlMaterialById(id);
}

export async function deleteControlMaterial(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(controlMaterials).where(eq(controlMaterials.id, id));
  return { success: true } as const;
}

export type ResultsFilter = {
  testId?: number;
  controlMaterialId?: number;
  from?: Date;
  to?: Date;
};

export async function listIqcResults(filters: ResultsFilter = {}) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters.testId) conditions.push(eq(iqcResults.testId, filters.testId));
  if (filters.controlMaterialId) conditions.push(eq(iqcResults.controlMaterialId, filters.controlMaterialId));
  if (filters.from) conditions.push(gte(iqcResults.recordedAt, filters.from));
  if (filters.to) conditions.push(lte(iqcResults.recordedAt, filters.to));
  return db
    .select({ result: iqcResults, test: tests, material: controlMaterials })
    .from(iqcResults)
    .innerJoin(tests, eq(iqcResults.testId, tests.id))
    .innerJoin(controlMaterials, eq(iqcResults.controlMaterialId, controlMaterials.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(iqcResults.recordedAt));
}

export async function getIqcResultById(id: number) {
  const results = await listIqcResults();
  return results.find((item) => item.result.id === id);
}

export async function createIqcResult(data: InsertIqcResult) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(iqcResults).values(data);
  return getIqcResultById(Number(result[0].insertId));
}

export async function updateIqcResult(id: number, data: Partial<InsertIqcResult>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(iqcResults).set(data).where(eq(iqcResults.id, id));
  return getIqcResultById(id);
}

export async function deleteIqcResult(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(iqcResults).where(eq(iqcResults.id, id));
  return { success: true } as const;
}


export async function getLabSettings() {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(labSettings).orderBy(labSettings.id).limit(1);
  return result[0];
}

export async function saveLabSettings(data: InsertLabSetting) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const current = await getLabSettings();
  if (current) {
    await db.update(labSettings).set(data).where(eq(labSettings.id, current.id));
    return getLabSettings();
  }
  const result = await db.insert(labSettings).values(data);
  return getLabSettingsById(Number(result[0].insertId));
}

async function getLabSettingsById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(labSettings).where(eq(labSettings.id, id)).limit(1);
  return result[0];
}

export type AuditLogFilters = {
  action?: string;
  targetType?: string;
  userId?: number;
  from?: Date;
  to?: Date;
  limit?: number;
};

export async function createAuditLog(data: InsertAuditLog) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(auditLogs).values(data);
  const rows = await db.select().from(auditLogs).where(eq(auditLogs.id, Number(result[0].insertId))).limit(1);
  return rows[0];
}

export async function listAuditLogs(filters: AuditLogFilters = {}) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters.action) conditions.push(eq(auditLogs.action, filters.action));
  if (filters.targetType) conditions.push(eq(auditLogs.targetType, filters.targetType));
  if (filters.userId) conditions.push(eq(auditLogs.userId, filters.userId));
  if (filters.from) conditions.push(gte(auditLogs.createdAt, filters.from));
  if (filters.to) conditions.push(lte(auditLogs.createdAt, filters.to));
  return db
    .select()
    .from(auditLogs)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(auditLogs.createdAt))
    .limit(Math.min(Math.max(filters.limit ?? 200, 1), 500));
}

export async function listUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: users.id,
    name: users.name,
    email: users.email,
    role: users.role,
    createdAt: users.createdAt,
    lastSignedIn: users.lastSignedIn,
  }).from(users).orderBy(users.name);
}

export type AppRole = "user" | "technician" | "manager" | "admin";

export async function updateUserRole(id: number, role: AppRole) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(users).set({ role }).where(eq(users.id, id));
  const result = await db.select({
    id: users.id,
    name: users.name,
    email: users.email,
    role: users.role,
    createdAt: users.createdAt,
    lastSignedIn: users.lastSignedIn,
  }).from(users).where(eq(users.id, id)).limit(1);
  return result[0];
}
