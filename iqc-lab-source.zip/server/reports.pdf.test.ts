import { describe, expect, it } from "vitest";
import { buildPdfChartRows, getPdfChartDateKeys } from "./routers";

describe("IQC PDF report chart data", () => {
  it("sorts chart rows chronologically and normalizes missing z-scores", () => {
    const rows = buildPdfChartRows([
      { level: "Level 1", recordedAt: "2026-08-14T08:00:00.000Z", zScore: null },
      { level: "Level 2", recordedAt: "2026-08-13T08:00:00.000Z", zScore: 1.25 },
    ]);

    expect(rows.map((row) => row.recordedAt)).toEqual([
      "2026-08-13T08:00:00.000Z",
      "2026-08-14T08:00:00.000Z",
    ]);
    expect(rows[1].zScore).toBe(0);
  });

  it("uses one shared X-axis date key for same-day QC points", () => {
    const rows = buildPdfChartRows([
      { level: "Level 1", recordedAt: "2026-08-13T08:00:00.000Z", zScore: -1 },
      { level: "Level 2", recordedAt: "2026-08-13T14:00:00.000Z", zScore: 1 },
      { level: "Level 1", recordedAt: "2026-08-14T08:00:00.000Z", zScore: 0 },
    ]);

    expect(getPdfChartDateKeys(rows)).toEqual(["2026-08-13", "2026-08-14"]);
  });
});
