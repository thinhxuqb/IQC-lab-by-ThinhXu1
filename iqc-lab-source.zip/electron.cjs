const { app, BrowserWindow, dialog, globalShortcut, ipcMain } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const fs = require('fs');
const { autoUpdater } = require('electron-updater');

let mainWindow = null;
let serverProcess = null;
let updateState = {
  status: process.platform === 'win32' && app.isPackaged ? 'idle' : 'unsupported',
  version: null,
  progress: 0,
  message: process.platform === 'win32' && app.isPackaged ? null : 'Tự động cập nhật chỉ khả dụng trong bản cài Windows.'
};

function publishUpdateState(nextState) {
  updateState = { ...updateState, ...nextState };
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('updates:state', updateState);
  }
}

function startServer() {
  const serverPath = path.join(__dirname, 'dist', 'index.js');
  if (!fs.existsSync(serverPath)) {
    dialog.showErrorBox('Lỗi khởi động', `Không tìm thấy máy chủ backend tại: ${serverPath}`);
    app.quit();
    return;
  }

  serverProcess = spawn(process.execPath, [serverPath], {
    env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', PORT: '3000', NODE_ENV: 'production' },
    windowsHide: true,
    stdio: 'inherit'
  });
  serverProcess.on('error', error => console.error('Không thể khởi động server nội bộ:', error));
}

function configureAutoUpdater() {
  if (!app.isPackaged || process.platform !== 'win32') return;

  autoUpdater.autoDownload = false;
  autoUpdater.autoInstallOnAppQuit = true;
  autoUpdater.on('checking-for-update', () => publishUpdateState({ status: 'checking', message: 'Đang kiểm tra phiên bản mới…' }));
  autoUpdater.on('update-available', info => publishUpdateState({
    status: 'available',
    version: info.version,
    progress: 0,
    message: `Đã có phiên bản ${info.version}.`
  }));
  autoUpdater.on('update-not-available', () => publishUpdateState({
    status: 'idle', version: null, progress: 0, message: 'Bạn đang sử dụng phiên bản mới nhất.'
  }));
  autoUpdater.on('download-progress', progress => publishUpdateState({
    status: 'downloading',
    progress: Math.round(progress.percent),
    message: `Đang tải bản cập nhật… ${Math.round(progress.percent)}%`
  }));
  autoUpdater.on('update-downloaded', info => publishUpdateState({
    status: 'downloaded',
    version: info.version,
    progress: 100,
    message: 'Bản cập nhật đã sẵn sàng. Khởi động lại để cài đặt.'
  }));
  autoUpdater.on('error', error => {
    console.error('Auto-update error:', error);
    publishUpdateState({ status: 'error', message: 'Không thể kiểm tra hoặc tải bản cập nhật. Vui lòng thử lại sau.' });
  });
}

async function checkForUpdates() {
  if (!app.isPackaged || process.platform !== 'win32') {
    publishUpdateState({ status: 'unsupported', message: 'Tự động cập nhật chỉ khả dụng trong bản cài Windows.' });
    return updateState;
  }
  try {
    await autoUpdater.checkForUpdates();
  } catch (error) {
    console.error('Check for updates failed:', error);
    publishUpdateState({ status: 'error', message: 'Không thể kết nối máy chủ cập nhật.' });
  }
  return updateState;
}

function registerUpdateIpc() {
  ipcMain.handle('updates:get-state', () => updateState);
  ipcMain.handle('updates:check', () => checkForUpdates());
  ipcMain.handle('updates:download', async () => {
    if (updateState.status !== 'available') return updateState;
    try {
      publishUpdateState({ status: 'downloading', progress: 0, message: 'Đang bắt đầu tải bản cập nhật…' });
      await autoUpdater.downloadUpdate();
    } catch (error) {
      console.error('Download update failed:', error);
      publishUpdateState({ status: 'error', message: 'Tải bản cập nhật thất bại. Vui lòng thử lại.' });
    }
    return updateState;
  });
  ipcMain.handle('updates:install', () => {
    if (updateState.status !== 'downloaded') return false;
    setImmediate(() => autoUpdater.quitAndInstall(false, true));
    return true;
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    title: 'IQC Lab by ThinhXu',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });

  mainWindow.loadURL('http://localhost:3000');
  globalShortcut.register('CommandOrControl+Shift+N', () => {
    if (mainWindow) mainWindow.loadURL('http://localhost:3000/results');
  });
  mainWindow.on('closed', () => { mainWindow = null; });
}

registerUpdateIpc();
configureAutoUpdater();

app.whenReady().then(() => {
  startServer();
  setTimeout(createWindow, 2000);
  if (app.isPackaged && process.platform === 'win32') setTimeout(checkForUpdates, 5000);
});

app.on('window-all-closed', () => {
  if (serverProcess) {
    try { serverProcess.kill(); } catch (_) { /* cleanup only */ }
  }
  app.quit();
});

app.on('will-quit', () => globalShortcut.unregisterAll());
