# GitHub release evidence

- **Tag**: `v1.0.2`
- **Release Title**: `IQC Lab by ThinhXu v1.0.2 — Auto-update`
- **Release URL**: `https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/releases/tag/v1.0.2`
- **GitHub Actions Run #13**: `https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/actions/runs/31712279798` (Status: Success)
- **Verified Assets**:
  1. `IQC-Lab-by-ThinhXu-Setup-1.0.2.exe` (NSIS Installer, 136 MB, sha256:0b6a1f73c653a0d087640801a547104e309aca3ca1e327b49436c2973f0fe9d4)
  2. `IQC-Lab-by-ThinhXu-Portable-1.0.2.zip` (Portable ZIP, 136 MB, sha256:d9aaa175315105265e627598924b713abc8949045262c28974b808e784f03794)
  3. `IQC-Lab-by-ThinhXu-1.0.2.exe` (Standalone Portable EXE, 136 MB, sha256:b485eb97ac4f90070f66fc31423a16fa3963683d47fb9b3a3a3724c14379207b)
  4. `latest.yml` (Auto-update metadata configuration file)
  5. `IQC-Lab-by-ThinhXu-Setup-1.0.2.exe.blockmap`
