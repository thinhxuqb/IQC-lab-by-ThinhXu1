CREATE TABLE `license_keys` (
	`id` int AUTO_INCREMENT NOT NULL,
	`licenseKey` varchar(128) NOT NULL,
	`hospitalName` varchar(250) NOT NULL,
	`activatedBy` varchar(150),
	`isActivated` int NOT NULL DEFAULT 1,
	`activatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `license_keys_id` PRIMARY KEY(`id`),
	CONSTRAINT `license_keys_licenseKey_unique` UNIQUE(`licenseKey`)
);
