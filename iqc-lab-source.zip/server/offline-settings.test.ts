import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { getLabSettings, saveLabSettings } from "./db";
import { getReportLogoBuffer } from "./routers";
import { DEFAULT_LAB_LOGO_DATA_URL } from "@shared/branding";

describe("offline laboratory settings", () => {
  const originalDatabaseUrl = process.env.DATABASE_URL;
  const originalDataDir = process.env.IQC_DATA_DIR;
  let dataDir = "";

  beforeEach(() => {
    delete process.env.DATABASE_URL;
    dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "iqc-lab-settings-"));
    process.env.IQC_DATA_DIR = dataDir;
  });

  afterEach(() => {
    if (originalDatabaseUrl === undefined) delete process.env.DATABASE_URL;
    else process.env.DATABASE_URL = originalDatabaseUrl;

    if (originalDataDir === undefined) delete process.env.IQC_DATA_DIR;
    else process.env.IQC_DATA_DIR = originalDataDir;

    fs.rmSync(dataDir, { recursive: true, force: true });
  });

  it("persists lab identity and custom logo without a database", async () => {
    const customLogo = "data:image/png;base64,AA==";
    const saved = await saveLabSettings({
      labName: "Khoa Xét nghiệm",
      hospitalName: "Bệnh viện mẫu",
      address: "Quảng Bình",
      managerName: "BS. Thịnh",
      chiefTechnician: "KTV. Xuân",
      logoUrl: customLogo,
      phone: "0232 000 000",
      email: "lab@example.org",
    });

    expect(saved?.logoUrl).toBe(customLogo);
    expect(fs.existsSync(path.join(dataDir, "settings.json"))).toBe(true);

    const reloaded = await getLabSettings();
    expect(reloaded?.labName).toBe("Khoa Xét nghiệm");
    expect(reloaded?.logoUrl).toBe(customLogo);
    expect(reloaded?.updatedAt).toBeInstanceOf(Date);
  });
});

describe("report logo selection", () => {
  it("prefers a valid local image data URL", () => {
    const customLogo = "data:image/png;base64,AAECAw==";
    expect(getReportLogoBuffer(customLogo)).toEqual(Buffer.from([0, 1, 2, 3]));
  });

  it("falls back to the embedded logo when no local logo is configured", () => {
    const embeddedLogo = Buffer.from(DEFAULT_LAB_LOGO_DATA_URL.split(",")[1] ?? "", "base64");
    expect(getReportLogoBuffer(null)).toEqual(embeddedLogo);
  });
});

export {};
