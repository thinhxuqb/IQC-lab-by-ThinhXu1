import { describe, expect, it } from "vitest";
import { getFileList, parseUpdateInfo } from "electron-updater/out/providers/Provider.js";

const repository = "thinhxuqb/IQC-lab-by-ThinhXu1";
const releaseBase = `https://github.com/${repository}/releases/download/v1.0.27`;

const runReleaseE2E = process.env.RUN_RELEASE_E2E === "1";

describe("electron-updater v1.0.27 release", () => {
  it.skipIf(!runReleaseE2E)("reads the public latest.yml with electron-updater's parser and resolves the Installer asset", async () => {
    const metadataUrl = `${releaseBase}/latest.yml`;
    const metadataResponse = await fetch(metadataUrl, { redirect: "follow" });
    expect(metadataResponse.ok).toBe(true);

    const rawMetadata = await metadataResponse.text();
    const updateInfo = parseUpdateInfo(rawMetadata, "latest.yml", metadataUrl);
    const files = getFileList(updateInfo);

    expect(updateInfo.version).toBe("1.0.27");
    expect(updateInfo.path).toBe("IQC-Lab-by-ThinhXu-1.0.27-Setup.exe");
    expect(files).toHaveLength(1);
    expect(files[0]?.url).toBe("IQC-Lab-by-ThinhXu-1.0.27-Setup.exe");
    expect(files[0]?.sha512).toBe(updateInfo.sha512);
    expect(files[0]?.size).toBe(143287342);

    const installerResponse = await fetch(`${releaseBase}/${files[0]?.url}`, {
      method: "HEAD",
      redirect: "follow",
    });
    expect(installerResponse.ok).toBe(true);
  }, 30_000);
});
