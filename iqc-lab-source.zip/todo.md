# Project TODO - Quản lý Nội kiểm Xét nghiệm (IQC Lab Manager)

- [x] Khởi tạo dự án ứng dụng web full-stack với tRPC, Drizzle, React, Tailwind CSS
- [x] Thiết kế cơ sở dữ liệu Drizzle cho danh mục xét nghiệm (Tests), vật liệu kiểm soát (Control Materials), mức kiểm chứng (Control Levels với Mean/SD) và kết quả nội kiểm (IQC Results)
- [x] Xây dựng thuật toán kiểm tra các quy tắc Westgard tự động (1-2s, 1-3s, 2-2s, R-4s, 4-1s, 10x) và tính toán thống kê (Mean thực tế, SD, CV%, số điểm vi phạm)
- [x] Xây dựng backend routers (tRPC) đầy đủ cho Quản lý danh mục xét nghiệm, Vật liệu, Nhập kết quả, Thống kê, Lịch sử và Xuất Excel/CSV
- [x] Thiết kế giao diện Dashboard sang trọng, tinh tế (phong cách y tế cao cấp, typography mượt mà, màu sắc chuẩn y khoa)
- [x] Phát triển màn hình Quản lý Danh mục xét nghiệm và Cấu hình Mean/SD theo các mức (Level 1, 2, 3)
- [x] Phát triển màn hình Quản lý Vật liệu kiểm soát (Control Materials, Lô số, Hạn sử dụng, Gán xét nghiệm)
- [x] Phát triển màn hình Nhập kết quả nội kiểm hàng ngày với giao diện nhanh, trực quan và kiểm tra lỗi ngay lập tức
- [x] Phát triển màn hình Biểu đồ Levey–Jennings tương tác cao (hiển thị Mean, ±1SD, ±2SD, ±3SD, các điểm vi phạm Westgard được tô màu cảnh báo)
- [x] Phát triển màn hình Thống kê định kỳ & Báo cáo chất lượng (CV%, số liệu tháng/quý)
- [x] Phát triển màn hình Lịch sử kết quả, bộ lọc nâng cao, chức năng chỉnh sửa và xóa kết quả
- [x] Tích hợp tính năng xuất báo cáo Excel/CSV theo tháng/quý cho từng xét nghiệm
- [x] Viết bộ test đơn vị (Vitest) cho các hàm tính toán Westgard và thống kê IQC
- [x] Kiểm tra toàn diện giao diện và xác thực luồng người dùng trước khi bàn giao

## Bổ sung sau kiểm tra trực quan và rà soát luồng

- [x] Thêm xuất Excel/XLSX thực sự ở backend và giao diện chọn định dạng CSV/XLSX
- [x] Bổ sung chỉnh sửa kết quả nội kiểm trong màn hình lịch sử
- [x] Thêm validation tại chỗ cho form xét nghiệm, vật liệu và kết quả nội kiểm
- [x] Hoàn thiện báo cáo theo kỳ tháng/quý rõ ràng bên cạnh khoảng ngày tùy chọn
- [x] Nâng cấp thêm hierarchy, empty states, branding và trạng thái thao tác cho dashboard IQC
- [x] Kiểm thử browser các luồng create/update/delete/export cùng loading, empty và error states
- [x] Chỉ đánh dấu QA hoàn tất sau khi xác minh các luồng chính trong trình duyệt

## Lịch sử trạng thái

- [x] Bản kiểm tra đầu tiên: TypeScript, build production, Vitest và screenshot giao diện đã thực hiện
- [x] Bản hoàn thiện sau rà soát gap: cần thực hiện các mục bổ sung ở trên

> Ghi chú: Bản hiện tại có luồng xuất CSV; các mục bổ sung sẽ hoàn thiện XLSX, chỉnh sửa kết quả và xác minh browser trước checkpoint bàn giao cuối.

## Yêu cầu chỉnh sửa biểu đồ theo mức/lô

- [x] Khi chọn tất cả mức/lô trên biểu đồ Levey–Jennings, phân tách chuỗi theo từng mức/lô và không nối điểm giữa các nhóm
- [x] Gán màu riêng, chú giải rõ ràng và giữ các đường Mean/SD phù hợp cho từng nhóm mức/lô
- [x] Kiểm thử biểu đồ nhiều mức/lô và lưu checkpoint sau khi xác minh giao diện

## QA bổ sung theo bằng chứng trình duyệt

- [x] Xác minh trực tiếp trên browser màn hình `/analytics` với ít nhất hai mức/lô hiển thị đồng thời, ghi nhận chú giải nhiều màu và các chuỗi tách rời
- [x] Cập nhật trạng thái QA sau khi có bằng chứng browser độc lập

## Điều chỉnh biểu đồ dùng chung Mean

- [x] Lồng các mức QC trên cùng hệ trục với một đường Mean và các dải ±SD dùng chung
- [x] Nối liên tục các điểm theo từng mức QC qua các vị trí xen kẽ, không nối chéo giữa các mức
- [x] Cập nhật chú giải màu theo mức QC, kiểm thử và lưu checkpoint phiên bản mới

## Sửa lỗi nối chuỗi xen kẽ

- [x] Điều chỉnh dữ liệu hoặc thuộc tính Line để Level 1 nối với các điểm Level 1 tiếp theo và tương tự cho Level 2/Level 3
- [x] Kiểm tra trực tiếp đồ thị có đường Level 1 và Level 2 hiển thị liên tục, tách biệt trên Mean chung

## Chuẩn hóa trục tung Levey–Jennings theo SD

- [x] Quy đổi từng kết quả QC về Z-score theo Mean và SD mục tiêu của chính mức QC
- [x] Hiển thị trục tung cố định chỉ gồm −3SD, −2SD, −1SD, Mean, +1SD, +2SD và +3SD
- [x] Giữ các đường chuỗi theo màu từng mức QC, kết nối liên tục trong cùng mức trên thang chuẩn hóa
- [x] Kiểm thử trực quan biểu đồ đa mức chuẩn hóa theo SD và lưu checkpoint mới

## Đồng bộ điểm QC theo cùng ngày trên trục hoành

- [x] Nhóm chartData theo ngày lịch thay vì theo từng bản ghi/giờ đo
- [x] Đặt các mức QC cùng ngày vào cùng một vị trí X và vẫn nối liên tục trong từng chuỗi mức
- [x] Kiểm thử trực quan trục ngày và lưu checkpoint cập nhật

## Phạm vi vận hành độc lập (Không kết nối máy xét nghiệm)

- [x] Tập trung hoàn toàn vào quy trình nội kiểm thủ công qua giao diện web: quản lý danh mục, vật liệu, nhập kết quả, biểu đồ Levey–Jennings, quy tắc Westgard, lịch sử và xuất báo cáo Excel/CSV.
- [x] Đã kiểm tra toàn bộ luồng, kiểm thử TypeScript, chạy 5/5 unit test Vitest thành công và xác thực biểu đồ chuẩn hóa Z-score với các điểm QC cùng ngày nằm trên cùng vị trí X.
- [x] Sẵn sàng đưa vào sử dụng thực tế trong phòng xét nghiệm dưới dạng ứng dụng web lưu trữ an toàn.

## Đổi tên thương hiệu

- [x] Đổi tên hiển thị và tiêu đề website thành “IQC Lab by ThinhXu”
- [x] Kiểm tra tiêu đề trình duyệt, sidebar và giao diện sau khi đổi tên
- [x] Lưu checkpoint phiên bản thương hiệu mới

## Mở rộng theo đề xuất (Logo, Cài đặt Lab, Audit Trail & Phân quyền)

- [x] Thiết kế cơ sở dữ liệu cho thông tin cài đặt phòng xét nghiệm (Lab Settings) và Nhật ký hành động (Audit Logs)
- [x] Mở rộng bảng người dùng hoặc phân quyền (role: technician, manager, admin) cho kiểm soát thao tác
- [x] Phát triển màn hình Cài đặt phòng xét nghiệm (Tên lab, địa chỉ, trưởng khoa, logo)
- [x] Phát triển màn hình Nhật ký hành động (Audit Trail) tra cứu lịch sử thay đổi/xóa kết quả
- [x] Tích hợp phân quyền role-based cho các thao tác nhạy cảm (thêm/sửa/xóa danh mục và kết quả, quản trị người dùng)
- [x] Kiểm thử TypeScript, Vitest và lưu checkpoint bàn giao phiên bản mở rộng

## Triển khai Settings, Audit Trail & RBAC

- [x] Hoàn thiện API và helper cho lab settings, audit logs, upload logo và quản lý vai trò
- [x] Xây dựng trang Cài đặt phòng xét nghiệm với cập nhật thông tin và logo
- [x] Xây dựng trang Audit Trail với bộ lọc và bảng lịch sử hành động
- [x] Tích hợp role-based access control cho thao tác tạo/sửa/xóa và quản trị người dùng
- [x] Ghi audit log cho các thao tác dữ liệu chính và thay đổi cài đặt
- [x] Viết/cập nhật Vitest, chạy kiểm tra TypeScript/build và xác minh browser
- [x] Lưu checkpoint bàn giao phiên bản mở rộng

## Báo cáo PDF có biểu đồ

- [x] Thêm endpoint backend xuất PDF theo cùng bộ lọc báo cáo hiện tại
- [x] Tạo biểu đồ Levey–Jennings Z-score và nhúng vào PDF
- [x] Tích hợp nút Xuất PDF có biểu đồ trên trang Báo cáo
- [x] Kiểm thử file PDF, nội dung biểu đồ, TypeScript, Vitest và build
- [x] Lưu checkpoint bàn giao tính năng PDF

## Đóng gói Desktop Offline (.exe)

- [x] Cấu hình electron.js để khởi chạy server cục bộ và giao diện ứng dụng
- [x] Thêm electron và electron-builder vào package.json với cấu hình nsis target
- [x] Đóng gói build production thành công và chuẩn bị hướng dẫn/scripts build .exe

## Phát hành GitHub và build Windows

- [ ] Chuẩn bị source archive không chứa secrets và node_modules để upload an toàn
- [ ] Tạo workflow GitHub Actions đúng thư mục .github/workflows để giải nén source và build Windows
- [ ] Commit source archive và workflow lên repository IQC-lab-by-ThinhXu1
- [ ] Xác minh Actions tạo artifact NSIS .exe và Portable .zip
