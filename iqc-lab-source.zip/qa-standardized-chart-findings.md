# QA — Biểu đồ Levey–Jennings chuẩn hóa theo SD

## Kết quả xác minh trực tiếp

Ngày kiểm tra: 13/08/2026. Màn hình `/analytics` được kiểm tra trong phiên đã đăng nhập với bộ lọc **Tất cả mức / lô**.

| Hạng mục | Kết quả |
| --- | --- |
| Trục tung | Hiển thị đúng các mốc `-3SD`, `-2SD`, `-1SD`, `Mean`, `+1SD`, `+2SD`, `+3SD`. |
| Chuẩn hóa dữ liệu | Điểm QC được biểu diễn trên thang Z-score, nên các mức có thể cùng xuất hiện trên một biểu đồ. |
| Chuỗi mức QC | Có hai đường SVG độc lập: `#2f7f80` (Level 1) và `#cf8d2e` (Level 2); mỗi đường gồm 9 đoạn nối liên tục. |
| Mean và các dải SD | Đường Mean tại Z=0; các dải ±1SD, ±2SD, ±3SD hiển thị bằng các đường tham chiếu. |

## Kiểm thử kỹ thuật

- `pnpm check`: thành công.
- `pnpm test`: 5/5 bài kiểm thử thành công.
- `pnpm build`: thành công.

## Bổ sung QA — đồng bộ theo ngày

Màn hình `/analytics` được kiểm tra trực tiếp với bộ lọc tất cả mức/lô. Trục X hiển thị một nhãn duy nhất cho mỗi ngày: `01-08` đến `10-08`; không còn hậu tố số thứ tự theo từng bản ghi. Hai chuỗi SVG Level 1 (`#2f7f80`) và Level 2 (`#cf8d2e`) vẫn độc lập, mỗi chuỗi có 9 đoạn nối. Như vậy, các mức QC phát sinh cùng ngày dùng chung một vị trí X trong chartData.
