const express = require('express');
const path = require('path');
const fs = require('fs');

function startProductionServer(port = 3000) {
  const app = express();
  
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Serve static files from dist/public
  const possiblePaths = [
    path.join(__dirname, 'public'),
    path.join(process.resourcesPath || '', 'app', 'dist', 'public'),
    path.join(process.resourcesPath || '', 'app.asar.unpacked', 'dist', 'public'),
    path.join(__dirname, '..', 'dist', 'public')
  ];

  let staticDir = possiblePaths.find(p => fs.existsSync(p)) || possiblePaths[0];
  console.log('[IQC Server] Serving static files from:', staticDir);

  app.use(express.static(staticDir));

  // Fallback to index.html for SPA routing
  app.get('*', (req, res) => {
    const indexPath = path.join(staticDir, 'index.html');
    if (fs.existsSync(indexPath)) {
      res.sendFile(indexPath);
    } else {
      res.status(404).send('IQC Lab by ThinhXu - Static files not found at: ' + indexPath);
    }
  });

  return new Promise((resolve, reject) => {
    const server = app.listen(port, '127.0.0.1', () => {
      const actualPort = server.address().port;
      console.log(`[IQC Server] Running on http://127.0.0.1:${actualPort}`);
      
      // Write port file for Electron
      try {
        const portFilePath = path.join(require('os').tmpdir(), 'iqc-lab-port.txt');
        fs.writeFileSync(portFilePath, String(actualPort));
      } catch (e) {
        console.error('Failed to write port file:', e);
      }
      
      resolve({ app, server, port: actualPort });
    }).on('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        console.log(`Port ${port} in use, trying random port...`);
        const fallbackServer = app.listen(0, '127.0.0.1', () => {
          const actualPort = fallbackServer.address().port;
          try {
            const portFilePath = path.join(require('os').tmpdir(), 'iqc-lab-port.txt');
            fs.writeFileSync(portFilePath, String(actualPort));
          } catch (e) {}
          resolve({ app, server: fallbackServer, port: actualPort });
        });
      } else {
        reject(err);
      }
    });
  });
}

if (require.main === module) {
  startProductionServer(3000).catch(console.error);
}

module.exports = { startProductionServer };
