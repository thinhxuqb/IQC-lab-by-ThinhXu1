import express from "express";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { appRouter } from "./routers";
import { createContext } from "./_core/context";
import { startEnabledInstrumentConnections, stopAllInstrumentConnections } from "./instrument-runtime";

function resolveStaticDir() {
  const resourcesPath = (process as NodeJS.Process & { resourcesPath?: string }).resourcesPath || "";
  const possiblePaths = [
    path.join(__dirname, "public"),
    path.join(resourcesPath, "app", "dist", "public"),
    path.join(resourcesPath, "app.asar.unpacked", "dist", "public"),
    path.join(__dirname, "..", "dist", "public"),
  ];

  return possiblePaths.find(candidate => fs.existsSync(candidate)) || possiblePaths[0];
}

function writePortFile(port: number) {
  try {
    fs.writeFileSync(path.join(os.tmpdir(), "iqc-lab-port.txt"), String(port));
  } catch (error) {
    console.error("[IQC Server] Failed to write port file:", error);
  }
}

export function startProductionServer(port = 3000) {
  const app = express();
  const staticDir = resolveStaticDir();

  app.disable("x-powered-by");
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ extended: true, limit: "50mb" }));

  // The router is bundled into this entry by esbuild. This keeps the packaged
  // Electron app independent from TypeScript source files outside app.asar.
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: "iqc-lab", transport: "trpc" });
  });

  app.use(express.static(staticDir));

  // Never send index.html for an API request. A malformed SPA fallback response
  // is what makes the tRPC client report "Unable to transform response".
  app.get("*", (req, res) => {
    if (req.path.startsWith("/api/")) {
      return res.status(404).json({ error: { message: `API route not found: ${req.path}` } });
    }

    const indexPath = path.join(staticDir, "index.html");
    if (fs.existsSync(indexPath)) {
      return res.sendFile(indexPath);
    }

    return res.status(404).send(`IQC Lab by ThinhXu - Static files not found at: ${indexPath}`);
  });

  const listen = (listenPort: number) => new Promise<{ app: express.Express; server: ReturnType<typeof app.listen>; port: number }>((resolve, reject) => {
    const server = app.listen(listenPort, "127.0.0.1", () => {
      const address = server.address();
      const actualPort = typeof address === "object" && address ? address.port : listenPort;
      writePortFile(actualPort);
      console.log(`[IQC Server] Running on http://127.0.0.1:${actualPort}`);
      if (process.env.IQC_DESKTOP === "1") {
        void startEnabledInstrumentConnections().catch((error) => console.error("[IQC Interface] Failed to start enabled connections:", error));
        process.once("beforeExit", () => { void stopAllInstrumentConnections(); });
      }
      resolve({ app, server, port: actualPort });
    });

    server.once("error", (error: NodeJS.ErrnoException) => {
      if (error.code === "EADDRINUSE" && listenPort !== 0) {
        void listen(0).then(resolve, reject);
        return;
      }
      reject(error);
    });
  });

  return listen(port);
}

if (require.main === module) {
  startProductionServer(Number(process.env.PORT || 3000)).catch(error => {
    console.error("[IQC Server] Failed to start:", error);
    process.exitCode = 1;
  });
}
