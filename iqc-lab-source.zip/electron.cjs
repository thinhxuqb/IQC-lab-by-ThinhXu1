const { app, BrowserWindow, ipcMain, globalShortcut, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { autoUpdater } = require('electron-updater');
// The production server is copied into dist/index.cjs during the production build.
// Resolve from __dirname so this works in an unpacked folder and inside app.asar.
const productionServerPath = path.join(__dirname, 'dist', 'index.cjs');
const { startProductionServer } = require(productionServerPath);

let mainWindow = null;
let updateState = {
  status: process.platform === 'win32' && app.isPackaged ? 'idle' : 'unsupported',
  version: null,
  progress: 0,
  message: process.platform === 'win32' && app.isPackaged ? null : 'Tự động cập nhật chỉ khả dụng trong bản cài Windows.'
};

function publishUpdateState(nextState) {
  updateState = { ...updateState, ...nextState };
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('updates:state', updateState);
  }
}

function startServer() {
  try {
    process.env.NODE_ENV = 'production';
    process.env.IQC_DESKTOP = '1';
    process.env.IQC_DATA_DIR = path.join(app.getPath('userData'), 'data');
    fs.mkdirSync(process.env.IQC_DATA_DIR, { recursive: true });
    startProductionServer(3000).catch(err => {
      let errorLogPath = path.join(process.cwd(), 'iqc-error.log');
      try { errorLogPath = path.join(app.getPath('userData'), 'iqc-error.log'); } catch(_) {}
      fs.writeFileSync(errorLogPath, `[Embedded Server Error] ${err && err.stack ? err.stack : err}\n`, { flag: 'a' });
    });
  } catch (err) {
    let errorLogPath = path.join(process.cwd(), 'iqc-error.log');
    try { errorLogPath = path.join(app.getPath('userData'), 'iqc-error.log'); } catch(_) {}
    fs.writeFileSync(errorLogPath, `[Embedded Server Init Error] ${err && err.stack ? err.stack : err}\n`, { flag: 'a' });
  }
}

function configureAutoUpdater() {
  if (!app.isPackaged || process.platform !== 'win32') return;

  autoUpdater.autoDownload = true;
  autoUpdater.autoInstallOnAppQuit = true;
  autoUpdater.on('checking-for-update', () => publishUpdateState({ status: 'checking', message: 'Đang kiểm tra phiên bản mới…' }));
  autoUpdater.on('update-available', info => publishUpdateState({
    status: 'downloading',
    version: info.version,
    progress: 0,
    message: `Đã có phiên bản ${info.version}. Đang tự động tải xuống…`
  }));
  autoUpdater.on('update-not-available', () => publishUpdateState({
    status: 'idle', version: null, progress: 0, message: 'Bạn đang sử dụng phiên bản mới nhất.'
  }));
  autoUpdater.on('download-progress', progress => publishUpdateState({
    status: 'downloading',
    progress: Math.round(progress.percent),
    message: `Đang tải bản cập nhật… ${Math.round(progress.percent)}%`
  }));
  autoUpdater.on('update-downloaded', info => publishUpdateState({
    status: 'downloaded',
    version: info.version,
    progress: 100,
    message: 'Bản cập nhật đã sẵn sàng. Khởi động lại để cài đặt.'
  }));
  autoUpdater.on('error', error => {
    console.error('Auto-update error:', error);
    publishUpdateState({ status: 'error', message: 'Không thể kiểm tra hoặc tải bản cập nhật. Vui lòng thử lại sau.' });
  });
}

async function checkForUpdates() {
  if (!app.isPackaged || process.platform !== 'win32') {
    publishUpdateState({ status: 'unsupported', message: 'Tự động cập nhật chỉ khả dụng trong bản cài Windows.' });
    return updateState;
  }
  try {
    await autoUpdater.checkForUpdates();
  } catch (error) {
    console.error('Check for updates failed:', error);
    publishUpdateState({ status: 'error', message: 'Không thể kết nối máy chủ cập nhật.' });
  }
  return updateState;
}

function registerUpdateIpc() {
  ipcMain.handle('updates:get-state', () => updateState);
  ipcMain.handle('updates:check', () => checkForUpdates());
  ipcMain.handle('updates:download', async () => {
    if (updateState.status !== 'available') return updateState;
    try {
      publishUpdateState({ status: 'downloading', progress: 0, message: 'Đang bắt đầu tải bản cập nhật…' });
      await autoUpdater.downloadUpdate();
    } catch (error) {
      console.error('Download update failed:', error);
      publishUpdateState({ status: 'error', message: 'Tải bản cập nhật thất bại. Vui lòng thử lại.' });
    }
    return updateState;
  });
  ipcMain.handle('updates:install', () => {
    if (updateState.status !== 'downloaded') return false;
    setImmediate(() => autoUpdater.quitAndInstall(false, true));
    return true;
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    title: 'IQC Lab by ThinhXu',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });

  let errorLogPath = '';
  try {
    errorLogPath = path.join(app.getPath('userData'), 'iqc-error.log');
  } catch(_) {
    errorLogPath = path.join(process.cwd(), 'iqc-error.log');
  }
  function logToFile(msg) {
    try {
      fs.appendFileSync(errorLogPath, `${new Date().toISOString()} - ${msg}\n`, 'utf-8');
    } catch(_) {}
  }

  mainWindow.webContents.on('console-message', (event, level, message, line, sourceId) => {
    logToFile(`[Renderer Console] [level ${level}] ${message} (${sourceId}:${line})`);
  });

  mainWindow.webContents.on('did-fail-load', (event, errorCode, errorDescription, validatedURL) => {
    logToFile(`[Did Fail Load] code: ${errorCode}, desc: ${errorDescription}, url: ${validatedURL}`);
  });

  const portFile = path.join(require('os').tmpdir(), 'iqc-lab-port.txt');
  let attempts = 0;

  function tryLoad() {
    let port = '3000';
    try {
      if (fs.existsSync(portFile)) {
        const val = fs.readFileSync(portFile, 'utf-8').trim();
        if (val) port = val;
      }
    } catch(_) {}

    const targetUrl = `http://127.0.0.1:${port}`;
    if (attempts < 20 && !fs.existsSync(portFile)) {
      attempts++;
      setTimeout(tryLoad, 300);
      return;
    }

    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.loadURL(targetUrl).catch(err => {
        console.error('Failed to load URL:', targetUrl, err);
        if (attempts < 30) {
          attempts++;
          setTimeout(tryLoad, 800);
        }
      });
    }
  }

  tryLoad();

  globalShortcut.register('CommandOrControl+Shift+N', () => {
    if (mainWindow) {
      let port = '3000';
      try {
        if (fs.existsSync(portFile)) {
          const val = fs.readFileSync(portFile, 'utf-8').trim();
          if (val) port = val;
        }
      } catch(_) {}
      mainWindow.loadURL(`http://127.0.0.1:${port}/results`);
    }
  });
  mainWindow.on('closed', () => { mainWindow = null; });
}

registerUpdateIpc();
configureAutoUpdater();

app.whenReady().then(() => {
  startServer();
  setTimeout(createWindow, 1000);
  if (app.isPackaged && process.platform === 'win32') setTimeout(checkForUpdates, 5000);
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('will-quit', () => globalShortcut.unregisterAll());
