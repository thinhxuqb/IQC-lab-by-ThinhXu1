import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { DEFAULT_LAB_LOGO_ALT, DEFAULT_LAB_LOGO_DATA_URL } from "@shared/branding";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { useIsMobile } from "@/hooks/useMobile";
import { BarChart3, Cable, ClipboardList, ClipboardPenLine, FlaskConical, History, LayoutDashboard, LogOut, PanelLeft, Settings2, FileDown } from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from './DashboardLayoutSkeleton';
import { UpdateBanner } from './UpdateBanner';
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { toast } from "sonner";

const menuItems: Array<{ icon: typeof LayoutDashboard; label: string; path: string; roles?: string[] }> = [
  { icon: LayoutDashboard, label: "Tổng quan", path: "/" },
  { icon: ClipboardPenLine, label: "Nhập kết quả", path: "/results" },
  { icon: FlaskConical, label: "Danh mục xét nghiệm", path: "/tests" },
  { icon: BarChart3, label: "Biểu đồ & thống kê", path: "/analytics" },
  { icon: History, label: "Lịch sử kết quả", path: "/history" },
  { icon: FileDown, label: "Báo cáo", path: "/reports" },
  { icon: Cable, label: "Interface máy xét nghiệm", path: "/instrument-interface", roles: ["manager", "admin"] },
  { icon: Settings2, label: "Cấu hình vật liệu", path: "/materials" },
  { icon: ClipboardList, label: "Audit Trail", path: "/audit-trail", roles: ["manager", "admin"] },
  { icon: Settings2, label: "Cài đặt phòng xét nghiệm", path: "/settings", roles: ["manager", "admin"] },
];

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 280;
const MIN_WIDTH = 200;
const MAX_WIDTH = 480;

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });
  const { loading, user } = useAuth();

  // LUÔN GỌI TẤT CẢ HOOK KHÔNG ĐIỀU KIỆN ĐỂ TUÂN THỦ TUYỆT ĐỐI QUY TẮC HOOK CỦA REACT
  const licenseQuery = trpc.license.status.useQuery();
  const activateMutation = trpc.license.activate.useMutation({
    onSuccess: () => {
      toast.success("Kích hoạt bản quyền thành công!");
      window.location.reload();
    },
    onError: (err) => {
      toast.error(err.message || "Mã bản quyền không hợp lệ");
    },
  });

  const [licenseKeyInput, setLicenseKeyInput] = useState("");
  const [hospitalInput, setHospitalInput] = useState("");
  const [activatorInput, setActivatorInput] = useState("");

  useEffect(() => {
    localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString());
  }, [sidebarWidth]);

  // Các nhánh return sớm ĐẶT SAU KHI ĐÃ GỌI TOÀN BỘ HOOK
  if (loading) {
    return <DashboardLayoutSkeleton />;
  }

  if (!user && !licenseQuery.data?.activated) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#f5f9f9] px-4">
        <div className="flex flex-col items-center gap-6 p-8 max-w-lg w-full bg-white rounded-3xl shadow-[0_20px_50px_rgba(20,49,74,0.1)] border border-[#edf3f3]">
          <div className="flex flex-col items-center text-center gap-3">
            <div className="flex h-24 w-24 items-center justify-center overflow-hidden rounded-2xl bg-white p-2 shadow-sm ring-1 ring-[#dcebea]">
              <img src={DEFAULT_LAB_LOGO_DATA_URL} alt={DEFAULT_LAB_LOGO_ALT} className="h-full w-full object-contain" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-[#14314a]">
              Kích hoạt IQC Lab by ThinhXu
            </h1>
            <p className="text-sm text-muted-foreground max-w-sm">
              Phần mềm nội kiểm xét nghiệm chạy offline. Vui lòng nhập mã bản quyền được cấp để kích hoạt sử dụng vĩnh viễn trên máy tính này (chỉ cần nhập 1 lần duy nhất).
            </p>
          </div>

          <div className="w-full space-y-4">
            <div className="space-y-2 text-left">
              <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Mã bản quyền (License Key)</label>
              <Input
                value={licenseKeyInput}
                onChange={(e) => setLicenseKeyInput(e.target.value)}
                className="h-11 rounded-xl font-mono text-sm"
              />
            </div>

            <div className="space-y-2 text-left">
              <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Tên phòng xét nghiệm / Cơ sở y tế</label>
              <Input
                value={hospitalInput}
                onChange={(e) => setHospitalInput(e.target.value)}
                placeholder="VD: Khoa Xét nghiệm - BVĐK"
                className="h-11 rounded-xl text-sm"
              />
            </div>

            <div className="space-y-2 text-left">
              <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Người kích hoạt / Phụ trách</label>
              <Input
                value={activatorInput}
                onChange={(e) => setActivatorInput(e.target.value)}
                placeholder="VD: BS. Cường Thịnh"
                className="h-11 rounded-xl text-sm"
              />
            </div>

            <Button
              onClick={() => activateMutation.mutate({ licenseKey: licenseKeyInput, hospitalName: hospitalInput, activatedBy: activatorInput })}
              disabled={activateMutation.isPending}
              size="lg"
              className="w-full h-12 rounded-xl bg-[#14314a] text-white shadow-lg shadow-[#14314a]/20 hover:bg-[#214a67]"
            >
              {activateMutation.isPending ? "Đang xác thực bản quyền..." : "Kích hoạt phần mềm"}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <SidebarProvider
      style={
        {
          "--sidebar-width": `${sidebarWidth}px`,
        } as CSSProperties
      }
    >
      <DashboardLayoutContent setSidebarWidth={setSidebarWidth}>
        {children}
      </DashboardLayoutContent>
    </SidebarProvider>
  );
}

type DashboardLayoutContentProps = {
  children: React.ReactNode;
  setSidebarWidth: (width: number) => void;
};

function DashboardLayoutContent({
  children,
  setSidebarWidth,
}: DashboardLayoutContentProps) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const settingsQuery = trpc.settings.get.useQuery(undefined, { enabled: Boolean(user), staleTime: 60_000 });
  const visibleMenuItems = menuItems.filter((item) => !item.roles || item.roles.includes(user?.role ?? ""));
  const activeMenuItem = visibleMenuItems.find(item => item.path === location);
  const isMobile = useIsMobile();
  const displayedLogoUrl = settingsQuery.data?.logoUrl || DEFAULT_LAB_LOGO_DATA_URL;

  useEffect(() => {
    if (isCollapsed) {
      setIsResizing(false);
    }
  }, [isCollapsed]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;

      const sidebarLeft = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const newWidth = e.clientX - sidebarLeft;
      if (newWidth >= MIN_WIDTH && newWidth <= MAX_WIDTH) {
        setSidebarWidth(newWidth);
      }
    };

    const handleMouseUp = () => {
      setIsResizing(false);
    };

    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }

    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  return (
    <>
      <div className="relative" ref={sidebarRef}>
        <Sidebar
          collapsible="icon"
          className="border-r-0"
          disableTransition={isResizing}
        >
          <SidebarHeader className="h-16 justify-center">
            <div className="flex items-center gap-3 px-2 transition-all w-full">
              <button
                onClick={toggleSidebar}
                className="h-8 w-8 flex items-center justify-center hover:bg-accent rounded-lg transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-ring shrink-0"
                aria-label="Toggle navigation"
              >
                <PanelLeft className="h-4 w-4 text-muted-foreground" />
              </button>
              {!isCollapsed ? (
                <div className="flex items-center gap-2 min-w-0">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-white text-primary shadow-sm ring-1 ring-[#dcebea]">
                    <img src={displayedLogoUrl} alt={DEFAULT_LAB_LOGO_ALT} className="h-full w-full object-contain" />
                  </div>
                  <span className="font-semibold tracking-tight truncate text-[13px]">
                    IQC Lab by ThinhXu
                  </span>
                </div>
              ) : null}
            </div>
          </SidebarHeader>

          <SidebarContent className="gap-0">
            <SidebarMenu className="px-2 py-1">
              {visibleMenuItems.map(item => {
                const isActive = location === item.path;
                return (
                  <SidebarMenuItem key={item.path}>
                    <SidebarMenuButton
                      isActive={isActive}
                      onClick={() => setLocation(item.path)}
                      tooltip={item.label}
                      className={`h-10 transition-all font-normal`}
                    >
                      <item.icon
                        className={`h-4 w-4 ${isActive ? "text-primary" : ""}`}
                      />
                      <span>{item.label}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarContent>

          <SidebarFooter className="p-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-3 rounded-lg px-1 py-1 hover:bg-accent/50 transition-colors w-full text-left group-data-[collapsible=icon]:justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                  <Avatar className="h-9 w-9 border shrink-0">
                    <AvatarFallback className="text-xs font-medium">
                      {user?.name?.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0 group-data-[collapsible=icon]:hidden">
                    <p className="text-sm font-medium truncate leading-none">
                      {user?.name || "-"}
                    </p>
                    <p className="text-xs text-muted-foreground truncate mt-1.5">
                      {user?.email || "Tài khoản phòng xét nghiệm"}
                    </p>
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem
                  onClick={logout}
                  className="cursor-pointer text-destructive focus:text-destructive"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Sign out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarFooter>
        </Sidebar>
        <div
          className={`absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-primary/20 transition-colors ${isCollapsed ? "hidden" : ""}`}
          onMouseDown={() => {
            if (isCollapsed) return;
            setIsResizing(true);
          }}
          style={{ zIndex: 50 }}
        />
      </div>

      <SidebarInset>
        {isMobile && (
          <div className="flex border-b h-14 items-center justify-between bg-background/95 px-2 backdrop-blur supports-[backdrop-filter]:backdrop-blur sticky top-0 z-40">
            <div className="flex items-center gap-2">
              <SidebarTrigger className="h-9 w-9 rounded-lg bg-background" />
              <div className="flex items-center gap-3">
                <div className="flex flex-col gap-1">
                  <span className="tracking-tight text-foreground font-medium">
                    {activeMenuItem?.label ?? "Tổng quan"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
        <main className="flex-1 p-4">
          <UpdateBanner />
          {children}
        </main>
      </SidebarInset>
    </>
  );
}
