import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";

describe("Copyright Information Test", () => {
  it("should contain copyright text 'Bản quyền thuộc về ThinhXuQB - 0855 703 123' in SettingsPage.tsx", () => {
    const filePath = path.join(process.cwd(), "client/src/pages/SettingsPage.tsx");
    const content = fs.readFileSync(filePath, "utf-8");
    expect(content).toContain("Bản quyền thuộc về ThinhXuQB - 0855 703 123");
  });
});
