import { useEffect, useMemo, useState } from "react";
import { Activity, Cable, Check, CircleAlert, CircleStop, FileCog, Link2, Network, PlugZap, Radio, RefreshCw, Save, Server, Trash2, Unplug } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const defaultConfig = {
  name: "",
  enabled: 0,
  connectionType: "tcp" as "tcp" | "serial",
  protocol: "delimited" as "delimited" | "hl7" | "astm",
  host: "",
  port: "5000",
  serialPort: "COM1",
  baudRate: "9600",
  dataBits: "8",
  stopBits: "1",
  parity: "none" as "none" | "even" | "odd",
  delimiter: "\\n",
  codeFieldIndex: "0",
  valueFieldIndex: "1",
  receiveTimeoutMs: "1000",
};

type ConfigForm = typeof defaultConfig;
type ConfigRow = {
  id: number;
  name: string;
  enabled: number;
  connectionType: "tcp" | "serial";
  protocol: "delimited" | "hl7" | "astm";
  host: string | null;
  port: number | null;
  serialPort: string | null;
  baudRate: number | null;
  dataBits: number;
  stopBits: number;
  parity: "none" | "even" | "odd";
  delimiter: string;
  codeFieldIndex: number;
  valueFieldIndex: number;
  receiveTimeoutMs: number;
  createdAt: Date;
  updatedAt: Date;
};

type MappingRow = {
  mapping: { id: number; configId: number; instrumentCode: string; testId: number; controlMaterialId: number; enabled: number };
  test: { id: number; code: string; name: string; unit: string };
  material: { id: number; name: string; lotNumber: string; level: string; targetMean: number; targetSd: number };
};

function numberOrNull(value: string) {
  const number = Number(value);
  return Number.isFinite(number) && value.trim() !== "" ? number : null;
}

function statusLabel(status: string) {
  return {
    stopped: "Đã dừng",
    connecting: "Đang kết nối",
    connected: "Đang nhận dữ liệu",
    error: "Lỗi kết nối",
  }[status] ?? status;
}

function statusClass(status: string) {
  return status === "connected"
    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
    : status === "error"
      ? "border-rose-200 bg-rose-50 text-rose-700"
      : status === "connecting"
        ? "border-amber-200 bg-amber-50 text-amber-700"
        : "border-slate-200 bg-slate-50 text-slate-600";
}

function logStatusLabel(status: string) {
  return { imported: "Đã nhập QC", duplicate: "Trùng", unmapped: "Chưa mapping", error: "Lỗi", received: "Đã nhận" }[status] ?? status;
}

function logStatusClass(status: string) {
  return status === "imported"
    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
    : status === "duplicate"
      ? "border-amber-200 bg-amber-50 text-amber-700"
      : status === "unmapped" || status === "error"
        ? "border-rose-200 bg-rose-50 text-rose-700"
        : "border-slate-200 bg-slate-50 text-slate-600";
}

function dateLabel(value: Date | string | null | undefined) {
  return value ? new Date(value).toLocaleString("vi-VN", { dateStyle: "short", timeStyle: "medium" }) : "—";
}

function Field({ label, value, onChange, placeholder, type = "text" }: { label: string; value: string; onChange: (value: string) => void; placeholder?: string; type?: string }) {
  return <div className="space-y-2"><Label className="text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">{label}</Label><Input type={type} value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} className="h-10 rounded-xl border-[#dcebea] bg-white" /></div>;
}

export default function InstrumentInterfacePage() {
  const { user } = useAuth();
  const isManager = user?.role === "manager" || user?.role === "admin";
  const configsQuery = trpc.instrument.configs.list.useQuery(undefined, { enabled: Boolean(user) });
  const testsQuery = trpc.tests.list.useQuery(undefined, { enabled: Boolean(user) });
  const materialsQuery = trpc.materials.list.useQuery(undefined, { enabled: Boolean(user) });
  const runtimeQuery = trpc.instrument.runtime.status.useQuery(undefined, { enabled: Boolean(user), refetchInterval: 2000 });
  const [form, setForm] = useState<ConfigForm>(defaultConfig);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [selectedConfigId, setSelectedConfigId] = useState<number | null>(null);
  const [mappingCode, setMappingCode] = useState("");
  const [mappingTestId, setMappingTestId] = useState("");
  const [mappingMaterialId, setMappingMaterialId] = useState("");
  const utils = trpc.useUtils();
  const saveConfigMutation = trpc.instrument.configs.create.useMutation();
  const updateConfigMutation = trpc.instrument.configs.update.useMutation();
  const deleteConfigMutation = trpc.instrument.configs.delete.useMutation();
  const createMappingMutation = trpc.instrument.mappings.create.useMutation();
  const deleteMappingMutation = trpc.instrument.mappings.delete.useMutation();
  const connectMutation = trpc.instrument.runtime.connect.useMutation();
  const disconnectMutation = trpc.instrument.runtime.disconnect.useMutation();
  const testMutation = trpc.instrument.runtime.test.useMutation();

  const configs = (configsQuery.data ?? []) as ConfigRow[];
  const activeConfigId = selectedConfigId ?? configs[0]?.id ?? null;
  const mappingsQuery = trpc.instrument.mappings.list.useQuery({ configId: activeConfigId ?? undefined }, { enabled: Boolean(user && activeConfigId) });
  const logsQuery = trpc.instrument.logs.list.useQuery({ configId: activeConfigId ?? undefined, limit: 100 }, { enabled: Boolean(user), refetchInterval: 3000 });
  const runtimeState = runtimeQuery.data?.find((state) => state.configId === activeConfigId);
  const selectedConfig = configs.find((config) => config.id === activeConfigId);
  const materials = (materialsQuery.data ?? []) as Array<{ material: { id: number; name: string; lotNumber: string; level: string }; test: { id: number; name: string } }>;
  const tests = (testsQuery.data ?? []) as Array<{ id: number; code: string; name: string; unit: string }>;
  const selectedTestId = Number(mappingTestId) || 0;
  const materialsForTest = useMemo(() => materials.filter((row) => row.test.id === selectedTestId), [materials, selectedTestId]);

  useEffect(() => {
    if (!activeConfigId || editingId !== null) return;
    const config = configs.find((item) => item.id === activeConfigId);
    if (config) setForm({ ...defaultConfig, ...config, host: config.host ?? "", port: config.port?.toString() ?? "", serialPort: config.serialPort ?? "", baudRate: config.baudRate?.toString() ?? "", dataBits: config.dataBits.toString(), stopBits: config.stopBits.toString(), delimiter: config.delimiter, codeFieldIndex: config.codeFieldIndex.toString(), valueFieldIndex: config.valueFieldIndex.toString(), receiveTimeoutMs: config.receiveTimeoutMs.toString() });
  }, [activeConfigId, configs, editingId]);

  const refresh = async () => {
    await Promise.all([utils.instrument.configs.list.invalidate(), utils.instrument.mappings.list.invalidate(), utils.instrument.logs.list.invalidate(), utils.instrument.runtime.status.invalidate()]);
  };

  if (!isManager) {
    return <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center bg-[#f5f9f9] p-6"><Card className="max-w-md border-0 shadow-[0_12px_35px_rgba(20,49,74,0.08)]"><CardContent className="space-y-3 p-8 text-center"><Cable className="mx-auto h-10 w-10 text-primary" /><h1 className="text-xl font-semibold text-[#14314a]">Không có quyền cấu hình Interface</h1><p className="text-sm leading-6 text-muted-foreground">Chỉ quản lý hoặc quản trị viên mới được khai báo kết nối và mapping dữ liệu máy xét nghiệm.</p></CardContent></Card></div>;
  }

  const setField = (key: keyof ConfigForm, value: string) => setForm((current) => ({ ...current, [key]: value }));
  const startNew = () => { setEditingId(null); setForm(defaultConfig); setSelectedConfigId(null); };
  const editConfig = (config: ConfigRow) => {
    setEditingId(config.id);
    setSelectedConfigId(config.id);
    setForm({ ...defaultConfig, ...config, host: config.host ?? "", port: config.port?.toString() ?? "", serialPort: config.serialPort ?? "", baudRate: config.baudRate?.toString() ?? "", dataBits: config.dataBits.toString(), stopBits: config.stopBits.toString(), delimiter: config.delimiter, codeFieldIndex: config.codeFieldIndex.toString(), valueFieldIndex: config.valueFieldIndex.toString(), receiveTimeoutMs: config.receiveTimeoutMs.toString() });
  };
  const saveConfig = async () => {
    if (!form.name.trim()) return toast.error("Vui lòng đặt tên cho cấu hình máy.");
    if (form.connectionType === "tcp" && (!form.host.trim() || !numberOrNull(form.port))) return toast.error("TCP/IP cần địa chỉ IP và cổng hợp lệ.");
    if (form.connectionType === "serial" && (!form.serialPort.trim() || !numberOrNull(form.baudRate))) return toast.error("COM/RS-232 cần cổng COM và Baud Rate hợp lệ.");
    const payload = { name: form.name.trim(), enabled: form.enabled, connectionType: form.connectionType, protocol: form.protocol, host: form.connectionType === "tcp" ? form.host.trim() : null, port: form.connectionType === "tcp" ? numberOrNull(form.port) : null, serialPort: form.connectionType === "serial" ? form.serialPort.trim() : null, baudRate: form.connectionType === "serial" ? numberOrNull(form.baudRate) : null, dataBits: Number(form.dataBits), stopBits: Number(form.stopBits), parity: form.parity, delimiter: form.delimiter, codeFieldIndex: Number(form.codeFieldIndex), valueFieldIndex: Number(form.valueFieldIndex), receiveTimeoutMs: Number(form.receiveTimeoutMs) };
    try {
      const result = editingId ? await updateConfigMutation.mutateAsync({ id: editingId, data: payload }) : await saveConfigMutation.mutateAsync(payload);
      if (!editingId && result?.id) setSelectedConfigId(result.id);
      await refresh();
      toast.success(editingId ? "Đã cập nhật cấu hình interface." : "Đã thêm cấu hình máy xét nghiệm.");
    } catch (error) { toast.error(error instanceof Error ? error.message : "Không thể lưu cấu hình interface."); }
  };
  const removeConfig = async (id: number) => {
    if (!confirm("Xóa cấu hình này sẽ xóa cả mapping và nhật ký nhận dữ liệu của máy. Bạn có chắc chắn muốn tiếp tục?")) return;
    try { await deleteConfigMutation.mutateAsync({ id }); if (selectedConfigId === id) startNew(); await refresh(); toast.success("Đã xóa cấu hình interface."); } catch (error) { toast.error(error instanceof Error ? error.message : "Không thể xóa cấu hình."); }
  };
  const toggleConnection = async (config: ConfigRow) => {
    try { const state = runtimeState?.status === "connected" || runtimeState?.status === "connecting" ? await disconnectMutation.mutateAsync({ id: config.id }) : await connectMutation.mutateAsync({ id: config.id }); await runtimeQuery.refetch(); toast.success(state?.message || "Đã cập nhật trạng thái kết nối."); } catch (error) { toast.error(error instanceof Error ? error.message : "Không thể thay đổi kết nối."); }
  };
  const testConnection = async (id: number) => {
    try { const state = await testMutation.mutateAsync({ id }); await runtimeQuery.refetch(); toast.info(state?.message || "Đã kiểm tra kết nối."); } catch (error) { toast.error(error instanceof Error ? error.message : "Kiểm tra kết nối thất bại."); }
  };
  const addMapping = async () => {
    if (!activeConfigId || !mappingCode.trim() || !selectedTestId || !Number(mappingMaterialId)) return toast.error("Chọn máy, nhập mã máy, xét nghiệm và vật liệu nội kiểm.");
    try { await createMappingMutation.mutateAsync({ configId: activeConfigId, instrumentCode: mappingCode.trim().toUpperCase(), testId: selectedTestId, controlMaterialId: Number(mappingMaterialId), enabled: 1 }); setMappingCode(""); setMappingTestId(""); setMappingMaterialId(""); await refresh(); toast.success("Đã thêm mapping mã máy → vật liệu nội kiểm."); } catch (error) { toast.error(error instanceof Error ? error.message : "Không thể thêm mapping."); }
  };
  const removeMapping = async (id: number) => { try { await deleteMappingMutation.mutateAsync({ id }); await refresh(); toast.success("Đã xóa mapping."); } catch (error) { toast.error(error instanceof Error ? error.message : "Không thể xóa mapping."); } };

  return <div className="min-h-[calc(100vh-2rem)] bg-[#f5f9f9] px-1 py-1 sm:px-3 lg:px-6"><div className="mx-auto max-w-[1440px] space-y-6 py-4">
    <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between"><div><div className="mb-2 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary/80"><span className="h-1.5 w-1.5 rounded-full bg-primary" />Instrument interface · 09</div><h1 className="text-3xl font-semibold tracking-[-0.03em] text-[#14314a] md:text-4xl">Interface máy xét nghiệm</h1><p className="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">Nhận kết quả tự động qua TCP/IP hoặc COM/RS-232, chuẩn hóa HL7/ASTM/delimited và chỉ nhập QC khi mapping đã được kiểm soát.</p></div><div className="flex gap-2"><Button variant="outline" onClick={startNew} className="gap-2 rounded-xl border-[#cddfe2] bg-white"><FileCog className="h-4 w-4" />Cấu hình mới</Button><Button variant="outline" onClick={() => refresh()} className="gap-2 rounded-xl border-[#cddfe2] bg-white"><RefreshCw className="h-4 w-4" />Làm mới</Button></div></div>

    <div className="grid gap-5 xl:grid-cols-[1.1fr_0.9fr]"><Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="border-b border-[#edf3f3] pb-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#e9f5f3] p-2.5 text-primary"><Cable className="h-5 w-5" /></div><div><CardTitle className="text-base text-[#14314a]">{editingId ? "Chỉnh sửa cấu hình" : "Khai báo máy xét nghiệm"}</CardTitle><p className="mt-1 text-xs text-muted-foreground">Thông số kết nối chỉ có hiệu lực trên máy đang chạy IQC Lab.</p></div></div></CardHeader><CardContent className="space-y-5 p-5"><div className="grid gap-4 sm:grid-cols-2"><Field label="Tên cấu hình *" value={form.name} onChange={(value) => setField("name", value)} placeholder="VD: Cobas c311 - Sinh hóa" /><div className="space-y-2"><Label className="text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">Kiểu kết nối</Label><Select value={form.connectionType} onValueChange={(value) => setField("connectionType", value)}><SelectTrigger className="h-10 rounded-xl border-[#dcebea] bg-white"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="tcp">TCP/IP · Ethernet</SelectItem><SelectItem value="serial">COM/RS-232</SelectItem></SelectContent></Select></div></div><div className="grid gap-4 sm:grid-cols-3"><div className="space-y-2"><Label className="text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">Giao thức</Label><Select value={form.protocol} onValueChange={(value) => setField("protocol", value)}><SelectTrigger className="h-10 rounded-xl border-[#dcebea] bg-white"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="delimited">Delimited · CSV/Tab</SelectItem><SelectItem value="hl7">HL7 v2.x / MLLP</SelectItem><SelectItem value="astm">ASTM E1381/E1394</SelectItem></SelectContent></Select></div>{form.connectionType === "tcp" ? <><Field label="Địa chỉ IP / Host *" value={form.host} onChange={(value) => setField("host", value)} placeholder="192.168.1.50" /><Field label="Cổng TCP *" value={form.port} onChange={(value) => setField("port", value)} placeholder="5000" type="number" /></> : <><Field label="Cổng COM *" value={form.serialPort} onChange={(value) => setField("serialPort", value)} placeholder="COM3 hoặc /dev/ttyUSB0" /><Field label="Baud Rate *" value={form.baudRate} onChange={(value) => setField("baudRate", value)} placeholder="9600" type="number" /></>}</div><div className="grid gap-4 sm:grid-cols-4"><Field label="Data bits" value={form.dataBits} onChange={(value) => setField("dataBits", value)} type="number" /><Field label="Stop bits" value={form.stopBits} onChange={(value) => setField("stopBits", value)} type="number" /><div className="space-y-2"><Label className="text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">Parity</Label><Select value={form.parity} onValueChange={(value) => setField("parity", value)}><SelectTrigger className="h-10 rounded-xl border-[#dcebea] bg-white"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="none">None</SelectItem><SelectItem value="even">Even</SelectItem><SelectItem value="odd">Odd</SelectItem></SelectContent></Select></div><Field label="Timeout (ms)" value={form.receiveTimeoutMs} onChange={(value) => setField("receiveTimeoutMs", value)} type="number" /></div><div className="grid gap-4 sm:grid-cols-3"><Field label="Delimiter" value={form.delimiter} onChange={(value) => setField("delimiter", value)} placeholder="\\n" /><Field label="Cột mã xét nghiệm" value={form.codeFieldIndex} onChange={(value) => setField("codeFieldIndex", value)} type="number" /><Field label="Cột giá trị" value={form.valueFieldIndex} onChange={(value) => setField("valueFieldIndex", value)} type="number" /></div><div className="flex flex-col gap-3 rounded-2xl border border-[#dcebea] bg-[#f8fbfb] p-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-sm font-semibold text-[#14314a]">Tự động kết nối khi mở phần mềm</p><p className="mt-1 text-xs text-muted-foreground">Chỉ nên bật sau khi đã thử kết nối và xác nhận đúng protocol.</p></div><Button type="button" variant={form.enabled === 1 ? "default" : "outline"} onClick={() => setForm((current) => ({ ...current, enabled: current.enabled === 1 ? 0 : 1 }))} className="rounded-xl">{form.enabled === 1 ? "Đang bật" : "Đang tắt"}</Button></div><div className="flex justify-end gap-2"><Button variant="outline" onClick={startNew} className="rounded-xl">Xóa form</Button><Button onClick={saveConfig} disabled={saveConfigMutation.isPending || updateConfigMutation.isPending} className="gap-2 rounded-xl bg-[#14314a] hover:bg-[#214a67]"><Save className="h-4 w-4" />{editingId ? "Lưu thay đổi" : "Thêm cấu hình"}</Button></div></CardContent></Card>

      <Card className="border-0 bg-[#14314a] text-white shadow-[0_10px_30px_rgba(20,49,74,0.16)]"><CardHeader><div className="flex items-center justify-between"><CardTitle className="text-base font-medium">Trạng thái kết nối</CardTitle><Activity className="h-5 w-5 text-[#72d4bf]" /></div><p className="text-xs text-white/55">Theo dõi runtime trên máy đang chạy IQC Lab.</p></CardHeader><CardContent className="space-y-4">{configs.length ? configs.map((config) => { const state = runtimeQuery.data?.find((item) => item.configId === config.id); const connected = state?.status === "connected"; return <div key={config.id} className="rounded-2xl border border-white/10 bg-white/5 p-4"><div className="flex items-start justify-between gap-3"><div className="flex min-w-0 items-center gap-3"><div className={`rounded-xl p-2 ${connected ? "bg-[#72d4bf]/15 text-[#72d4bf]" : "bg-white/10 text-white/60"}`}>{config.connectionType === "tcp" ? <Network className="h-5 w-5" /> : <PlugZap className="h-5 w-5" />}</div><div className="min-w-0"><p className="truncate font-medium">{config.name}</p><p className="mt-1 truncate text-xs text-white/50">{config.connectionType === "tcp" ? `${config.host}:${config.port}` : `${config.serialPort} · ${config.baudRate} baud`} · {config.protocol.toUpperCase()}</p></div></div><Badge variant="outline" className={`shrink-0 ${connected ? "border-[#72d4bf]/40 bg-[#72d4bf]/10 text-[#bde8df]" : "border-white/15 bg-transparent text-white/60"}`}>{connected ? "Đã kết nối" : statusLabel(state?.status ?? "stopped")}</Badge></div><p className="mt-3 text-xs leading-5 text-white/60">{state?.message ?? "Chưa khởi động kết nối."}</p><div className="mt-4 flex flex-wrap gap-2"><Button size="sm" onClick={() => toggleConnection(config)} className="gap-2 rounded-lg bg-[#72d4bf] text-[#14314a] hover:bg-[#8be1cf]">{connected ? <><Unplug className="h-3.5 w-3.5" />Ngắt kết nối</> : <><Radio className="h-3.5 w-3.5" />Kết nối</>}</Button><Button size="sm" variant="outline" onClick={() => testConnection(config.id)} className="gap-2 rounded-lg border-white/15 bg-transparent text-white hover:bg-white/10 hover:text-white"><Check className="h-3.5 w-3.5" />Thử kết nối</Button><Button size="sm" variant="ghost" onClick={() => editConfig(config)} className="rounded-lg text-white/70 hover:bg-white/10 hover:text-white">Chỉnh sửa</Button></div>{state?.lastMessageAt ? <p className="mt-3 text-[11px] text-white/40">Frame gần nhất: {dateLabel(state.lastMessageAt)}</p> : null}</div>; }) : <div className="rounded-2xl border border-dashed border-white/15 p-6 text-center"><Server className="mx-auto h-8 w-8 text-white/35" /><p className="mt-3 text-sm text-white/70">Chưa có máy nào được khai báo.</p><p className="mt-1 text-xs text-white/45">Tạo cấu hình bên trái để bắt đầu.</p></div>}<div className="rounded-2xl border border-[#f7e5b8]/20 bg-[#f7e5b8]/10 p-4 text-xs leading-5 text-[#f7e5b8]"><CircleAlert className="mr-2 inline h-4 w-4" />Không bật tự động nhập nếu chưa có tài liệu protocol của đúng model máy. Mã xét nghiệm và vật liệu nội kiểm phải được mapping trước.</div></CardContent></Card></div>

    <Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="border-b border-[#edf3f3] pb-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#eef4fb] p-2.5 text-[#3b6e95]"><Link2 className="h-5 w-5" /></div><div><CardTitle className="text-base text-[#14314a]">Mapping mã máy → xét nghiệm & vật liệu nội kiểm</CardTitle><p className="mt-1 text-xs text-muted-foreground">Mỗi mã máy phải trỏ chính xác đến một xét nghiệm và một lô/mức nội kiểm trước khi tự động ghi kết quả.</p></div></div></CardHeader><CardContent className="space-y-5 p-5"><div className="grid gap-4 lg:grid-cols-[1fr_1fr_1fr_0.7fr_auto]"><div className="space-y-2"><Label className="text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">Máy đang chọn</Label><Select value={activeConfigId?.toString() ?? ""} onValueChange={(value) => { setSelectedConfigId(Number(value)); setEditingId(null); }}><SelectTrigger className="h-10 rounded-xl border-[#dcebea] bg-white"><SelectValue placeholder="Chọn cấu hình" /></SelectTrigger><SelectContent>{configs.map((config) => <SelectItem key={config.id} value={config.id.toString()}>{config.name}</SelectItem>)}</SelectContent></Select></div><Field label="Mã xét nghiệm trên máy" value={mappingCode} onChange={setMappingCode} placeholder="VD: GLU, 001, ^GLU^" /><div className="space-y-2"><Label className="text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">Xét nghiệm nội bộ</Label><Select value={mappingTestId} onValueChange={(value) => { setMappingTestId(value); setMappingMaterialId(""); }}><SelectTrigger className="h-10 rounded-xl border-[#dcebea] bg-white"><SelectValue placeholder="Chọn xét nghiệm" /></SelectTrigger><SelectContent>{tests.map((test) => <SelectItem key={test.id} value={test.id.toString()}>{test.code} · {test.name}</SelectItem>)}</SelectContent></Select></div><div className="space-y-2"><Label className="text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">Vật liệu / mức</Label><Select value={mappingMaterialId} onValueChange={setMappingMaterialId}><SelectTrigger className="h-10 rounded-xl border-[#dcebea] bg-white"><SelectValue placeholder="Chọn vật liệu" /></SelectTrigger><SelectContent>{materialsForTest.map((row) => <SelectItem key={row.material.id} value={row.material.id.toString()}>{row.material.level} · Lot {row.material.lotNumber}</SelectItem>)}</SelectContent></Select></div><Button onClick={addMapping} disabled={createMappingMutation.isPending || !activeConfigId} className="h-10 self-end gap-2 rounded-xl bg-[#14314a] hover:bg-[#214a67)"><Save className="h-4 w-4" />Thêm</Button></div>{!selectedConfig ? <div className="rounded-2xl border border-dashed border-[#cddfe2] bg-[#fbfdfd] p-8 text-center text-sm text-muted-foreground">Chọn hoặc tạo cấu hình máy để khai báo mapping.</div> : mappingsQuery.data?.length ? <div className="overflow-x-auto rounded-2xl border border-[#edf3f3]"><Table><TableHeader><TableRow><TableHead>Mã máy</TableHead><TableHead>Xét nghiệm nội bộ</TableHead><TableHead>Vật liệu / mức</TableHead><TableHead>Mean ± SD</TableHead><TableHead className="text-right">Thao tác</TableHead></TableRow></TableHeader><TableBody>{(mappingsQuery.data as MappingRow[]).map((row) => <TableRow key={row.mapping.id}><TableCell className="font-mono text-sm font-semibold text-[#14314a]">{row.mapping.instrumentCode}</TableCell><TableCell><p className="font-medium text-[#18364b]">{row.test.name}</p><p className="text-xs text-muted-foreground">{row.test.code} · {row.test.unit}</p></TableCell><TableCell>{row.material.level}<p className="text-xs text-muted-foreground">Lot {row.material.lotNumber}</p></TableCell><TableCell className="font-mono text-xs">{row.material.targetMean} ± {row.material.targetSd}</TableCell><TableCell className="text-right"><Button variant="ghost" size="icon" onClick={() => removeMapping(row.mapping.id)} className="h-8 w-8 text-rose-600 hover:bg-rose-50"><Trash2 className="h-4 w-4" /></Button></TableCell></TableRow>)}</TableBody></Table></div> : <div className="rounded-2xl border border-dashed border-[#cddfe2] bg-[#fbfdfd] p-8 text-center text-sm text-muted-foreground">Chưa có mapping cho máy này.</div>}</CardContent></Card>

    <Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="flex flex-row items-start justify-between space-y-0 border-b border-[#edf3f3] pb-5"><div><div className="flex items-center gap-3"><div className="rounded-xl bg-[#fff5df] p-2.5 text-[#a16b18]"><Activity className="h-5 w-5" /></div><div><CardTitle className="text-base text-[#14314a]">Nhật ký dữ liệu nhận vào</CardTitle><p className="mt-1 text-xs text-muted-foreground">Tự làm mới mỗi 3 giây · lưu tối đa 100 frame gần nhất trong bộ lọc hiện tại.</p></div></div></div><Badge variant="outline" className="gap-2 rounded-full border-[#bde8df] bg-[#e9f5f3] text-primary"><span className="h-1.5 w-1.5 rounded-full bg-primary" />Live monitor</Badge></CardHeader><CardContent className="p-0">{logsQuery.data?.length ? <div className="overflow-x-auto"><Table><TableHeader><TableRow><TableHead className="pl-5">Thời gian</TableHead><TableHead>Protocol</TableHead><TableHead>Frame nhận được</TableHead><TableHead>Trạng thái</TableHead><TableHead className="pr-5">Chi tiết</TableHead></TableRow></TableHeader><TableBody>{logsQuery.data.map((log) => <TableRow key={log.id}><TableCell className="whitespace-nowrap pl-5 text-xs text-muted-foreground">{dateLabel(log.receivedAt)}</TableCell><TableCell><Badge variant="outline" className="font-mono text-[10px]">{log.protocol.toUpperCase()}</Badge></TableCell><TableCell className="max-w-[390px]"><code className="block truncate rounded-lg bg-[#f8fbfb] px-2 py-1 text-xs text-[#31556a]" title={log.rawText}>{log.rawText || "(frame đã nhận)"}</code></TableCell><TableCell><Badge variant="outline" className={logStatusClass(log.parseStatus)}>{logStatusLabel(log.parseStatus)}</Badge></TableCell><TableCell className="max-w-[320px] pr-5 text-xs text-muted-foreground">{log.errorMessage || (log.resultId ? `Đã tạo kết quả QC #${log.resultId}` : "—")}</TableCell></TableRow>)}</TableBody></Table></div> : <div className="flex flex-col items-center justify-center px-6 py-12 text-center"><CircleStop className="h-8 w-8 text-[#cddfe2]" /><p className="mt-3 text-sm font-medium text-[#31556a]">Chưa có frame dữ liệu</p><p className="mt-1 max-w-md text-xs leading-5 text-muted-foreground">Khi máy gửi dữ liệu, frame gốc và trạng thái parse sẽ xuất hiện tại đây để dễ đối chiếu protocol.</p></div>}</CardContent></Card>
  </div></div>;
}
