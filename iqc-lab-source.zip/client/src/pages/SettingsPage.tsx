import { useEffect, useMemo, useRef, useState } from "react";
import { Building2, Check, ImagePlus, Mail, Phone, Save, ShieldCheck, Upload, Users } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";

const roleLabels = {
  user: "Người dùng",
  technician: "Kỹ thuật viên",
  manager: "Quản lý",
  admin: "Quản trị viên",
} as const;

type SettingsForm = {
  labName: string;
  hospitalName: string;
  address: string;
  managerName: string;
  chiefTechnician: string;
  logoUrl: string;
  phone: string;
  email: string;
};

const emptyForm: SettingsForm = {
  labName: "",
  hospitalName: "",
  address: "",
  managerName: "",
  chiefTechnician: "",
  logoUrl: "",
  phone: "",
  email: "",
};

function Field({ label, value, onChange, placeholder, type = "text" }: { label: string; value: string; onChange: (value: string) => void; placeholder?: string; type?: string }) {
  return (
    <div className="space-y-2">
      <Label className="text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">{label}</Label>
      <Input type={type} value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} className="h-10 rounded-xl border-[#dcebea] bg-white" />
    </div>
  );
}

export default function SettingsPage() {
  const { user } = useAuth();
  const isManager = user?.role === "manager" || user?.role === "admin";
  const isAdmin = user?.role === "admin";
  const settingsQuery = trpc.settings.get.useQuery(undefined, { enabled: Boolean(user) });
  const usersQuery = trpc.users.list.useQuery(undefined, { enabled: isAdmin });
  const saveMutation = trpc.settings.update.useMutation();
  const uploadMutation = trpc.settings.uploadLogo.useMutation();
  const updateRoleMutation = trpc.users.updateRole.useMutation();
  const utils = trpc.useUtils();
  const fileRef = useRef<HTMLInputElement>(null);
  const [form, setForm] = useState<SettingsForm>(emptyForm);

  useEffect(() => {
    if (!settingsQuery.data) return;
    setForm({
      labName: settingsQuery.data.labName ?? "",
      hospitalName: settingsQuery.data.hospitalName ?? "",
      address: settingsQuery.data.address ?? "",
      managerName: settingsQuery.data.managerName ?? "",
      chiefTechnician: settingsQuery.data.chiefTechnician ?? "",
      logoUrl: settingsQuery.data.logoUrl ?? "",
      phone: settingsQuery.data.phone ?? "",
      email: settingsQuery.data.email ?? "",
    });
  }, [settingsQuery.data]);

  const roleOptions = useMemo(() => Object.entries(roleLabels) as Array<[keyof typeof roleLabels, string]>, []);

  if (!isManager) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center bg-[#f5f9f9] p-6">
        <Card className="max-w-md border-0 shadow-[0_12px_35px_rgba(20,49,74,0.08)]"><CardContent className="space-y-3 p-8 text-center"><ShieldCheck className="mx-auto h-10 w-10 text-primary" /><h1 className="text-xl font-semibold text-[#14314a]">Không có quyền truy cập</h1><p className="text-sm leading-6 text-muted-foreground">Chỉ quản lý hoặc quản trị viên mới được thay đổi cấu hình phòng xét nghiệm.</p></CardContent></Card>
      </div>
    );
  }

  const updateField = (key: keyof SettingsForm, value: string) => setForm((current) => ({ ...current, [key]: value }));
  const saveSettings = async () => {
    if (!form.labName.trim()) {
      toast.error("Vui lòng nhập tên phòng xét nghiệm.");
      return;
    }
    try {
      await saveMutation.mutateAsync({ ...form, logoUrl: form.logoUrl || null });
      await utils.settings.get.invalidate();
      toast.success("Đã lưu thông tin phòng xét nghiệm.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Không thể lưu cấu hình.");
    }
  };

  const uploadLogo = (file: File) => {
    const allowed = ["image/png", "image/jpeg", "image/webp", "image/svg+xml"] as const;
    if (!allowed.includes(file.type as (typeof allowed)[number])) {
      toast.error("Logo chỉ hỗ trợ PNG, JPEG, WEBP hoặc SVG.");
      return;
    }
    if (file.size > 4 * 1024 * 1024) {
      toast.error("Dung lượng logo không được vượt quá 4 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = async () => {
      const raw = typeof reader.result === "string" ? reader.result : "";
      const base64 = raw.split(",")[1] ?? "";
      try {
        const saved = await uploadMutation.mutateAsync({ fileName: file.name, contentType: file.type as (typeof allowed)[number], base64 });
        updateField("logoUrl", saved.logoUrl ?? "");
        await utils.settings.get.invalidate();
        await utils.audit.list.invalidate();
        toast.success("Đã cập nhật logo phòng xét nghiệm.");
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Không thể tải logo lên.");
      }
    };
    reader.readAsDataURL(file);
  };

  const changeRole = async (id: number, role: keyof typeof roleLabels) => {
    try {
      await updateRoleMutation.mutateAsync({ id, role });
      await utils.users.list.invalidate();
      await utils.audit.list.invalidate();
      toast.success("Đã cập nhật vai trò người dùng.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Không thể cập nhật vai trò.");
    }
  };

  return (
    <div className="min-h-[calc(100vh-2rem)] bg-[#f5f9f9] px-1 py-1 sm:px-3 lg:px-6">
      <div className="mx-auto max-w-[1280px] space-y-7 py-4">
        <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
          <div><div className="mb-2 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary/80"><span className="h-1.5 w-1.5 rounded-full bg-primary" />Administration · 08</div><h1 className="text-3xl font-semibold tracking-[-0.03em] text-[#14314a] md:text-4xl">Cài đặt phòng xét nghiệm</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">Quản lý nhận diện đơn vị, thông tin liên hệ và cơ chế phân quyền của IQC Lab by ThinhXu.</p></div>
          <Badge variant="outline" className="w-fit gap-2 rounded-full border-[#bde8df] bg-[#e9f5f3] px-3 py-1.5 text-primary"><Check className="h-3.5 w-3.5" />{isAdmin ? "Quản trị viên" : "Quản lý"}</Badge>
        </div>

        <div className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
          <Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="border-b border-[#edf3f3] pb-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#e9f5f3] p-2.5 text-primary"><Building2 className="h-5 w-5" /></div><div><CardTitle className="text-base text-[#14314a]">Thông tin nhận diện</CardTitle><p className="mt-1 text-xs text-muted-foreground">Thông tin này được dùng trên màn hình và các báo cáo nội kiểm.</p></div></div></CardHeader><CardContent className="space-y-5 p-5"><div className="grid gap-4 sm:grid-cols-2"><Field label="Tên phòng xét nghiệm *" value={form.labName} onChange={(value) => updateField("labName", value)} placeholder="VD: Khoa Xét nghiệm" /><Field label="Bệnh viện / cơ sở y tế" value={form.hospitalName} onChange={(value) => updateField("hospitalName", value)} placeholder="VD: Bệnh viện Đa khoa..." /></div><div className="grid gap-4 sm:grid-cols-2"><Field label="Trưởng khoa xét nghiệm" value={form.managerName} onChange={(value) => updateField("managerName", value)} placeholder="Họ và tên" /><Field label="Kỹ thuật trưởng" value={form.chiefTechnician} onChange={(value) => updateField("chiefTechnician", value)} placeholder="Họ và tên" /></div><div className="grid gap-4 sm:grid-cols-2"><Field label="Số điện thoại" value={form.phone} onChange={(value) => updateField("phone", value)} placeholder="Số điện thoại liên hệ" type="tel" /><Field label="Email" value={form.email} onChange={(value) => updateField("email", value)} placeholder="lab@example.org" type="email" /></div><div className="space-y-2"><Label className="text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">Địa chỉ</Label><Textarea value={form.address} onChange={(event) => updateField("address", event.target.value)} placeholder="Địa chỉ phòng xét nghiệm" className="min-h-24 rounded-xl border-[#dcebea] bg-white" /></div><div className="flex justify-end"><Button onClick={saveSettings} disabled={saveMutation.isPending} className="h-10 gap-2 rounded-xl bg-[#14314a] px-4 hover:bg-[#214a67]"><Save className="h-4 w-4" />{saveMutation.isPending ? "Đang lưu..." : "Lưu cài đặt"}</Button></div></CardContent></Card>

          <Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="border-b border-[#edf3f3] pb-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#eef4fb] p-2.5 text-[#3b6e95]"><ImagePlus className="h-5 w-5" /></div><div><CardTitle className="text-base text-[#14314a]">Logo phòng xét nghiệm</CardTitle><p className="mt-1 text-xs text-muted-foreground">PNG, JPEG, WEBP hoặc SVG · tối đa 4 MB.</p></div></div></CardHeader><CardContent className="space-y-5 p-5"><div className="flex min-h-48 items-center justify-center rounded-2xl border border-dashed border-[#cddfe2] bg-[#f8fbfb] p-6">{form.logoUrl ? <img src={form.logoUrl} alt="Logo phòng xét nghiệm" className="max-h-36 max-w-full object-contain" /> : <div className="text-center text-muted-foreground"><ImagePlus className="mx-auto h-10 w-10 text-[#9bb9bf]" /><p className="mt-3 text-sm">Chưa có logo được tải lên</p></div>}</div><input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" className="hidden" onChange={(event) => { const file = event.target.files?.[0]; if (file) uploadLogo(file); event.currentTarget.value = ""; }} /><Button variant="outline" onClick={() => fileRef.current?.click()} disabled={uploadMutation.isPending} className="w-full gap-2 rounded-xl border-[#cddfe2] bg-white"><Upload className="h-4 w-4" />{uploadMutation.isPending ? "Đang tải lên..." : "Tải logo lên"}</Button><p className="text-xs leading-5 text-muted-foreground">Logo được lưu trong storage riêng của ứng dụng và tham chiếu an toàn qua URL nội bộ.</p></CardContent></Card>
        </div>

        {isAdmin ? <Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="border-b border-[#edf3f3] pb-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#fff5df] p-2.5 text-[#a16b18]"><Users className="h-5 w-5" /></div><div><CardTitle className="text-base text-[#14314a]">Phân quyền người dùng</CardTitle><p className="mt-1 text-xs text-muted-foreground">Chỉ quản trị viên có thể thay đổi vai trò truy cập.</p></div></div></CardHeader><CardContent className="p-0">{usersQuery.isLoading ? <div className="p-6 text-sm text-muted-foreground">Đang tải danh sách người dùng...</div> : usersQuery.data?.length ? <div className="divide-y divide-[#edf3f3]">{usersQuery.data.map((account) => <div key={account.id} className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between"><div className="min-w-0"><p className="truncate text-sm font-semibold text-[#18364b]">{account.name || "Chưa cập nhật tên"}</p><p className="mt-1 truncate text-xs text-muted-foreground">{account.email || "Không có email"}</p></div><Select value={account.role} onValueChange={(value) => changeRole(account.id, value as keyof typeof roleLabels)}><SelectTrigger className="w-full rounded-xl border-[#dcebea] bg-white sm:w-44"><SelectValue /></SelectTrigger><SelectContent>{roleOptions.map(([value, label]) => <SelectItem key={value} value={value}>{label}</SelectItem>)}</SelectContent></Select></div>)}</div> : <div className="p-6 text-sm text-muted-foreground">Chưa có tài khoản nào.</div>}</CardContent></Card> : <Card className="border-0 bg-[#14314a] text-white shadow-[0_10px_30px_rgba(20,49,74,0.14)]"><CardContent className="flex items-start gap-4 p-5"><ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-[#72d4bf]" /><div><p className="font-medium">Phân quyền đang được bảo vệ</p><p className="mt-1 text-sm leading-6 text-white/65">Tài khoản quản lý có thể cập nhật cấu hình lab và dữ liệu danh mục, nhưng không thể thay đổi vai trò người dùng.</p></div></CardContent></Card>}

        <div className="grid gap-4 sm:grid-cols-3"><div className="rounded-2xl border border-[#dcebea] bg-white p-4"><p className="text-xs font-semibold uppercase tracking-[0.1em] text-primary">Nhập liệu</p><p className="mt-2 text-sm text-muted-foreground">Kỹ thuật viên có thể ghi nhận kết quả QC thủ công.</p></div><div className="rounded-2xl border border-[#dcebea] bg-white p-4"><p className="text-xs font-semibold uppercase tracking-[0.1em] text-primary">Kiểm soát</p><p className="mt-2 text-sm text-muted-foreground">Quản lý được phép cập nhật danh mục, sửa và xóa dữ liệu nhạy cảm.</p></div><div className="rounded-2xl border border-[#dcebea] bg-white p-4"><p className="text-xs font-semibold uppercase tracking-[0.1em] text-primary">Truy vết</p><p className="mt-2 text-sm text-muted-foreground">Mọi thay đổi quan trọng được ghi lại trong Audit Trail.</p></div></div>
      </div>
    </div>
  );
}
