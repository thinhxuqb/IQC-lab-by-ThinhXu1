import { and, desc, eq, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  controlMaterials,
  InsertControlMaterial,
  InsertIqcResult,
  InsertTest,
  InsertLabSetting,
  InsertAuditLog,
  auditLogs,
  iqcResults,
  labSettings,
  tests,
  InsertUser,
  users,
  licenseKeys,
  InsertLicenseKey,
  instrumentConfigs,
  InsertInstrumentConfig,
  instrumentMappings,
  InsertInstrumentMapping,
  instrumentLogs,
  InsertInstrumentLog,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

let _db: ReturnType<typeof drizzle> | null = null;

type OfflineLicenseRecord = {
  id: number;
  licenseKey: string;
  hospitalName: string;
  activatedBy: string | null;
  isActivated: number;
  activatedAt: string;
};

function getOfflineLicensePath() {
  const dataRoot = process.env.IQC_DATA_DIR || path.join(os.homedir(), ".iqc-lab-by-thinhxu");
  return path.join(dataRoot, "license.json");
}

type OfflineLabSettingsRecord = {
  id: number;
  labName: string;
  hospitalName: string | null;
  address: string | null;
  managerName: string | null;
  chiefTechnician: string | null;
  logoUrl: string | null;
  phone: string | null;
  email: string | null;
  updatedAt: string;
};

function getOfflineSettingsPath() {
  const dataRoot = process.env.IQC_DATA_DIR || path.join(os.homedir(), ".iqc-lab-by-thinhxu");
  return path.join(dataRoot, "settings.json");
}

type OfflineDataStore = {
  tests: any[];
  controlMaterials: any[];
  iqcResults: any[];
  auditLogs: any[];
  users: any[];
  instrumentConfigs: any[];
  instrumentMappings: any[];
  instrumentLogs: any[];
  nextIds: {
    tests: number;
    controlMaterials: number;
    iqcResults: number;
    auditLogs: number;
    users: number;
    instrumentConfigs: number;
    instrumentMappings: number;
    instrumentLogs: number;
  };
  updatedAt: string;
};

function getOfflineDataPath() {
  const dataRoot = process.env.IQC_DATA_DIR || path.join(os.homedir(), ".iqc-lab-by-thinhxu");
  return path.join(dataRoot, "data.json");
}

function createEmptyOfflineData(): OfflineDataStore {
  return {
    tests: [],
    controlMaterials: [],
    iqcResults: [],
    auditLogs: [],
    users: [],
    instrumentConfigs: [],
    instrumentMappings: [],
    instrumentLogs: [],
    nextIds: { tests: 1, controlMaterials: 1, iqcResults: 1, auditLogs: 1, users: 1, instrumentConfigs: 1, instrumentMappings: 1, instrumentLogs: 1 },
    updatedAt: new Date().toISOString(),
  };
}

function readOfflineData(): OfflineDataStore {
  try {
    const filePath = getOfflineDataPath();
    if (!fs.existsSync(filePath)) return createEmptyOfflineData();
    const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
    const fallback = createEmptyOfflineData();
    const data: OfflineDataStore = {
      ...fallback,
      ...parsed,
      tests: Array.isArray(parsed.tests) ? parsed.tests : [],
      controlMaterials: Array.isArray(parsed.controlMaterials) ? parsed.controlMaterials : [],
      iqcResults: Array.isArray(parsed.iqcResults) ? parsed.iqcResults : [],
      auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : [],
      users: Array.isArray(parsed.users) ? parsed.users : [],
      instrumentConfigs: Array.isArray(parsed.instrumentConfigs) ? parsed.instrumentConfigs : [],
      instrumentMappings: Array.isArray(parsed.instrumentMappings) ? parsed.instrumentMappings : [],
      instrumentLogs: Array.isArray(parsed.instrumentLogs) ? parsed.instrumentLogs : [],
      nextIds: { ...fallback.nextIds, ...(parsed.nextIds ?? {}) },
    };
    for (const [key, records] of Object.entries({
      tests: data.tests,
      controlMaterials: data.controlMaterials,
      iqcResults: data.iqcResults,
      auditLogs: data.auditLogs,
      users: data.users,
      instrumentConfigs: data.instrumentConfigs,
      instrumentMappings: data.instrumentMappings,
      instrumentLogs: data.instrumentLogs,
    })) {
      const maxId = records.reduce((max, record) => Math.max(max, Number(record?.id) || 0), 0);
      const typedKey = key as keyof OfflineDataStore["nextIds"];
      data.nextIds[typedKey] = Math.max(Number(data.nextIds[typedKey]) || 1, maxId + 1);
    }
    return data;
  } catch (error) {
    console.warn("[Offline Data] Failed to read local data:", error);
    return createEmptyOfflineData();
  }
}

function writeOfflineData(data: OfflineDataStore) {
  const filePath = getOfflineDataPath();
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temporaryPath = `${filePath}.tmp`;
  fs.writeFileSync(temporaryPath, JSON.stringify({ ...data, updatedAt: new Date().toISOString() }, null, 2), "utf8");
  fs.renameSync(temporaryPath, filePath);
}

function nextOfflineId(data: OfflineDataStore, collection: keyof OfflineDataStore["nextIds"]) {
  const id = Math.max(Number(data.nextIds[collection]) || 1, 1);
  data.nextIds[collection] = id + 1;
  return id;
}

function asDate(value: unknown) {
  return value instanceof Date ? value : new Date(String(value ?? new Date().toISOString()));
}

function offlineTestRow(record: any) {
  return { ...record, createdAt: asDate(record.createdAt), updatedAt: asDate(record.updatedAt) };
}

function offlineMaterialRow(record: any) {
  return {
    ...record,
    expirationDate: record.expirationDate ? asDate(record.expirationDate) : null,
    createdAt: asDate(record.createdAt),
    updatedAt: asDate(record.updatedAt),
  };
}

function offlineResultRow(record: any) {
  return {
    ...record,
    recordedAt: asDate(record.recordedAt),
    createdAt: asDate(record.createdAt),
    updatedAt: asDate(record.updatedAt),
  };
}

function offlineInstrumentConfigRow(record: any) {
  return {
    ...record,
    enabled: Number(record.enabled ?? 0),
    dataBits: Number(record.dataBits ?? 8),
    stopBits: Number(record.stopBits ?? 1),
    codeFieldIndex: Number(record.codeFieldIndex ?? 0),
    valueFieldIndex: Number(record.valueFieldIndex ?? 1),
    receiveTimeoutMs: Number(record.receiveTimeoutMs ?? 1000),
    createdAt: asDate(record.createdAt),
    updatedAt: asDate(record.updatedAt),
  };
}

function offlineInstrumentMappingRow(record: any) {
  return { ...record, enabled: Number(record.enabled ?? 1), createdAt: asDate(record.createdAt), updatedAt: asDate(record.updatedAt) };
}

function offlineInstrumentLogRow(record: any) {
  return {
    ...record,
    receivedAt: asDate(record.receivedAt),
    createdAt: asDate(record.createdAt),
  };
}

function offlineAuditRow(record: any) {
  return { ...record, createdAt: asDate(record.createdAt) };
}

function readOfflineLabSettings(): OfflineLabSettingsRecord | undefined {
  try {
    const filePath = getOfflineSettingsPath();
    if (!fs.existsSync(filePath)) return undefined;
    const parsed = JSON.parse(fs.readFileSync(filePath, "utf8")) as OfflineLabSettingsRecord;
    if (!parsed.labName) return undefined;
    return parsed;
  } catch (error) {
    console.warn("[Offline Settings] Failed to read local settings:", error);
    return undefined;
  }
}

function writeOfflineLabSettings(record: OfflineLabSettingsRecord) {
  const filePath = getOfflineSettingsPath();
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temporaryPath = `${filePath}.tmp`;
  fs.writeFileSync(temporaryPath, JSON.stringify(record, null, 2), "utf8");
  fs.renameSync(temporaryPath, filePath);
}

function offlineLabSettingsAsDatabaseRow(record: OfflineLabSettingsRecord) {
  return {
    ...record,
    updatedAt: new Date(record.updatedAt),
  };
}

function readOfflineLicense(): OfflineLicenseRecord | undefined {
  try {
    const filePath = getOfflineLicensePath();
    if (!fs.existsSync(filePath)) return undefined;
    const parsed = JSON.parse(fs.readFileSync(filePath, "utf8")) as OfflineLicenseRecord;
    return parsed.isActivated === 1 && parsed.licenseKey ? parsed : undefined;
  } catch (error) {
    console.warn("[Offline License] Failed to read local license:", error);
    return undefined;
  }
}

function writeOfflineLicense(record: OfflineLicenseRecord) {
  const filePath = getOfflineLicensePath();
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temporaryPath = `${filePath}.tmp`;
  fs.writeFileSync(temporaryPath, JSON.stringify(record, null, 2), "utf8");
  fs.renameSync(temporaryPath, filePath);
}

function offlineLicenseAsDatabaseRow(record: OfflineLicenseRecord) {
  return {
    ...record,
    activatedAt: new Date(record.activatedAt),
  };
}

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    if (openId === "offline-admin-openid" && readOfflineLicense()) {
      const now = new Date();
      return {
        id: 1,
        openId,
        name: "Quản trị viên xét nghiệm",
        email: null,
        loginMethod: "offline-license",
        role: "admin" as const,
        createdAt: now,
        updatedAt: now,
        lastSignedIn: now,
      };
    }
    return undefined;
  }
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listTests() {
  const db = await getDb();
  if (!db) return readOfflineData().tests.map(offlineTestRow).sort((a, b) => a.name.localeCompare(b.name));
  return db.select().from(tests).orderBy(tests.name);
}

export async function createTest(data: InsertTest) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const now = new Date().toISOString();
    const record = { ...data, id: nextOfflineId(store, "tests"), createdAt: now, updatedAt: now };
    store.tests.push(record);
    writeOfflineData(store);
    return offlineTestRow(record);
  }
  const result = await db.insert(tests).values(data);
  return getTestById(Number(result[0].insertId));
}

export async function getTestById(id: number) {
  const db = await getDb();
  if (!db) {
    const record = readOfflineData().tests.find((item) => Number(item.id) === id);
    return record ? offlineTestRow(record) : undefined;
  }
  const result = await db.select().from(tests).where(eq(tests.id, id)).limit(1);
  return result[0];
}

export async function updateTest(id: number, data: Partial<InsertTest>) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const index = store.tests.findIndex((item) => Number(item.id) === id);
    if (index < 0) return undefined;
    const record = { ...store.tests[index], ...data, id, updatedAt: new Date().toISOString() };
    store.tests[index] = record;
    writeOfflineData(store);
    return offlineTestRow(record);
  }
  await db.update(tests).set(data).where(eq(tests.id, id));
  return getTestById(id);
}

export async function deleteTest(id: number) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const before = store.tests.length;
    store.tests = store.tests.filter((item) => Number(item.id) !== id);
    if (store.tests.length !== before) writeOfflineData(store);
    return { success: true } as const;
  }
  await db.delete(tests).where(eq(tests.id, id));
  return { success: true } as const;
}

export async function listControlMaterials(testId?: number) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    return store.controlMaterials
      .filter((material) => !testId || Number(material.testId) === testId)
      .map((material) => {
        const test = store.tests.find((item) => Number(item.id) === Number(material.testId));
        return test ? { material: offlineMaterialRow(material), test: offlineTestRow(test) } : undefined;
      })
      .filter((item): item is { material: any; test: any } => Boolean(item))
      .sort((a, b) => a.test.name.localeCompare(b.test.name) || String(a.material.level).localeCompare(String(b.material.level)));
  }
  const condition = testId ? eq(controlMaterials.testId, testId) : undefined;
  return db
    .select({ material: controlMaterials, test: tests })
    .from(controlMaterials)
    .innerJoin(tests, eq(controlMaterials.testId, tests.id))
    .where(condition)
    .orderBy(tests.name, controlMaterials.level);
}

export async function createControlMaterial(data: InsertControlMaterial) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const now = new Date().toISOString();
    const record = { ...data, id: nextOfflineId(store, "controlMaterials"), createdAt: now, updatedAt: now };
    store.controlMaterials.push(record);
    writeOfflineData(store);
    return getControlMaterialById(record.id);
  }
  const result = await db.insert(controlMaterials).values(data);
  return getControlMaterialById(Number(result[0].insertId));
}

export async function getControlMaterialById(id: number) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const material = store.controlMaterials.find((item) => Number(item.id) === id);
    const test = material ? store.tests.find((item) => Number(item.id) === Number(material.testId)) : undefined;
    return material && test ? { material: offlineMaterialRow(material), test: offlineTestRow(test) } : undefined;
  }
  const result = await db
    .select({ material: controlMaterials, test: tests })
    .from(controlMaterials)
    .innerJoin(tests, eq(controlMaterials.testId, tests.id))
    .where(eq(controlMaterials.id, id))
    .limit(1);
  return result[0];
}

export async function updateControlMaterial(id: number, data: Partial<InsertControlMaterial>) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const index = store.controlMaterials.findIndex((item) => Number(item.id) === id);
    if (index < 0) return undefined;
    const record = { ...store.controlMaterials[index], ...data, id, updatedAt: new Date().toISOString() };
    store.controlMaterials[index] = record;
    writeOfflineData(store);
    return getControlMaterialById(id);
  }
  await db.update(controlMaterials).set(data).where(eq(controlMaterials.id, id));
  return getControlMaterialById(id);
}

export async function deleteControlMaterial(id: number) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const before = store.controlMaterials.length;
    store.controlMaterials = store.controlMaterials.filter((item) => Number(item.id) !== id);
    if (store.controlMaterials.length !== before) writeOfflineData(store);
    return { success: true } as const;
  }
  await db.delete(controlMaterials).where(eq(controlMaterials.id, id));
  return { success: true } as const;
}

export type ResultsFilter = {
  testId?: number;
  controlMaterialId?: number;
  from?: Date;
  to?: Date;
};

export async function listIqcResults(filters: ResultsFilter = {}) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    return store.iqcResults
      .filter((result) => {
        const recordedAt = asDate(result.recordedAt).getTime();
        return (!filters.testId || Number(result.testId) === filters.testId)
          && (!filters.controlMaterialId || Number(result.controlMaterialId) === filters.controlMaterialId)
          && (!filters.from || recordedAt >= filters.from.getTime())
          && (!filters.to || recordedAt <= filters.to.getTime());
      })
      .map((result) => {
        const test = store.tests.find((item) => Number(item.id) === Number(result.testId));
        const material = store.controlMaterials.find((item) => Number(item.id) === Number(result.controlMaterialId));
        return test && material ? { result: offlineResultRow(result), test: offlineTestRow(test), material: offlineMaterialRow(material) } : undefined;
      })
      .filter((item): item is { result: any; test: any; material: any } => Boolean(item))
      .sort((a, b) => b.result.recordedAt.getTime() - a.result.recordedAt.getTime());
  }
  const conditions = [];
  if (filters.testId) conditions.push(eq(iqcResults.testId, filters.testId));
  if (filters.controlMaterialId) conditions.push(eq(iqcResults.controlMaterialId, filters.controlMaterialId));
  if (filters.from) conditions.push(gte(iqcResults.recordedAt, filters.from));
  if (filters.to) conditions.push(lte(iqcResults.recordedAt, filters.to));
  return db
    .select({ result: iqcResults, test: tests, material: controlMaterials })
    .from(iqcResults)
    .innerJoin(tests, eq(iqcResults.testId, tests.id))
    .innerJoin(controlMaterials, eq(iqcResults.controlMaterialId, controlMaterials.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(iqcResults.recordedAt));
}

export async function getIqcResultById(id: number) {
  const results = await listIqcResults();
  return results.find((item) => item.result.id === id);
}

export async function createIqcResult(data: InsertIqcResult) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const now = new Date().toISOString();
    const record = { ...data, id: nextOfflineId(store, "iqcResults"), createdAt: now, updatedAt: now };
    store.iqcResults.push(record);
    writeOfflineData(store);
    return getIqcResultById(record.id);
  }
  const result = await db.insert(iqcResults).values(data);
  return getIqcResultById(Number(result[0].insertId));
}

export async function updateIqcResult(id: number, data: Partial<InsertIqcResult>) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const index = store.iqcResults.findIndex((item) => Number(item.id) === id);
    if (index < 0) return undefined;
    const record = { ...store.iqcResults[index], ...data, id, updatedAt: new Date().toISOString() };
    store.iqcResults[index] = record;
    writeOfflineData(store);
    return getIqcResultById(id);
  }
  await db.update(iqcResults).set(data).where(eq(iqcResults.id, id));
  return getIqcResultById(id);
}

export async function deleteIqcResult(id: number) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const before = store.iqcResults.length;
    store.iqcResults = store.iqcResults.filter((item) => Number(item.id) !== id);
    if (store.iqcResults.length !== before) writeOfflineData(store);
    return { success: true } as const;
  }
  await db.delete(iqcResults).where(eq(iqcResults.id, id));
  return { success: true } as const;
}

export async function listInstrumentConfigs(enabledOnly = false) {
  const db = await getDb();
  if (!db) {
    return readOfflineData().instrumentConfigs
      .filter((config) => !enabledOnly || Number(config.enabled) === 1)
      .map(offlineInstrumentConfigRow)
      .sort((a, b) => a.name.localeCompare(b.name));
  }
  return db
    .select()
    .from(instrumentConfigs)
    .where(enabledOnly ? eq(instrumentConfigs.enabled, 1) : undefined)
    .orderBy(instrumentConfigs.name);
}

export async function getInstrumentConfigById(id: number) {
  const db = await getDb();
  if (!db) {
    const record = readOfflineData().instrumentConfigs.find((item) => Number(item.id) === id);
    return record ? offlineInstrumentConfigRow(record) : undefined;
  }
  const result = await db.select().from(instrumentConfigs).where(eq(instrumentConfigs.id, id)).limit(1);
  return result[0];
}

export async function createInstrumentConfig(data: InsertInstrumentConfig) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const now = new Date().toISOString();
    const record = { ...data, id: nextOfflineId(store, "instrumentConfigs"), createdAt: now, updatedAt: now };
    store.instrumentConfigs.push(record);
    writeOfflineData(store);
    return offlineInstrumentConfigRow(record);
  }
  const result = await db.insert(instrumentConfigs).values(data);
  return getInstrumentConfigById(Number(result[0].insertId));
}

export async function updateInstrumentConfig(id: number, data: Partial<InsertInstrumentConfig>) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const index = store.instrumentConfigs.findIndex((item) => Number(item.id) === id);
    if (index < 0) return undefined;
    const record = { ...store.instrumentConfigs[index], ...data, id, updatedAt: new Date().toISOString() };
    store.instrumentConfigs[index] = record;
    writeOfflineData(store);
    return offlineInstrumentConfigRow(record);
  }
  await db.update(instrumentConfigs).set(data).where(eq(instrumentConfigs.id, id));
  return getInstrumentConfigById(id);
}

export async function deleteInstrumentConfig(id: number) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    store.instrumentMappings = store.instrumentMappings.filter((item) => Number(item.configId) !== id);
    store.instrumentConfigs = store.instrumentConfigs.filter((item) => Number(item.id) !== id);
    store.instrumentLogs = store.instrumentLogs.filter((item) => Number(item.configId) !== id);
    writeOfflineData(store);
    return { success: true } as const;
  }
  await db.delete(instrumentLogs).where(eq(instrumentLogs.configId, id));
  await db.delete(instrumentMappings).where(eq(instrumentMappings.configId, id));
  await db.delete(instrumentConfigs).where(eq(instrumentConfigs.id, id));
  return { success: true } as const;
}

export async function listInstrumentMappings(configId?: number) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    return store.instrumentMappings
      .filter((mapping) => !configId || Number(mapping.configId) === configId)
      .map((mapping) => {
        const test = store.tests.find((item) => Number(item.id) === Number(mapping.testId));
        const material = store.controlMaterials.find((item) => Number(item.id) === Number(mapping.controlMaterialId));
        return test && material ? { mapping: offlineInstrumentMappingRow(mapping), test: offlineTestRow(test), material: offlineMaterialRow(material) } : undefined;
      })
      .filter((item): item is { mapping: any; test: any; material: any } => Boolean(item));
  }
  const condition = configId ? eq(instrumentMappings.configId, configId) : undefined;
  return db
    .select({ mapping: instrumentMappings, test: tests, material: controlMaterials })
    .from(instrumentMappings)
    .innerJoin(tests, eq(instrumentMappings.testId, tests.id))
    .innerJoin(controlMaterials, eq(instrumentMappings.controlMaterialId, controlMaterials.id))
    .where(condition)
    .orderBy(instrumentMappings.instrumentCode);
}

export async function createInstrumentMapping(data: InsertInstrumentMapping) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const now = new Date().toISOString();
    const record = { ...data, id: nextOfflineId(store, "instrumentMappings"), createdAt: now, updatedAt: now };
    store.instrumentMappings.push(record);
    writeOfflineData(store);
    const rows = await listInstrumentMappings(record.configId);
    return rows.find((item) => item.mapping.id === record.id);
  }
  const result = await db.insert(instrumentMappings).values(data);
  const rows = await listInstrumentMappings(data.configId);
  return rows.find((item) => item.mapping.id === Number(result[0].insertId));
}

export async function updateInstrumentMapping(id: number, data: Partial<InsertInstrumentMapping>) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const index = store.instrumentMappings.findIndex((item) => Number(item.id) === id);
    if (index < 0) return undefined;
    const record = { ...store.instrumentMappings[index], ...data, id, updatedAt: new Date().toISOString() };
    store.instrumentMappings[index] = record;
    writeOfflineData(store);
    const rows = await listInstrumentMappings(Number(record.configId));
    return rows.find((item) => item.mapping.id === id);
  }
  await db.update(instrumentMappings).set(data).where(eq(instrumentMappings.id, id));
  const current = await db.select().from(instrumentMappings).where(eq(instrumentMappings.id, id)).limit(1);
  const rows = await listInstrumentMappings(current[0]?.configId);
  return rows.find((item) => item.mapping.id === id);
}

export async function deleteInstrumentMapping(id: number) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    store.instrumentMappings = store.instrumentMappings.filter((item) => Number(item.id) !== id);
    writeOfflineData(store);
    return { success: true } as const;
  }
  await db.delete(instrumentMappings).where(eq(instrumentMappings.id, id));
  return { success: true } as const;
}

export async function createInstrumentLog(data: InsertInstrumentLog) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const now = new Date().toISOString();
    const record = { ...data, id: nextOfflineId(store, "instrumentLogs"), createdAt: now, receivedAt: data.receivedAt?.toISOString?.() ?? now };
    store.instrumentLogs.push(record);
    writeOfflineData(store);
    return offlineInstrumentLogRow(record);
  }
  const result = await db.insert(instrumentLogs).values(data);
  const rows = await db.select().from(instrumentLogs).where(eq(instrumentLogs.id, Number(result[0].insertId))).limit(1);
  return rows[0];
}

export async function listInstrumentLogs(configId?: number, limit = 100) {
  const db = await getDb();
  const safeLimit = Math.min(Math.max(limit, 1), 500);
  if (!db) {
    return readOfflineData().instrumentLogs
      .filter((log) => !configId || Number(log.configId) === configId)
      .map(offlineInstrumentLogRow)
      .sort((a, b) => b.receivedAt.getTime() - a.receivedAt.getTime() || Number(b.id) - Number(a.id))
      .slice(0, safeLimit);
  }
  return db
    .select()
    .from(instrumentLogs)
    .where(configId ? eq(instrumentLogs.configId, configId) : undefined)
    .orderBy(desc(instrumentLogs.receivedAt), desc(instrumentLogs.id))
    .limit(safeLimit);
}

export async function findInstrumentLogByDedupKey(dedupKey: string) {
  const db = await getDb();
  if (!db) return readOfflineData().instrumentLogs.map(offlineInstrumentLogRow).find((log) => log.dedupKey === dedupKey);
  const result = await db.select().from(instrumentLogs).where(eq(instrumentLogs.dedupKey, dedupKey)).limit(1);
  return result[0];
}


export async function getLabSettings() {
  const db = await getDb();
  if (!db) {
    const localSettings = readOfflineLabSettings();
    return localSettings ? offlineLabSettingsAsDatabaseRow(localSettings) : undefined;
  }
  const result = await db.select().from(labSettings).orderBy(labSettings.id).limit(1);
  return result[0];
}

export async function saveLabSettings(data: InsertLabSetting) {
  const db = await getDb();
  if (!db) {
    const current = readOfflineLabSettings();
    const record: OfflineLabSettingsRecord = {
      id: current?.id ?? 1,
      labName: data.labName,
      hospitalName: data.hospitalName ?? null,
      address: data.address ?? null,
      managerName: data.managerName ?? null,
      chiefTechnician: data.chiefTechnician ?? null,
      logoUrl: data.logoUrl === undefined ? current?.logoUrl ?? null : data.logoUrl ?? null,
      phone: data.phone ?? null,
      email: data.email ?? null,
      updatedAt: new Date().toISOString(),
    };
    writeOfflineLabSettings(record);
    return offlineLabSettingsAsDatabaseRow(record);
  }
  const current = await getLabSettings();
  if (current) {
    await db.update(labSettings).set(data).where(eq(labSettings.id, current.id));
    return getLabSettings();
  }
  const result = await db.insert(labSettings).values(data);
  return getLabSettingsById(Number(result[0].insertId));
}

async function getLabSettingsById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(labSettings).where(eq(labSettings.id, id)).limit(1);
  return result[0];
}

export type AuditLogFilters = {
  action?: string;
  targetType?: string;
  userId?: number;
  from?: Date;
  to?: Date;
  limit?: number;
};

export async function createAuditLog(data: InsertAuditLog) {
  const db = await getDb();
  if (!db) {
    const store = readOfflineData();
    const record = { ...data, id: nextOfflineId(store, "auditLogs"), createdAt: new Date().toISOString() };
    store.auditLogs.push(record);
    writeOfflineData(store);
    return offlineAuditRow(record);
  }
  const result = await db.insert(auditLogs).values(data);
  const rows = await db.select().from(auditLogs).where(eq(auditLogs.id, Number(result[0].insertId))).limit(1);
  return rows[0];
}

export async function listAuditLogs(filters: AuditLogFilters = {}) {
  const db = await getDb();
  if (!db) {
    return readOfflineData().auditLogs
      .filter((log) => (!filters.action || log.action === filters.action)
        && (!filters.targetType || log.targetType === filters.targetType)
        && (!filters.userId || Number(log.userId) === filters.userId)
        && (!filters.from || asDate(log.createdAt).getTime() >= filters.from.getTime())
        && (!filters.to || asDate(log.createdAt).getTime() <= filters.to.getTime()))
      .map(offlineAuditRow)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, Math.min(Math.max(filters.limit ?? 200, 1), 500));
  }
  const conditions = [];
  if (filters.action) conditions.push(eq(auditLogs.action, filters.action));
  if (filters.targetType) conditions.push(eq(auditLogs.targetType, filters.targetType));
  if (filters.userId) conditions.push(eq(auditLogs.userId, filters.userId));
  if (filters.from) conditions.push(gte(auditLogs.createdAt, filters.from));
  if (filters.to) conditions.push(lte(auditLogs.createdAt, filters.to));
  return db
    .select()
    .from(auditLogs)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(auditLogs.createdAt))
    .limit(Math.min(Math.max(filters.limit ?? 200, 1), 500));
}

export async function listUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: users.id,
    name: users.name,
    email: users.email,
    role: users.role,
    createdAt: users.createdAt,
    lastSignedIn: users.lastSignedIn,
  }).from(users).orderBy(users.name);
}

export type AppRole = "user" | "technician" | "manager" | "admin";

export async function updateUserRole(id: number, role: AppRole) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(users).set({ role }).where(eq(users.id, id));
  const result = await db.select({
    id: users.id,
    name: users.name,
    email: users.email,
    role: users.role,
    createdAt: users.createdAt,
    lastSignedIn: users.lastSignedIn,
  }).from(users).where(eq(users.id, id)).limit(1);
  return result[0];
}

export async function exportFullDatabaseBackup() {
  const db = await getDb();
  let allTests: any[] = [];
  let allMaterials: any[] = [];
  let allResults: any[] = [];
  let allAuditLogs: any[] = [];
  let allInstrumentConfigs: any[] = [];
  let allInstrumentMappings: any[] = [];
  let allInstrumentLogs: any[] = [];
  let settings: any = null;
  let license: any = null;

  if (db) {
    allTests = await db.select().from(tests);
    allMaterials = await db.select().from(controlMaterials);
    allResults = await db.select().from(iqcResults);
    allAuditLogs = await db.select().from(auditLogs);
    allInstrumentConfigs = await db.select().from(instrumentConfigs);
    allInstrumentMappings = await db.select().from(instrumentMappings);
    allInstrumentLogs = await db.select().from(instrumentLogs);
    const settingsRows = await db.select().from(labSettings).limit(1);
    settings = settingsRows[0] ?? null;
    const licenseRows = await db.select().from(licenseKeys).limit(1);
    license = licenseRows[0] ?? null;
  } else {
    const store = readOfflineData();
    allTests = store.tests;
    allMaterials = store.controlMaterials;
    allResults = store.iqcResults;
    allAuditLogs = store.auditLogs;
    allInstrumentConfigs = store.instrumentConfigs;
    allInstrumentMappings = store.instrumentMappings;
    allInstrumentLogs = store.instrumentLogs;
    settings = readOfflineLabSettings() ?? null;
    license = readOfflineLicense() ?? null;
  }

  return {
    version: "1.0.27",
    app: "iqc-lab-manager",
    exportedAt: new Date().toISOString(),
    data: {
      tests: allTests,
      controlMaterials: allMaterials,
      iqcResults: allResults,
      auditLogs: allAuditLogs,
      instrumentConfigs: allInstrumentConfigs,
      instrumentMappings: allInstrumentMappings,
      instrumentLogs: allInstrumentLogs,
      labSettings: settings,
      licenseKey: license,
    },
  };
}

export async function importFullDatabaseBackup(backup: {
  version?: string;
  app?: string;
  data?: {
    tests?: any[];
    controlMaterials?: any[];
    iqcResults?: any[];
    auditLogs?: any[];
    instrumentConfigs?: any[];
    instrumentMappings?: any[];
    instrumentLogs?: any[];
    labSettings?: any;
    licenseKey?: any;
  };
}) {
  if (!backup || !backup.data) {
    throw new Error("Tệp sao lưu không đúng định dạng IQC Lab (.iqc-backup).");
  }

  const db = await getDb();
  const payload = backup.data;

  if (db) {
    // Xóa dữ liệu cũ theo thứ tự khóa ngoại ngược để an toàn
    await db.delete(iqcResults);
    await db.delete(controlMaterials);
    await db.delete(tests);
    await db.delete(instrumentLogs);
    await db.delete(instrumentMappings);
    await db.delete(instrumentConfigs);
    await db.delete(labSettings);
    await db.delete(licenseKeys);

    if (payload.tests && payload.tests.length > 0) {
      const cleanTests = payload.tests.map((t: any) => ({
        id: t.id,
        code: t.code,
        name: t.name,
        unit: t.unit,
        category: t.category ?? null,
        description: t.description ?? null,
        createdAt: t.createdAt ? new Date(t.createdAt) : new Date(),
        updatedAt: t.updatedAt ? new Date(t.updatedAt) : new Date(),
      }));
      await db.insert(tests).values(cleanTests);
    }

    if (payload.controlMaterials && payload.controlMaterials.length > 0) {
      const cleanMaterials = payload.controlMaterials.map((m: any) => ({
        id: m.id,
        testId: m.testId,
        name: m.name,
        lotNumber: m.lotNumber,
        level: m.level,
        targetMean: m.targetMean,
        targetSd: m.targetSd,
        expirationDate: m.expirationDate ? new Date(m.expirationDate) : null,
        isActive: m.isActive ?? 1,
        createdAt: m.createdAt ? new Date(m.createdAt) : new Date(),
        updatedAt: m.updatedAt ? new Date(m.updatedAt) : new Date(),
      }));
      await db.insert(controlMaterials).values(cleanMaterials);
    }

    if (payload.iqcResults && payload.iqcResults.length > 0) {
      const cleanResults = payload.iqcResults.map((r: any) => ({
        id: r.id,
        testId: r.testId,
        controlMaterialId: r.controlMaterialId,
        value: r.value,
        recordedAt: r.recordedAt ? new Date(r.recordedAt) : new Date(),
        mean: r.mean,
        sd: r.sd,
        zScore: r.zScore,
        status: r.status,
        violations: r.violations,
        note: r.note ?? null,
        technician: r.technician ?? null,
        createdAt: r.createdAt ? new Date(r.createdAt) : new Date(),
        updatedAt: r.updatedAt ? new Date(r.updatedAt) : new Date(),
      }));
      await db.insert(iqcResults).values(cleanResults);
    }

    if (payload.labSettings) {
      const s = payload.labSettings;
      await db.insert(labSettings).values({
        id: s.id ?? 1,
        labName: s.labName ?? "Phòng xét nghiệm",
        hospitalName: s.hospitalName ?? null,
        address: s.address ?? null,
        managerName: s.managerName ?? null,
        chiefTechnician: s.chiefTechnician ?? null,
        logoUrl: s.logoUrl ?? null,
        phone: s.phone ?? null,
        email: s.email ?? null,
        updatedAt: s.updatedAt ? new Date(s.updatedAt) : new Date(),
      });
    }

    if (payload.licenseKey) {
      const l = payload.licenseKey;
      await db.insert(licenseKeys).values({
        id: l.id ?? 1,
        licenseKey: l.licenseKey,
        hospitalName: l.hospitalName,
        activatedBy: l.activatedBy ?? null,
        isActivated: l.isActivated ?? 1,
        activatedAt: l.activatedAt ? new Date(l.activatedAt) : new Date(),
      });
    }
    if (payload.auditLogs && payload.auditLogs.length > 0) {
      const cleanAuditLogs = payload.auditLogs.map((log: any) => ({
        id: log.id,
        userId: log.userId ?? null,
        userName: log.userName ?? null,
        userRole: log.userRole ?? null,
        action: log.action,
        targetType: log.targetType,
        targetId: log.targetId ?? null,
        details: log.details ?? null,
        ipAddress: log.ipAddress ?? null,
        createdAt: log.createdAt ? new Date(log.createdAt) : new Date(),
      }));
      await db.insert(auditLogs).values(cleanAuditLogs);
    }
    if (payload.instrumentConfigs && payload.instrumentConfigs.length > 0) {
      await db.insert(instrumentConfigs).values(payload.instrumentConfigs.map((config: any) => ({
        id: config.id,
        name: config.name,
        enabled: config.enabled ?? 0,
        connectionType: config.connectionType,
        protocol: config.protocol ?? "delimited",
        host: config.host ?? null,
        port: config.port ?? null,
        serialPort: config.serialPort ?? null,
        baudRate: config.baudRate ?? null,
        dataBits: config.dataBits ?? 8,
        stopBits: config.stopBits ?? 1,
        parity: config.parity ?? "none",
        delimiter: config.delimiter ?? "\\n",
        codeFieldIndex: config.codeFieldIndex ?? 0,
        valueFieldIndex: config.valueFieldIndex ?? 1,
        receiveTimeoutMs: config.receiveTimeoutMs ?? 1000,
        createdAt: config.createdAt ? new Date(config.createdAt) : new Date(),
        updatedAt: config.updatedAt ? new Date(config.updatedAt) : new Date(),
      })));
    }
    if (payload.instrumentMappings && payload.instrumentMappings.length > 0) {
      await db.insert(instrumentMappings).values(payload.instrumentMappings.map((mapping: any) => ({
        id: mapping.id,
        configId: mapping.configId,
        instrumentCode: mapping.instrumentCode,
        testId: mapping.testId,
        controlMaterialId: mapping.controlMaterialId,
        enabled: mapping.enabled ?? 1,
        createdAt: mapping.createdAt ? new Date(mapping.createdAt) : new Date(),
        updatedAt: mapping.updatedAt ? new Date(mapping.updatedAt) : new Date(),
      })));
    }
    if (payload.instrumentLogs && payload.instrumentLogs.length > 0) {
      await db.insert(instrumentLogs).values(payload.instrumentLogs.map((log: any) => ({
        id: log.id,
        configId: log.configId,
        direction: log.direction ?? "inbound",
        rawText: log.rawText ?? "",
        protocol: log.protocol ?? "delimited",
        messageId: log.messageId ?? null,
        receivedAt: log.receivedAt ? new Date(log.receivedAt) : new Date(),
        parseStatus: log.parseStatus ?? "received",
        dedupKey: log.dedupKey ?? null,
        resultId: log.resultId ?? null,
        errorMessage: log.errorMessage ?? null,
        createdAt: log.createdAt ? new Date(log.createdAt) : new Date(),
      })));
    }
  } else {
    const store = readOfflineData();
    store.tests = Array.isArray(payload.tests) ? payload.tests : [];
    store.controlMaterials = Array.isArray(payload.controlMaterials) ? payload.controlMaterials : [];
    store.iqcResults = Array.isArray(payload.iqcResults) ? payload.iqcResults : [];
    store.auditLogs = Array.isArray(payload.auditLogs) ? payload.auditLogs : [];
    store.instrumentConfigs = Array.isArray(payload.instrumentConfigs) ? payload.instrumentConfigs : [];
    store.instrumentMappings = Array.isArray(payload.instrumentMappings) ? payload.instrumentMappings : [];
    store.instrumentLogs = Array.isArray(payload.instrumentLogs) ? payload.instrumentLogs : [];
    store.nextIds = {
      tests: store.tests.reduce((max, row) => Math.max(max, Number(row?.id) || 0), 0) + 1,
      controlMaterials: store.controlMaterials.reduce((max, row) => Math.max(max, Number(row?.id) || 0), 0) + 1,
      iqcResults: store.iqcResults.reduce((max, row) => Math.max(max, Number(row?.id) || 0), 0) + 1,
      auditLogs: store.auditLogs.reduce((max, row) => Math.max(max, Number(row?.id) || 0), 0) + 1,
      users: store.users.reduce((max, row) => Math.max(max, Number(row?.id) || 0), 0) + 1,
      instrumentConfigs: store.instrumentConfigs.reduce((max, row) => Math.max(max, Number(row?.id) || 0), 0) + 1,
      instrumentMappings: store.instrumentMappings.reduce((max, row) => Math.max(max, Number(row?.id) || 0), 0) + 1,
      instrumentLogs: store.instrumentLogs.reduce((max, row) => Math.max(max, Number(row?.id) || 0), 0) + 1,
    };
    writeOfflineData(store);
    // Offline mode: ghi trực tiếp vào các tệp json cục bộ
    if (payload.labSettings) {
      writeOfflineLabSettings({
        id: payload.labSettings.id ?? 1,
        labName: payload.labSettings.labName ?? "Phòng xét nghiệm",
        hospitalName: payload.labSettings.hospitalName ?? null,
        address: payload.labSettings.address ?? null,
        managerName: payload.labSettings.managerName ?? null,
        chiefTechnician: payload.labSettings.chiefTechnician ?? null,
        logoUrl: payload.labSettings.logoUrl ?? null,
        phone: payload.labSettings.phone ?? null,
        email: payload.labSettings.email ?? null,
        updatedAt: new Date().toISOString(),
      });
    }
    if (payload.licenseKey) {
      writeOfflineLicense({
        id: payload.licenseKey.id ?? 1,
        licenseKey: payload.licenseKey.licenseKey,
        hospitalName: payload.licenseKey.hospitalName,
        activatedBy: payload.licenseKey.activatedBy ?? null,
        isActivated: payload.licenseKey.isActivated ?? 1,
        activatedAt: new Date().toISOString(),
      });
    }
  }

  return { success: true, message: "Khôi phục dữ liệu thành công." };
}

export async function getActiveLicense() {
  const db = await getDb();
  if (!db) {
    const localLicense = readOfflineLicense();
    return localLicense ? offlineLicenseAsDatabaseRow(localLicense) : undefined;
  }
  const rows = await db.select().from(licenseKeys).where(eq(licenseKeys.isActivated, 1)).limit(1);
  return rows[0];
}

export async function activateLicense(key: string, hospitalName: string, activatedBy: string) {
  const db = await getDb();
  if (!db) {
    const localLicense: OfflineLicenseRecord = {
      id: 1,
      licenseKey: key,
      hospitalName,
      activatedBy: activatedBy || null,
      isActivated: 1,
      activatedAt: new Date().toISOString(),
    };
    writeOfflineLicense(localLicense);
    return offlineLicenseAsDatabaseRow(localLicense);
  }
  await db.delete(licenseKeys);
  await db.insert(licenseKeys).values({
    licenseKey: key,
    hospitalName,
    activatedBy,
    isActivated: 1,
  });
  
  const license = await getActiveLicense();
  if (!license) throw new Error("Failed to activate license");
  return license;
}
