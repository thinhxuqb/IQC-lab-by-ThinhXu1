# GitHub release evidence

Source URL: https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/actions
Workflow file URL: https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/blob/main/.github/workflows/build-win.yml
Latest observed run: https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/actions/runs/31701517926
Latest observed commit: a068d3e27bc440fc1ca83c2eb1916be9013a9d45

Observed status on 2026-08-13: repository shows only 3 workflow runs, all failed. Latest run #3 has Status Failure, duration 1m16s, Artifacts –. The failing command in Build and Package is rendered by GitHub as:
`pnpm build && pn\`m exec electron-builder --wIn --x64 --publish never`
The relevant error is PowerShell: `The term 'pnm' is not recognized as a name of a cmdlet, function, script file, or executable program.`

The workflow file on GitHub still contains the typo and incorrect casing:
`run: pnpm build && pn\`m exec electron-builder --wIn --x64 --publish never`
The intended command is:
`run: pnpm build && pnpm exec electron-builder --win --x64 --publish never`

The repository tree contains `.github/workflows/build-win.yml` and `iqc-lab-source.zip`. The visible file page has an edit URL:
https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/edit/main/.github/workflows/build-win.yml

The Actions page currently has no successful run and no artifact available for download. This evidence must not be treated as a completed release.

The source archive needs separate verification for secrets and node_modules before release. The local WebDev checkpoint is not a Windows executable; it is only a project checkpoint.

Security note: do not write or expose any GitHub token in this file or user-facing messages.

Next action: edit the workflow file on GitHub or otherwise synchronize the local fix to the user repository, then wait for a new run and verify `.exe` and `.zip` artifacts.

## Verified successful release

Run URL: https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/actions/runs/31702628860
Job URL: https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/actions/runs/31702628860/job/94455253778
Commit: 6cb05cb0e8c73fb0b4bf094b0affbdfd442e5ecf
Status: Success
Total duration: 4m 15s
Build job duration: 4m 10s
Artifacts: 1
Artifact name: iqc-lab-windows-build
Artifact size: 272 MB
Artifact digest: sha256:d7f5a00aba2f7bcde1319802846d287c5ad7ff3167e13bc577f9aca6681901ac
Verified steps: Build and Package 2m43s; Verify Windows artifacts 1s; Upload Windows artifacts 10s.
Warning only: GitHub Actions reports Node.js 20 deprecation for action runtimes; it did not fail the build.

Browser download verification: download item `iqc-lab-windows-build.zip` is active in chrome://downloads. At 2026-08-13 13:09:54 local browser view, progress was 117 MB of 272 MB with an estimated 10 minutes remaining. The browser download is not visible as a completed file under /home/ubuntu/Downloads during the initial shell check, so local extraction has not yet been verified. The GitHub artifact itself is confirmed present and downloadable from the run page.

User monitoring request: user asked to open an additional screen; informed that a separate desktop/Remote Desktop screen cannot be exposed, and provided the run URL for parallel monitoring.

## Source archive audit

Repository root: https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/tree/main
Source archive found on GitHub: `iqc-lab-source.zip`, referenced by the workflow as the sanitized source package expanded before dependency installation.
Local project audit: no archive candidate was present under `/home/ubuntu/iqc-lab-manager` at audit depth, and no `.env`, `.env.*`, `.pem`, `.key`, `id_rsa*`, or non-pruned `node_modules` paths were found in the local project tree. The repository archive itself was not downloaded locally for byte-level listing; this limitation is recorded rather than overstated.

## Artifact content audit

Downloaded artifact path: `/home/ubuntu/Downloads/iqc-lab-windows-build.zip`
Downloaded size: 285,494,219 bytes
ZIP listing:
- `IQC Lab by ThinhXu 1.0.0.exe` — 142,643,381 bytes
- `IQC Lab by ThinhXu Setup 1.0.0.exe` — 142,810,584 bytes

Important correction: the successful artifact contains two Windows executables, not a separate `.zip` Portable package. The first executable is the unpacked/portable target produced by the workflow; the second is the NSIS installer. No `.zip` file exists inside this downloaded artifact, so the release handoff must describe the portable executable accurately and not claim a Portable ZIP.

## Portable ZIP workflow change

The local and GitHub editor workflow now adds a PowerShell `Create Portable ZIP` step. It selects the non-Setup executable from `release/*.exe`, creates `release/IQC-Lab-by-ThinhXu-Portable-1.0.0.zip` with `Compress-Archive`, verifies at least two EXE files and one ZIP, then uploads both patterns. The editor accepted 3,241 characters; commit is still pending user-confirmed action.

## Commit record

GitHub accepted the direct commit with message `ci: package portable Windows executable as ZIP`; commit SHA shown by GitHub: `78e53da4a7f064adaf6f17234aacea0d3c96ebdb`.
The post-commit page must still be checked through the raw workflow URL because the rendered summary appeared to show the older verify-only content; Portable ZIP creation is not considered synced until raw content confirms it.

## Run #5 diagnosis and corrected workflow
- Run #5 URL: https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/actions/runs/31704879622
- Run #5 failure: Invalid workflow file at line 1 because commit 78e53da contained only a fragment beginning with `uses: actions/cache@v4`.
- Local full workflow was verified to include `name`, `on`, `jobs`, Windows runner, source archive expansion, Electron build, Portable ZIP creation, artifact verification and upload.
- Commit 78e53da was replaced through GitHub editor using a direct full-document CodeMirror replacement.
- Corrected GitHub commit: `a032c26`, message `ci: restore valid Windows workflow and package Portable ZIP`.
- Corrected file page: https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/blob/main/.github/workflows/build-win.yml
- The corrected file page shows line 1 `name: Build Windows App (.exe)`, an `on` block, a `jobs` block, and a Portable ZIP step.
- A new Actions run should be triggered by commit `a032c26`; artifact verification remains pending.

## Run #6 diagnosis and corrected workflow
- Run #6 URL: https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/actions/runs/31705216879
- Run #6 failure: GitHub reported `.github/workflows/build-win.yml#L1` with `on` already defined at line 78 and `jobs` already defined at line 84.
- Cause: the previous browser editor replacement retained a duplicate fragment from the virtualized CodeMirror document.
- The workflow was replaced again through CodeMirror using `document.execCommand('selectAll')` and one complete 69-line YAML document. Console verification reported `onCount: 1` and `jobsCount: 1`.
- Corrected commit: `0d29941`, message `ci: remove duplicate workflow keys`.
- Corrected file page: https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/blob/main/.github/workflows/build-win.yml
- Corrected page reports 69 lines, starts with `name: Build Windows App (.exe)`, and contains one `on` block, one `jobs` block, Portable ZIP creation, verification and upload. New CI result is pending.
