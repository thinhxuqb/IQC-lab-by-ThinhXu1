import { describe, it, expect } from 'vitest';

describe('IQC Master License Key Validation', () => {
  const masterKey = 'IQC-THINHXU-2026-0001';

  it('accepts the official master license key for ThinhXu', () => {
    const cleanKey = masterKey.toUpperCase();
    const isValid = (cleanKey === masterKey || cleanKey === 'THINHXU-MASTER-2026');
    expect(isValid).toBe(true);
  });

  it('rejects random or forged keys', () => {
    const badKey = 'IQC-FAKE-2026-9999';
    const cleanKey = badKey.toUpperCase();
    const isValid = (cleanKey === masterKey || cleanKey === 'THINHXU-MASTER-2026');
    expect(isValid).toBe(false);
  });
});
