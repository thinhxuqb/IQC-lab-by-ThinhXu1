import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, float, date } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "technician", "manager", "admin"]).default("technician").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Danh mục xét nghiệm (Tests)
 * Ví dụ: Glucose, Cholesterol, Creatinine, ALT, AST...
 */
export const tests = mysqlTable("tests", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 50 }).notNull().unique(), // Mã xét nghiệm (vd: GLU, CHOL)
  name: varchar("name", { length: 150 }).notNull(), // Tên xét nghiệm (vd: Glucose máu)
  unit: varchar("unit", { length: 30 }).notNull(), // Đơn vị đo (vd: mmol/L, mg/dL)
  category: varchar("category", { length: 100 }), // Khoa/Nhóm (vd: Sinh hóa, Huyết học)
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Test = typeof tests.$inferSelect;
export type InsertTest = typeof tests.$inferInsert;

/**
 * Vật liệu nội kiểm (Control Materials)
 * Ví dụ: Bio-Rad Lyphochek Assayed Chemistry Control Level 1, 2, 3
 */
export const controlMaterials = mysqlTable("control_materials", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 150 }).notNull(), // Tên lô vật liệu (vd: Bio-Rad Level 1)
  lotNumber: varchar("lotNumber", { length: 50 }).notNull(), // Số lô (Lot number)
  testId: int("testId").notNull(), // Liên kết với xét nghiệm
  level: mysqlEnum("level", ["Level 1", "Level 2", "Level 3"]).notNull(), // Mức kiểm chứng
  targetMean: float("targetMean").notNull(), // Giá trị Mean mục tiêu từ nhà sản xuất
  targetSd: float("targetSd").notNull(), // Giá trị SD mục tiêu từ nhà sản xuất
  expirationDate: date("expirationDate"), // Hạn sử dụng
  isActive: int("isActive").default(1).notNull(), // 1: Đang sử dụng, 0: Ngừng
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ControlMaterial = typeof controlMaterials.$inferSelect;
export type InsertControlMaterial = typeof controlMaterials.$inferInsert;

/**
 * Kết quả nội kiểm hàng ngày (IQC Results)
 */
export const iqcResults = mysqlTable("iqc_results", {
  id: int("id").autoincrement().primaryKey(),
  testId: int("testId").notNull(), // Xét nghiệm
  controlMaterialId: int("controlMaterialId").notNull(), // Vật liệu nội kiểm & mức
  value: float("value").notNull(), // Giá trị đo được
  recordedAt: timestamp("recordedAt").notNull(), // Ngày giờ thực hiện
  zScore: float("zScore"), // Giá trị Z-score tính toán: (value - mean) / sd
  violations: text("violations"), // Các quy tắc Westgard vi phạm (JSON string hoặc danh sách vd: "1-2s, 1-3s")
  status: mysqlEnum("status", ["Accepted", "Rejected", "Warning"]).default("Accepted").notNull(),
  note: text("note"), // Ghi chú / Nguyên nhân / Hành động khắc phục
  technician: varchar("technician", { length: 100 }), // Kỹ thuật viên thực hiện
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type IqaiResult = typeof iqcResults.$inferSelect;
export type InsertIqcResult = typeof iqcResults.$inferInsert;

/**
 * Cài đặt thông tin phòng xét nghiệm (Lab Settings)
 */
export const labSettings = mysqlTable("lab_settings", {
  id: int("id").autoincrement().primaryKey(),
  labName: varchar("labName", { length: 200 }).notNull(), // Tên khoa/phòng xét nghiệm
  hospitalName: varchar("hospitalName", { length: 200 }), // Tên bệnh viện / cơ sở y tế
  address: text("address"), // Địa chỉ
  managerName: varchar("managerName", { length: 150 }), // Trưởng khoa xét nghiệm
  chiefTechnician: varchar("chiefTechnician", { length: 150 }), // Kỹ thuật trưởng
  logoUrl: text("logoUrl"), // URL logo phòng xét nghiệm
  phone: varchar("phone", { length: 50 }),
  email: varchar("email", { length: 320 }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LabSetting = typeof labSettings.$inferSelect;
export type InsertLabSetting = typeof labSettings.$inferInsert;

/**
 * Nhật ký hành động / Audit Trail (Audit Logs)
 */
export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"), // ID người thực hiện
  userName: varchar("userName", { length: 150 }), // Tên người thực hiện
  userRole: varchar("userRole", { length: 50 }), // Vai trò lúc thực hiện
  action: varchar("action", { length: 100 }).notNull(), // Hành động: CREATE, UPDATE, DELETE, LOGIN, APPROVE
  targetType: varchar("targetType", { length: 100 }).notNull(), // Đối tượng: TEST, MATERIAL, RESULT, SETTINGS
  targetId: int("targetId"), // ID đối tượng
  details: text("details"), // Chi tiết thay đổi / mô tả
  ipAddress: varchar("ipAddress", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

/**
 * Quản lý mã kích hoạt bản quyền offline (License Keys)
 * Cho phép kích hoạt phần mềm 1 lần duy nhất trên máy tính phòng xét nghiệm mà không cần đăng nhập trực tuyến
 */
export const licenseKeys = mysqlTable("license_keys", {
  id: int("id").autoincrement().primaryKey(),
  licenseKey: varchar("licenseKey", { length: 128 }).notNull().unique(), // Mã bản quyền (vd: IQC-THINHXU-2026-PRO)
  hospitalName: varchar("hospitalName", { length: 250 }).notNull(), // Tên cơ sở y tế / phòng khám được cấp phép
  activatedBy: varchar("activatedBy", { length: 150 }), // Người kích hoạt
  isActivated: int("isActivated").default(1).notNull(), // Trạng thái kích hoạt (1: Đã kích hoạt)
  activatedAt: timestamp("activatedAt").defaultNow().notNull(),
});

export type LicenseKey = typeof licenseKeys.$inferSelect;
export type InsertLicenseKey = typeof licenseKeys.$inferInsert;

/**
 * Cấu hình interface máy xét nghiệm. Các tham số này cũng được lưu trong
 * kho JSON khi chạy bản Electron offline.
 */
export const instrumentConfigs = mysqlTable("instrument_configs", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 150 }).notNull(),
  enabled: int("enabled").default(0).notNull(),
  connectionType: mysqlEnum("connectionType", ["tcp", "serial"]).notNull(),
  protocol: mysqlEnum("protocol", ["delimited", "hl7", "astm"]).default("delimited").notNull(),
  host: varchar("host", { length: 255 }),
  port: int("port"),
  serialPort: varchar("serialPort", { length: 100 }),
  baudRate: int("baudRate"),
  dataBits: int("dataBits").default(8).notNull(),
  stopBits: int("stopBits").default(1).notNull(),
  parity: mysqlEnum("parity", ["none", "even", "odd"]).default("none").notNull(),
  delimiter: varchar("delimiter", { length: 20 }).default("\\n").notNull(),
  codeFieldIndex: int("codeFieldIndex").default(0).notNull(),
  valueFieldIndex: int("valueFieldIndex").default(1).notNull(),
  receiveTimeoutMs: int("receiveTimeoutMs").default(1000).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type InstrumentConfig = typeof instrumentConfigs.$inferSelect;
export type InsertInstrumentConfig = typeof instrumentConfigs.$inferInsert;

export const instrumentMappings = mysqlTable("instrument_mappings", {
  id: int("id").autoincrement().primaryKey(),
  configId: int("configId").notNull(),
  instrumentCode: varchar("instrumentCode", { length: 100 }).notNull(),
  testId: int("testId").notNull(),
  controlMaterialId: int("controlMaterialId").notNull(),
  enabled: int("enabled").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type InstrumentMapping = typeof instrumentMappings.$inferSelect;
export type InsertInstrumentMapping = typeof instrumentMappings.$inferInsert;

export const instrumentLogs = mysqlTable("instrument_logs", {
  id: int("id").autoincrement().primaryKey(),
  configId: int("configId").notNull(),
  direction: mysqlEnum("direction", ["inbound", "outbound"]).default("inbound").notNull(),
  rawText: text("rawText").notNull(),
  protocol: mysqlEnum("protocol", ["delimited", "hl7", "astm"]).notNull(),
  messageId: varchar("messageId", { length: 150 }),
  receivedAt: timestamp("receivedAt").defaultNow().notNull(),
  parseStatus: mysqlEnum("parseStatus", ["received", "imported", "duplicate", "unmapped", "error"]).default("received").notNull(),
  dedupKey: varchar("dedupKey", { length: 128 }),
  resultId: int("resultId"),
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type InstrumentLog = typeof instrumentLogs.$inferSelect;
export type InsertInstrumentLog = typeof instrumentLogs.$inferInsert;
