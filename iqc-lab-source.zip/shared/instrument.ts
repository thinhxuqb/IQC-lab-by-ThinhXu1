export type InstrumentConnectionType = "tcp" | "serial";
export type InstrumentProtocol = "delimited" | "hl7" | "astm";
export type InstrumentParity = "none" | "even" | "odd";
export type InstrumentConnectionStatus = "stopped" | "connecting" | "connected" | "error";

export type InstrumentConfig = {
  id: number;
  name: string;
  enabled: number;
  connectionType: InstrumentConnectionType;
  protocol: InstrumentProtocol;
  host: string | null;
  port: number | null;
  serialPort: string | null;
  baudRate: number | null;
  dataBits: number;
  stopBits: number;
  parity: InstrumentParity;
  delimiter: string;
  codeFieldIndex: number;
  valueFieldIndex: number;
  receiveTimeoutMs: number;
  createdAt: Date;
  updatedAt: Date;
};

export type InstrumentMapping = {
  id: number;
  configId: number;
  instrumentCode: string;
  testId: number;
  controlMaterialId: number;
  enabled: number;
  createdAt: Date;
  updatedAt: Date;
};

export type InstrumentLogStatus = "received" | "imported" | "duplicate" | "unmapped" | "error";

export type InstrumentLog = {
  id: number;
  configId: number;
  direction: "inbound" | "outbound";
  rawText: string;
  protocol: InstrumentProtocol;
  messageId: string | null;
  receivedAt: Date;
  parseStatus: InstrumentLogStatus;
  dedupKey: string | null;
  resultId: number | null;
  errorMessage: string | null;
  createdAt: Date;
};

export type InstrumentRuntimeState = {
  configId: number;
  status: InstrumentConnectionStatus;
  message: string;
  connectedAt: Date | null;
  lastMessageAt: Date | null;
};

export type ParsedInstrumentResult = {
  instrumentCode: string;
  value: number;
  unit: string | null;
  measuredAt: Date | null;
  sampleId: string | null;
  messageId: string | null;
};

export type ParsedInstrumentFrame = {
  protocol: InstrumentProtocol;
  messageId: string | null;
  results: ParsedInstrumentResult[];
};

export function decodeDelimiter(value: string | null | undefined) {
  return (value || "\\n")
    .replaceAll("\\r", "\r")
    .replaceAll("\\n", "\n")
    .replaceAll("\\t", "\t");
}

export function normalizeInstrumentCode(value: unknown) {
  return String(value ?? "").trim().toUpperCase();
}

export function isInstrumentProtocol(value: unknown): value is InstrumentProtocol {
  return value === "delimited" || value === "hl7" || value === "astm";
}
