import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const projectRoot = resolve(import.meta.dirname, "..");

function readProjectFile(relativePath: string) {
  return readFileSync(resolve(projectRoot, relativePath), "utf8");
}

describe("default laboratory branding", () => {
  it("is wired into the activation screen and sidebar", () => {
    const source = readProjectFile("client/src/components/DashboardLayout.tsx");

    expect(source).toContain('import { DEFAULT_LAB_LOGO_ALT, DEFAULT_LAB_LOGO_DATA_URL } from "@shared/branding"');
    expect(source).toContain('<img src={DEFAULT_LAB_LOGO_DATA_URL} alt={DEFAULT_LAB_LOGO_ALT}');
    expect(source).toContain('<SidebarHeader className="h-16 justify-center">');
    expect(source).toContain('<img src={displayedLogoUrl} alt={DEFAULT_LAB_LOGO_ALT} className="h-full w-full object-contain" />');
    expect(source).toMatch(/const displayedLogoUrl = settingsQuery\.data\?\.logoUrl \|\| DEFAULT_LAB_LOGO_DATA_URL;/);
    expect(source).toContain("DEFAULT_LAB_LOGO_DATA_URL");
  });

  it("is wired into SettingsPage as the default logo", () => {
    const source = readProjectFile("client/src/pages/SettingsPage.tsx");

    expect(source).toContain('import { DEFAULT_LAB_LOGO_ALT, DEFAULT_LAB_LOGO_DATA_URL } from "@shared/branding"');
    expect(source).toContain("const displayedLogoUrl = form.logoUrl || DEFAULT_LAB_LOGO_DATA_URL;");
    expect(source).toContain('alt={DEFAULT_LAB_LOGO_ALT}');
  });

  it("contains the offline MEDIC Quang Binh branding asset", () => {
    const branding = readProjectFile("shared/branding.ts");

    expect(branding).toContain("MEDIC QUẢNG BÌNH");
    expect(branding).toContain("data:image/png;base64,");
  });
});
