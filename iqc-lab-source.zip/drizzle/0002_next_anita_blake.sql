CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`userName` varchar(150),
	`userRole` varchar(50),
	`action` varchar(100) NOT NULL,
	`targetType` varchar(100) NOT NULL,
	`targetId` int,
	`details` text,
	`ipAddress` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lab_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`labName` varchar(200) NOT NULL,
	`hospitalName` varchar(200),
	`address` text,
	`managerName` varchar(150),
	`chiefTechnician` varchar(150),
	`logoUrl` text,
	`phone` varchar(50),
	`email` varchar(320),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `lab_settings_id` PRIMARY KEY(`id`)
);
