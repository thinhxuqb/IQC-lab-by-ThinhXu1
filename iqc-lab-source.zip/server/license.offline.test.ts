import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { activateLicense, getActiveLicense } from "./db";

describe("offline license persistence", () => {
  const originalDatabaseUrl = process.env.DATABASE_URL;
  const originalDataDir = process.env.IQC_DATA_DIR;
  let dataDir = "";

  beforeEach(() => {
    delete process.env.DATABASE_URL;
    dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "iqc-lab-license-"));
    process.env.IQC_DATA_DIR = dataDir;
  });

  afterEach(() => {
    if (originalDatabaseUrl === undefined) delete process.env.DATABASE_URL;
    else process.env.DATABASE_URL = originalDatabaseUrl;

    if (originalDataDir === undefined) delete process.env.IQC_DATA_DIR;
    else process.env.IQC_DATA_DIR = originalDataDir;

    fs.rmSync(dataDir, { recursive: true, force: true });
  });

  it("writes and reads the activated license without a remote database", async () => {
    expect(await getActiveLicense()).toBeUndefined();

    const activated = await activateLicense(
      "IQC-THINHXU-2026-0001",
      "MEDIC QUANG BINH",
      "Test operator"
    );

    expect(activated.licenseKey).toBe("IQC-THINHXU-2026-0001");
    expect(activated.hospitalName).toBe("MEDIC QUANG BINH");
    expect(activated.isActivated).toBe(1);
    expect(fs.existsSync(path.join(dataDir, "license.json"))).toBe(true);

    const persisted = await getActiveLicense();
    expect(persisted?.licenseKey).toBe("IQC-THINHXU-2026-0001");
    expect(persisted?.activatedAt).toBeInstanceOf(Date);
  });
});

export {};
