export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { encodeOAuthState, OAUTH_STATE_COOKIE } from "@shared/const";

export const startLogin = () => {
  const oauthPortalUrl = import.meta.env.VITE_OAUTH_PORTAL_URL;
  const appId = import.meta.env.VITE_APP_ID;
  
  // Nếu chạy trong Electron (localhost / 127.0.0.1), sử dụng domain production chính thức được cấu hình trong OAuth Portal
  let redirectUri = `${window.location.origin}/api/oauth/callback`;
  if (window.location.hostname === '127.0.0.1' || window.location.hostname === 'localhost') {
    // Domain production của dự án trên Manus
    redirectUri = 'https://iqclabmgr-bn359qy5.manus.space/api/oauth/callback';
  }

  const nonce = crypto.randomUUID();
  document.cookie = `${OAUTH_STATE_COOKIE}=${nonce}; Path=/; Max-Age=600; SameSite=None; Secure`;
  const state = encodeOAuthState({ redirectUri, nonce });

  const url = new URL(`${oauthPortalUrl}/app-auth`);
  url.searchParams.set("appId", appId);
  url.searchParams.set("redirectUri", redirectUri);
  url.searchParams.set("state", state);
  url.searchParams.set("type", "signIn");

  window.location.href = url.toString();
};
