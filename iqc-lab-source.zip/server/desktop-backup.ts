import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const ENCRYPTION_KEY = crypto.scryptSync('iqc-lab-thinhxu-secret-key', 'salt', 32);
const ALGORITHM = 'aes-256-cbc';

export function setupDesktopBackup(dbPath: string, backupDir: string) {
  try {
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }
    if (fs.existsSync(dbPath)) {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupPath = path.join(backupDir, `iqc_backup_${timestamp}.enc`);
      
      const fileBuffer = fs.readFileSync(dbPath);
      const iv = crypto.randomBytes(16);
      const cipher = crypto.createCipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
      const encrypted = Buffer.concat([iv, cipher.update(fileBuffer), cipher.final()]);
      
      fs.writeFileSync(backupPath, encrypted);
      console.log(`[Desktop Encrypted Backup] Đã sao lưu và mã hóa thành công tại: ${backupPath}`);
    }
  } catch (err) {
    console.error('[Desktop Backup] Lỗi sao lưu dữ liệu mã hóa:', err);
  }
}
