import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const packageJson = JSON.parse(readFileSync("package.json", "utf8")) as {
  main: string;
  version: string;
  build: {
    publish: { provider: string; owner: string; repo: string };
    files: string[];
  };
};
const workflow = readFileSync(".github/workflows/build-win.yml", "utf8");

describe("Electron auto-update release configuration", () => {
  it("uses the CommonJS main process and packages the preload bridge", () => {
    expect(packageJson.main).toBe("electron.cjs");
    expect(packageJson.build.files).toContain("preload.cjs");
  });

  it("targets the IQC Lab GitHub repository for update releases", () => {
    expect(packageJson.build.publish.provider).toBe("github");
    expect(packageJson.build.publish.owner).toBe("thinhxuqb");
    expect(packageJson.build.publish.repo).toBe("IQC-lab-by-ThinhXu1");
  });

  it("publishes tagged builds and verifies updater metadata", () => {
    expect(workflow).toContain("tags: ['v*']");
    expect(workflow).toContain("--publish always");
    expect(workflow).toContain("release/latest*.yml");
    expect(workflow).toContain("Expected latest.yml metadata");
  });

  it("automatically creates the next patch release after changes land on main", () => {
    const releaseWorkflow = readFileSync(".github/workflows/release-on-main.yml", "utf8");
    expect(releaseWorkflow).toContain("branches: [main]");
    expect(releaseWorkflow).toContain("NEXT_VERSION");
    expect(releaseWorkflow).toContain('git tag -a "v${NEXT_VERSION}"');
    expect(releaseWorkflow).toContain('git push origin HEAD:main "v${NEXT_VERSION}"');
  });

  it("downloads a detected update automatically", () => {
    const electronSource = readFileSync("electron.cjs", "utf8");
    expect(electronSource).toContain("autoUpdater.autoDownload = true");
    expect(electronSource).toContain("Đang tự động tải xuống");
  });

  it("shows download progress and provides a manual check in Settings", () => {
    const bannerSource = readFileSync("client/src/components/UpdateBanner.tsx", "utf8");
    const settingsSource = readFileSync("client/src/pages/SettingsPage.tsx", "utf8");
    expect(bannerSource).toContain("Đang tải bản cập nhật");
    expect(bannerSource).toContain("Sau khi tải xong, ứng dụng sẽ cài đặt khi bạn khởi động lại.");
    expect(settingsSource).toContain("Kiểm tra cập nhật");
    expect(settingsSource).toContain("updatesApi.check()");
  });
});
