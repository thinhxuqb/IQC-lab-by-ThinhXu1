

### Update UI — 2026-10-02

- [x] Thông báo giao diện khi bản cập nhật đang được tải, có phiên bản và phần trăm tiến độ
- [x] Hướng dẫn người dùng khởi động lại để hoàn tất cài đặt bản cập nhật
- [x] Nút “Kiểm tra cập nhật” trong phần Cài đặt, có trạng thái đang kiểm tra và toast kết quả
- [x] Kiểm thử cuối: `pnpm check`, build production, 42 test passed và 1 skipped
