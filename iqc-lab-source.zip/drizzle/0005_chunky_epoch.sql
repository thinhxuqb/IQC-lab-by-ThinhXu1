CREATE TABLE `instrument_configs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(150) NOT NULL,
	`enabled` int NOT NULL DEFAULT 0,
	`connectionType` enum('tcp','serial') NOT NULL,
	`protocol` enum('delimited','hl7','astm') NOT NULL DEFAULT 'delimited',
	`host` varchar(255),
	`port` int,
	`serialPort` varchar(100),
	`baudRate` int,
	`dataBits` int NOT NULL DEFAULT 8,
	`stopBits` int NOT NULL DEFAULT 1,
	`parity` enum('none','even','odd') NOT NULL DEFAULT 'none',
	`delimiter` varchar(20) NOT NULL DEFAULT '\n',
	`codeFieldIndex` int NOT NULL DEFAULT 0,
	`valueFieldIndex` int NOT NULL DEFAULT 1,
	`receiveTimeoutMs` int NOT NULL DEFAULT 1000,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `instrument_configs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `instrument_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`configId` int NOT NULL,
	`direction` enum('inbound','outbound') NOT NULL DEFAULT 'inbound',
	`rawText` text NOT NULL,
	`protocol` enum('delimited','hl7','astm') NOT NULL,
	`messageId` varchar(150),
	`receivedAt` timestamp NOT NULL DEFAULT (now()),
	`parseStatus` enum('received','imported','duplicate','unmapped','error') NOT NULL DEFAULT 'received',
	`dedupKey` varchar(128),
	`resultId` int,
	`errorMessage` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `instrument_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `instrument_mappings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`configId` int NOT NULL,
	`instrumentCode` varchar(100) NOT NULL,
	`testId` int NOT NULL,
	`controlMaterialId` int NOT NULL,
	`enabled` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `instrument_mappings_id` PRIMARY KEY(`id`)
);
