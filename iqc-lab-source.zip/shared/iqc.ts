export type WestgardRule = "1-2s" | "1-3s" | "2-2s" | "R-4s" | "4-1s" | "10x";

export type IqcStatistics = {
  count: number;
  mean: number | null;
  sd: number | null;
  cv: number | null;
  violationCount: number;
};

export function zScore(value: number, targetMean: number, targetSd: number) {
  if (!Number.isFinite(value) || targetSd <= 0) return null;
  return (value - targetMean) / targetSd;
}

export function calculateWestgardViolations(zScores: number[]): WestgardRule[] {
  const current = zScores.at(-1);
  if (current === undefined) return [];

  const rules: WestgardRule[] = [];
  const absCurrent = Math.abs(current);

  if (absCurrent >= 2) rules.push("1-2s");
  if (absCurrent >= 3) rules.push("1-3s");

  const previous = zScores.at(-2);
  if (previous !== undefined) {
    if (Math.abs(previous) >= 2 && Math.abs(current) >= 2 && Math.sign(previous) === Math.sign(current)) {
      rules.push("2-2s");
    }
    if (Math.abs(current - previous) >= 4) rules.push("R-4s");
  }

  const lastFour = zScores.slice(-4);
  if (lastFour.length === 4 && lastFour.every((score) => score >= 1) || lastFour.length === 4 && lastFour.every((score) => score <= -1)) {
    rules.push("4-1s");
  }

  const lastTen = zScores.slice(-10);
  if (lastTen.length === 10 && lastTen.every((score) => score > 0) || lastTen.length === 10 && lastTen.every((score) => score < 0)) {
    rules.push("10x");
  }

  return rules;
}

export function calculateStatistics(values: number[], violationCount = 0): IqcStatistics {
  const validValues = values.filter((value) => Number.isFinite(value));
  if (validValues.length === 0) {
    return { count: 0, mean: null, sd: null, cv: null, violationCount };
  }

  const mean = validValues.reduce((sum, value) => sum + value, 0) / validValues.length;
  const variance = validValues.length > 1
    ? validValues.reduce((sum, value) => sum + (value - mean) ** 2, 0) / (validValues.length - 1)
    : 0;
  const sd = Math.sqrt(variance);
  const cv = mean === 0 ? null : (sd / Math.abs(mean)) * 100;

  return { count: validValues.length, mean, sd, cv, violationCount };
}

export function classifyStatus(rules: WestgardRule[]) {
  if (rules.some((rule) => ["1-3s", "2-2s", "R-4s", "4-1s", "10x"].includes(rule))) return "Rejected" as const;
  if (rules.includes("1-2s")) return "Warning" as const;
  return "Accepted" as const;
}

export function formatRuleLabel(rule: string) {
  return rule.replace("-", "–");
}

export function parseViolations(value: string | null | undefined): WestgardRule[] {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return value.split(",").map((item) => item.trim()).filter(Boolean) as WestgardRule[];
  }
}

export const WESTGARD_RULE_DESCRIPTIONS: Record<WestgardRule, string> = {
  "1-2s": "Một điểm vượt quá ±2SD — tín hiệu cảnh báo.",
  "1-3s": "Một điểm vượt quá ±3SD — loại run kiểm soát.",
  "2-2s": "Hai điểm liên tiếp cùng phía vượt quá ±2SD.",
  "R-4s": "Hai điểm liên tiếp chênh nhau từ 4SD trở lên.",
  "4-1s": "Bốn điểm liên tiếp cùng phía vượt quá ±1SD.",
  "10x": "Mười điểm liên tiếp nằm cùng một phía so với Mean.",
};

export const LEVELS = ["Level 1", "Level 2", "Level 3"] as const;
export type ControlLevel = (typeof LEVELS)[number];

export const chartPalette = {
  navy: "#14314a",
  teal: "#2a9d8f",
  mint: "#cfeee8",
  warning: "#e9a23b",
  danger: "#d95d5d",
  grid: "#dce7eb",
  ink: "#1b2a36",
};

export function toLocalDateTimeInput(date = new Date()) {
  const offset = date.getTimezoneOffset();
  return new Date(date.getTime() - offset * 60_000).toISOString().slice(0, 16);
}

export function formatNumber(value: number | null | undefined, digits = 2) {
  return value === null || value === undefined || !Number.isFinite(value) ? "—" : value.toFixed(digits);
}
