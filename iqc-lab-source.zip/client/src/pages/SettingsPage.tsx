import { useEffect, useMemo, useRef, useState } from "react";
import { Building2, Check, Download, ImagePlus, Mail, Phone, RefreshCw, Save, ShieldCheck, Upload, Users } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { DEFAULT_LAB_LOGO_ALT, DEFAULT_LAB_LOGO_DATA_URL } from "@shared/branding";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { getElectronUpdatesApi, type UpdateState } from "@/lib/electron-updates";

const roleLabels = {
  user: "Người dùng",
  technician: "Kỹ thuật viên",
  manager: "Quản lý",
  admin: "Quản trị viên",
} as const;

type SettingsForm = {
  labName: string;
  hospitalName: string;
  address: string;
  managerName: string;
  chiefTechnician: string;
  logoUrl: string;
  phone: string;
  email: string;
};

const emptyForm: SettingsForm = {
  labName: "",
  hospitalName: "",
  address: "",
  managerName: "",
  chiefTechnician: "",
  logoUrl: "",
  phone: "",
  email: "",
};

const initialUpdateState: UpdateState = { status: "unsupported", version: null, progress: 0, message: null };

function Field({ label, value, onChange, placeholder, type = "text" }: { label: string; value: string; onChange: (value: string) => void; placeholder?: string; type?: string }) {
  return (
    <div className="space-y-2">
      <Label className="text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">{label}</Label>
      <Input type={type} value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} className="h-10 rounded-xl border-[#dcebea] bg-white" />
    </div>
  );
}

export default function SettingsPage() {
  const { user } = useAuth();
  const isManager = user?.role === "manager" || user?.role === "admin";
  const isAdmin = user?.role === "admin";
  const settingsQuery = trpc.settings.get.useQuery(undefined, { enabled: Boolean(user) });
  const usersQuery = trpc.users.list.useQuery(undefined, { enabled: isAdmin });
  const saveMutation = trpc.settings.update.useMutation();
  const uploadMutation = trpc.settings.uploadLogo.useMutation();
  const updateRoleMutation = trpc.users.updateRole.useMutation();
  const utils = trpc.useUtils();
  const fileRef = useRef<HTMLInputElement>(null);
  const [form, setForm] = useState<SettingsForm>(emptyForm);
  const updatesApi = getElectronUpdatesApi();
  const [updateState, setUpdateState] = useState<UpdateState>(initialUpdateState);
  const [checkingUpdate, setCheckingUpdate] = useState(false);
  const displayedLogoUrl = form.logoUrl || DEFAULT_LAB_LOGO_DATA_URL;
  const exportBackupQuery = trpc.settings.exportBackup.useQuery(undefined, { enabled: false });
  const importBackupMutation = trpc.settings.importBackup.useMutation({
    onSuccess: () => {
      toast.success("Khôi phục dữ liệu phòng xét nghiệm thành công!");
      utils.settings.get.invalidate();
    },
    onError: (err) => {
      toast.error(`Khôi phục thất bại: ${err.message}`);
    },
  });

  useEffect(() => {
    const api = getElectronUpdatesApi();
    if (!api) return;
    let mounted = true;
    api.getState().then((state) => { if (mounted) setUpdateState(state); });
    const unsubscribe = api.onState((state) => { if (mounted) setUpdateState(state); });
    return () => { mounted = false; unsubscribe(); };
  }, []);

  const handleCheckForUpdates = async () => {
    if (!updatesApi || checkingUpdate) return;
    setCheckingUpdate(true);
    try {
      const state = await updatesApi.check();
      setUpdateState(state);
      if (state.status === "idle") toast.success("Bạn đang sử dụng phiên bản mới nhất.");
      else if (state.status === "checking") toast.info("Đang kiểm tra phiên bản mới...");
      else if (state.status === "error") toast.error(state.message ?? "Không thể kiểm tra cập nhật.");
      else toast.success(state.message ?? "Đã tìm thấy bản cập nhật mới.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Không thể kiểm tra cập nhật.");
    } finally {
      setCheckingUpdate(false);
    }
  };

  const handleExportBackup = async () => {
    try {
      toast.info("Đang tạo tệp sao lưu dữ liệu...");
      const result = await utils.client.settings.exportBackup.query();
      const jsonString = JSON.stringify(result, null, 2);
      const blob = new Blob([jsonString], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, "");
      link.download = `iqc-backup-${dateStr}.iqc-backup`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      toast.success("Đã tải xuống tệp sao lưu .iqc-backup thành công!");
    } catch (error: any) {
      toast.error(`Xuất sao lưu thất bại: ${error.message || error}`);
    }
  };

  const handleImportBackup = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!confirm("Cảnh báo: Khôi phục dữ liệu sẽ ghi đè toàn bộ danh mục xét nghiệm, vật liệu nội kiểm và kết quả QC hiện tại bằng dữ liệu từ tệp sao lưu. Bạn có chắc chắn muốn tiếp tục?")) {
      event.target.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const parsed = JSON.parse(content);
        if (!parsed || !parsed.data) {
          throw new Error("Tệp sao lưu không đúng định dạng .iqc-backup hợp lệ.");
        }
        importBackupMutation.mutate(parsed);
      } catch (err: any) {
        toast.error(`Không thể đọc tệp sao lưu: ${err.message}`);
      } finally {
        event.target.value = "";
      }
    };
    reader.readAsText(file);
  };

  useEffect(() => {
    if (!settingsQuery.data) return;
    setForm({
      labName: settingsQuery.data.labName ?? "",
      hospitalName: settingsQuery.data.hospitalName ?? "",
      address: settingsQuery.data.address ?? "",
      managerName: settingsQuery.data.managerName ?? "",
      chiefTechnician: settingsQuery.data.chiefTechnician ?? "",
      logoUrl: settingsQuery.data.logoUrl ?? "",
      phone: settingsQuery.data.phone ?? "",
      email: settingsQuery.data.email ?? "",
    });
  }, [settingsQuery.data]);

  const roleOptions = useMemo(() => Object.entries(roleLabels) as Array<[keyof typeof roleLabels, string]>, []);

  if (!isManager) {
    return (
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center bg-[#f5f9f9] p-6">
        <Card className="max-w-md border-0 shadow-[0_12px_35px_rgba(20,49,74,0.08)]"><CardContent className="space-y-3 p-8 text-center"><ShieldCheck className="mx-auto h-10 w-10 text-primary" /><h1 className="text-xl font-semibold text-[#14314a]">Không có quyền truy cập</h1><p className="text-sm leading-6 text-muted-foreground">Chỉ quản lý hoặc quản trị viên mới được thay đổi cấu hình phòng xét nghiệm.</p></CardContent></Card>
      </div>
    );
  }

  const updateField = (key: keyof SettingsForm, value: string) => setForm((current) => ({ ...current, [key]: value }));
  const saveSettings = async () => {
    if (!form.labName.trim()) {
      toast.error("Vui lòng nhập tên phòng xét nghiệm.");
      return;
    }
    try {
      await saveMutation.mutateAsync({ ...form, logoUrl: form.logoUrl || null });
      await utils.settings.get.invalidate();
      toast.success("Đã lưu thông tin phòng xét nghiệm.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Không thể lưu cấu hình.");
    }
  };

  const uploadLogo = (file: File) => {
    const allowed = ["image/png", "image/jpeg"] as const;
    if (!allowed.includes(file.type as (typeof allowed)[number])) {
      toast.error("Logo chỉ hỗ trợ PNG hoặc JPEG để tương thích với báo cáo PDF.");
      return;
    }
    if (file.size > 4 * 1024 * 1024) {
      toast.error("Dung lượng logo không được vượt quá 4 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = async () => {
      const raw = typeof reader.result === "string" ? reader.result : "";
      const base64 = raw.split(",")[1] ?? "";
      try {
        const saved = await uploadMutation.mutateAsync({ fileName: file.name, contentType: file.type as (typeof allowed)[number], base64 });
        updateField("logoUrl", saved.logoUrl ?? "");
        await utils.settings.get.invalidate();
        await utils.audit.list.invalidate();
        toast.success("Đã lưu logo phòng xét nghiệm trên máy tính này.");
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Không thể tải logo lên.");
      }
    };
    reader.readAsDataURL(file);
  };

  const resetLogo = async () => {
    try {
      updateField("logoUrl", "");
      await saveMutation.mutateAsync({ ...form, logoUrl: null });
      await utils.settings.get.invalidate();
      await utils.audit.list.invalidate();
      toast.success("Đã khôi phục logo mặc định của IQC Lab.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Không thể khôi phục logo mặc định.");
    }
  };

  const changeRole = async (id: number, role: keyof typeof roleLabels) => {
    try {
      await updateRoleMutation.mutateAsync({ id, role });
      await utils.users.list.invalidate();
      await utils.audit.list.invalidate();
      toast.success("Đã cập nhật vai trò người dùng.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Không thể cập nhật vai trò.");
    }
  };

  return (
    <div className="min-h-[calc(100vh-2rem)] bg-[#f5f9f9] px-1 py-1 sm:px-3 lg:px-6">
      <div className="mx-auto max-w-[1280px] space-y-7 py-4">
        <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
          <div><div className="mb-2 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary/80"><span className="h-1.5 w-1.5 rounded-full bg-primary" />Administration · 08</div><h1 className="text-3xl font-semibold tracking-[-0.03em] text-[#14314a] md:text-4xl">Cài đặt phòng xét nghiệm</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">Quản lý nhận diện đơn vị, thông tin liên hệ và cơ chế phân quyền của IQC Lab by ThinhXu.</p></div>
          <Badge variant="outline" className="w-fit gap-2 rounded-full border-[#bde8df] bg-[#e9f5f3] px-3 py-1.5 text-primary"><Check className="h-3.5 w-3.5" />{isAdmin ? "Quản trị viên" : "Quản lý"}</Badge>
        </div>

        <div className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
          <Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="border-b border-[#edf3f3] pb-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#e9f5f3] p-2.5 text-primary"><Building2 className="h-5 w-5" /></div><div><CardTitle className="text-base text-[#14314a]">Thông tin nhận diện</CardTitle><p className="mt-1 text-xs text-muted-foreground">Thông tin này được dùng trên màn hình và các báo cáo nội kiểm.</p></div></div></CardHeader><CardContent className="space-y-5 p-5"><div className="grid gap-4 sm:grid-cols-2"><Field label="Tên phòng xét nghiệm *" value={form.labName} onChange={(value) => updateField("labName", value)} placeholder="VD: Khoa Xét nghiệm" /><Field label="Bệnh viện / cơ sở y tế" value={form.hospitalName} onChange={(value) => updateField("hospitalName", value)} placeholder="VD: Bệnh viện Đa khoa..." /></div><div className="grid gap-4 sm:grid-cols-2"><Field label="Trưởng khoa xét nghiệm" value={form.managerName} onChange={(value) => updateField("managerName", value)} placeholder="Họ và tên" /><Field label="Kỹ thuật trưởng" value={form.chiefTechnician} onChange={(value) => updateField("chiefTechnician", value)} placeholder="Họ và tên" /></div><div className="grid gap-4 sm:grid-cols-2"><Field label="Số điện thoại" value={form.phone} onChange={(value) => updateField("phone", value)} placeholder="Số điện thoại liên hệ" type="tel" /><Field label="Email" value={form.email} onChange={(value) => updateField("email", value)} placeholder="lab@example.org" type="email" /></div><div className="space-y-2"><Label className="text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">Địa chỉ</Label><Textarea value={form.address} onChange={(event) => updateField("address", event.target.value)} placeholder="Địa chỉ phòng xét nghiệm" className="min-h-24 rounded-xl border-[#dcebea] bg-white" /></div><div className="flex justify-end"><Button onClick={saveSettings} disabled={saveMutation.isPending} className="h-10 gap-2 rounded-xl bg-[#14314a] px-4 hover:bg-[#214a67]"><Save className="h-4 w-4" />{saveMutation.isPending ? "Đang lưu..." : "Lưu cài đặt"}</Button></div></CardContent></Card>

          <Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="border-b border-[#edf3f3] pb-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#eef4fb] p-2.5 text-[#3b6e95]"><ImagePlus className="h-5 w-5" /></div><div><CardTitle className="text-base text-[#14314a]">Logo phòng xét nghiệm</CardTitle><p className="mt-1 text-xs text-muted-foreground">PNG hoặc JPEG · tối đa 4 MB · lưu cục bộ.</p>
</div></div></CardHeader><CardContent className="space-y-5 p-5"><div className="flex min-h-48 items-center justify-center rounded-2xl border border-dashed border-[#cddfe2] bg-[#f8fbfb] p-6"><img src={displayedLogoUrl} alt={DEFAULT_LAB_LOGO_ALT} className="max-h-36 max-w-full object-contain" /></div><input ref={fileRef} type="file" accept="image/png,image/jpeg"
 className="hidden" onChange={(event) => { const file = event.target.files?.[0]; if (file) uploadLogo(file); event.currentTarget.value = ""; }} /><div className="flex flex-col gap-2 sm:flex-row"><Button variant="outline" onClick={() => fileRef.current?.click()} disabled={uploadMutation.isPending} className="flex-1 gap-2 rounded-xl border-[#cddfe2] bg-white"><Upload className="h-4 w-4" />{uploadMutation.isPending ? "Đang lưu..." : "Tải logo lên"}</Button><Button variant="ghost" onClick={resetLogo} disabled={!form.logoUrl || saveMutation.isPending} className="rounded-xl text-[#31556a]">Khôi phục mặc định</Button></div><p className="text-xs leading-5 text-muted-foreground">Logo được lưu cục bộ trong thư mục dữ liệu của ứng dụng và sẽ được dùng trên giao diện cùng báo cáo PDF, không cần kết nối Internet.</p>
</CardContent></Card>
        </div>

        <Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]">
          <CardHeader className="border-b border-[#edf3f3] pb-5">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-[#e9f5f3] p-2.5 text-primary"><ShieldCheck className="h-5 w-5" /></div>
              <div>
                <CardTitle className="text-base text-[#14314a]">Thông tin phần mềm & Sao lưu dữ liệu</CardTitle>
                <p className="mt-1 text-xs text-muted-foreground">Bản quyền và tính năng xuất / nhập tệp sao lưu .iqc-backup.</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 p-5">
            <div className="rounded-2xl border border-[#dcebea] bg-[#f8fbfb] p-4 space-y-1.5">
              <p className="text-sm font-semibold text-[#14314a]">IQC Lab by ThinhXu (Phiên bản v1.0.27)</p>
              <p className="text-sm font-medium text-primary">Bản quyền thuộc về ThinhXuQB - 0855 703 123</p>
              <p className="text-xs text-muted-foreground">Phần mềm hỗ trợ quản lý nội kiểm xét nghiệm y tế, biểu đồ Levey-Jennings, quy tắc Westgard tự động và báo cáo offline.</p>
            </div>

            <div className="flex flex-col gap-3 rounded-2xl border border-[#cddfe2] bg-white p-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="min-w-0">
                <h4 className="text-sm font-semibold text-[#14314a]">Cập nhật phần mềm</h4>
                <p className="mt-1 text-xs leading-5 text-muted-foreground">
                  {updatesApi ? (updateState.message ?? "Tự động kiểm tra khi mở ứng dụng; bạn cũng có thể kiểm tra ngay.") : "Tính năng này chỉ khả dụng trong bản cài Windows của IQC Lab."}
                </p>
              </div>
              <Button onClick={handleCheckForUpdates} disabled={!updatesApi || checkingUpdate || updateState.status === "downloading"} variant="outline" className="shrink-0 gap-2 rounded-xl border-[#cddfe2] bg-white text-[#14314a] hover:bg-[#f8fbfb]">
                <RefreshCw className={`h-4 w-4 text-primary ${checkingUpdate ? "animate-spin" : ""}`} />
                {checkingUpdate ? "Đang kiểm tra..." : "Kiểm tra cập nhật"}
              </Button>
            </div>

            <div className="rounded-2xl border border-[#dcebea] bg-white p-4 space-y-3">
              <div>
                <h4 className="text-sm font-semibold text-[#14314a]">Sao lưu & Khôi phục dữ liệu (.iqc-backup)</h4>
                <p className="text-xs text-muted-foreground mt-0.5">Xuất toàn bộ cấu hình phòng xét nghiệm, danh mục xét nghiệm, vật liệu nội kiểm, kết quả QC và cấu hình Interface/mapping thành tệp .iqc-backup để lưu trữ hoặc khôi phục.</p>
              </div>
              <div className="flex flex-wrap gap-3 pt-1">
                <Button onClick={handleExportBackup} variant="outline" className="h-10 rounded-xl border-[#dcebea] text-[#14314a] hover:bg-[#f8fbfb]">
                  <Download className="mr-2 h-4 w-4 text-primary" /> Xuất tệp .iqc-backup
                </Button>
                <label className="inline-flex cursor-pointer items-center justify-center rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-sm hover:bg-primary/90 transition-colors">
                  <RefreshCw className="mr-2 h-4 w-4" /> Khôi phục từ .iqc-backup
                  <input type="file" accept=".iqc-backup,.json" onChange={handleImportBackup} className="hidden" />
                </label>
              </div>
            </div>
          </CardContent>
        </Card>

        {isAdmin ? <Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="border-b border-[#edf3f3] pb-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#fff5df] p-2.5 text-[#a16b18]"><Users className="h-5 w-5" /></div><div><CardTitle className="text-base text-[#14314a]">Phân quyền người dùng</CardTitle><p className="mt-1 text-xs text-muted-foreground">Chỉ quản trị viên có thể thay đổi vai trò truy cập.</p></div></div></CardHeader><CardContent className="p-0">{usersQuery.isLoading ? <div className="p-6 text-sm text-muted-foreground">Đang tải danh sách người dùng...</div> : usersQuery.data?.length ? <div className="divide-y divide-[#edf3f3]">{usersQuery.data.map((account) => <div key={account.id} className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between"><div className="min-w-0"><p className="truncate text-sm font-semibold text-[#18364b]">{account.name || "Chưa cập nhật tên"}</p><p className="mt-1 truncate text-xs text-muted-foreground">{account.email || "Không có email"}</p></div><Select value={account.role} onValueChange={(value) => changeRole(account.id, value as keyof typeof roleLabels)}><SelectTrigger className="w-full rounded-xl border-[#dcebea] bg-white sm:w-44"><SelectValue /></SelectTrigger><SelectContent>{roleOptions.map(([value, label]) => <SelectItem key={value} value={value}>{label}</SelectItem>)}</SelectContent></Select></div>)}</div> : <div className="p-6 text-sm text-muted-foreground">Chưa có tài khoản nào.</div>}</CardContent></Card> : <Card className="border-0 bg-[#14314a] text-white shadow-[0_10px_30px_rgba(20,49,74,0.14)]"><CardContent className="flex items-start gap-4 p-5"><ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-[#72d4bf]" /><div><p className="font-medium">Phân quyền đang được bảo vệ</p><p className="mt-1 text-sm leading-6 text-white/65">Tài khoản quản lý có thể cập nhật cấu hình lab và dữ liệu danh mục, nhưng không thể thay đổi vai trò người dùng.</p></div></CardContent></Card>}

        <div className="grid gap-4 sm:grid-cols-3"><div className="rounded-2xl border border-[#dcebea] bg-white p-4"><p className="text-xs font-semibold uppercase tracking-[0.1em] text-primary">Nhập liệu</p><p className="mt-2 text-sm text-muted-foreground">Kỹ thuật viên có thể ghi nhận kết quả QC thủ công.</p></div><div className="rounded-2xl border border-[#dcebea] bg-white p-4"><p className="text-xs font-semibold uppercase tracking-[0.1em] text-primary">Kiểm soát</p><p className="mt-2 text-sm text-muted-foreground">Quản lý được phép cập nhật danh mục, sửa và xóa dữ liệu nhạy cảm.</p></div><div className="rounded-2xl border border-[#dcebea] bg-white p-4"><p className="text-xs font-semibold uppercase tracking-[0.1em] text-primary">Truy vết</p><p className="mt-2 text-sm text-muted-foreground">Mọi thay đổi quan trọng được ghi lại trong Audit Trail.</p></div></div>
      </div>
    </div>
  );
}
