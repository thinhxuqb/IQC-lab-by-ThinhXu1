export const APP_VERSION_INFO = {
  version: "1.0.27",
  releaseDate: "2026-08-14",
  notes: "Cho phép tải logo phòng xét nghiệm và lưu cục bộ để dùng trên giao diện, báo cáo PDF; giữ cơ chế tự động cập nhật Windows.",
  downloadUrl: "https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/releases"
};
