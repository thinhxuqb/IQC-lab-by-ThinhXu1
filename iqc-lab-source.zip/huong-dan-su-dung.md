# Hướng dẫn sử dụng phần mềm Quản lý Nội kiểm Xét nghiệm (IQC Lab by ThinhXu)

**Tác giả:** ThinhxuQB  
**Phần mềm:** IQC Lab by ThinhXu  

## 1. Giới thiệu chung

Phần mềm **IQC Lab by ThinhXu** do **ThinhxuQB** phát triển là giải pháp chuyên sâu hỗ trợ các khoa xét nghiệm y học thực hiện công tác Nội kiểm chất lượng (Internal Quality Control - IQC) một cách khoa học, đồng bộ và tuân thủ các tiêu chuẩn kiểm định chất lượng xét nghiệm. Ứng dụng hoạt động độc lập trên máy tính cá nhân (chạy offline), bảo mật dữ liệu cục bộ và hỗ trợ đầy đủ các tính năng quản lý danh mục xét nghiệm, vật liệu nội kiểm, nhập liệu kết quả hàng ngày, phân tích biểu đồ Levey-Jennings, kiểm tra tự động quy tắc Westgard và xuất báo cáo PDF chuẩn mực.

> "Hệ thống nội kiểm chất lượng xét nghiệm được xây dựng nhằm đảm bảo độ tin cậy của kết quả xét nghiệm huyết học, sinh hóa, miễn dịch và các xét nghiệm lâm sàng khác trước khi trả về cho bác sĩ điều trị." [1]

---

## 2. Cấu trúc giao diện và Quản lý danh mục

Giao diện chính được bố trí theo dạng bảng điều khiển chuyên nghiệp (Dashboard Layout) với thanh điều hướng trực quan ở cạnh trái màn hình, giúp người dùng dễ dàng chuyển đổi giữa các module nghiệp vụ quan trọng.

### Các module chức năng chính
1. **Tổng quan (Dashboard):** Hiển thị thống kê tổng số xét nghiệm, vật liệu nội kiểm đang hoạt động, tỷ lệ đạt nội kiểm trong tháng và danh sách các cảnh báo vi phạm quy tắc Westgard gần nhất.
2. **Quản lý Xét nghiệm (Tests):** Khai báo danh mục các chỉ số xét nghiệm (như Glucose, Creatinine, AST, ALT, Cholesterol...), đơn vị tính, giá trị trung bình (Mean) và độ lệch chuẩn (SD) chuẩn mực cho từng mức kiểm soát.
3. **Vật liệu nội kiểm (Control Materials):** Quản lý thông tin các lô huyết thanh kiểm soát (Control Lot), hạn sử dụng, nhà sản xuất và phân loại theo các mức nồng độ (Mức 1, Mức 2, Mức 3).
4. **Nhập kết quả IQC (Data Entry):** Giao diện nhập liệu hàng ngày cho phép kỹ thuật viên chọn ngày, ca trực, lô vật liệu nội kiểm và ghi nhận giá trị đo được của từng chỉ số.
5. **Biểu đồ Levey-Jennings & Westgard:** Trực quan hóa dữ liệu nội kiểm theo thời gian, hiển thị các đường biên Mean, $\pm 1\text{SD}$, $\pm 2\text{SD}$, $\pm 3\text{SD}$ và tự động đánh dấu các điểm vi phạm quy tắc Westgard.
6. **Báo cáo & Thống kê (Reports):** Trích xuất báo cáo tổng hợp tháng/quý kèm biểu đồ Levey-Jennings và bảng đánh giá độ chụm (CV%), độ đúng (Bias) dưới định dạng PDF có hỗ trợ đầy đủ tiếng Việt.
7. **Nhật ký hệ thống (Audit Trail):** Ghi nhận mọi thao tác thêm, sửa, xóa dữ liệu của người dùng nhằm đảm bảo tính minh bạch và kiểm toán nội bộ [1].

---

## 3. Quy trình nghiệp vụ hàng ngày dành cho kỹ thuật viên

Để vận hành hệ thống hiệu quả, kỹ thuật viên phòng xét nghiệm thực hiện theo trình tự các bước tiêu chuẩn sau:

### Bước 1: Kiểm tra danh mục và lô vật liệu nội kiểm
- Truy cập mục **Vật liệu nội kiểm** để xác nhận lô huyết thanh kiểm soát đang sử dụng còn hạn sử dụng và khớp với ca làm việc thực tế.
- Kiểm tra danh mục xét nghiệm và giá trị Mean, SD đã được thiết lập chính xác theo tờ hướng dẫn của nhà sản xuất (Insert Sheet).

### Bước 2: Nhập kết quả đo nội kiểm hàng ngày
- Vào mục **Nhập kết quả IQC**, chọn ngày thực hiện, ca làm việc (Ca sáng, Ca chiều, Ca đêm) và mã lô vật liệu.
- Nhập giá trị số liệu đo được cho từng chỉ số xét nghiệm tương ứng. Hệ thống sẽ tự động tính toán khoảng cách so với giá trị trung bình (tính bằng số lần SD).

### Bước 3: Đánh giá biểu đồ Levey-Jennings và Quy tắc Westgard
- Chuyển đến màn hình **Biểu đồ Levey-Jennings** để quan sát sự phân bố các điểm dữ liệu theo thời gian.
- Các điểm đo cùng ngày và cùng mức nồng độ được biểu diễn đồng bộ trên trục tung. Hệ thống tự động kiểm tra các quy tắc Westgard ($1_{3s}$, $2_{2s}$, $R_{4s}$, $4_{1s}$, $10_{x}$) [2].
- Nếu phát sinh cảnh báo vi phạm quy tắc Westgard, hệ thống sẽ hiển thị nhãn cảnh báo màu đỏ kèm khuyến nghị hành động khắc phục (Troubleshooting) [2].

### Bước 4: Lập và in báo cáo tháng
- Vào cuối tháng hoặc khi có yêu cầu kiểm định, chọn mục **Báo cáo**, lọc theo khoảng thời gian và chỉ số xét nghiệm cần báo cáo.
- Nhấn **Xuất báo cáo PDF** để tải về tệp tài liệu chính thức chứa đầy đủ biểu đồ Levey-Jennings, bảng thống kê CV% và chữ ký xác nhận của khoa xét nghiệm.

---

## 4. Giải đáp thắc mắc và Hỗ trợ kỹ thuật

Trong quá trình sử dụng phần mềm trên hệ thống máy tính phòng xét nghiệm, nếu gặp các vấn đề phát sinh hoặc cần hướng dẫn nâng cao, kỹ thuật viên có thể tham khảo các điểm lưu ý sau:

- **Dữ liệu được lưu trữ ở đâu?** Toàn bộ cơ sở dữ liệu nội kiểm được mã hóa và lưu trữ an toàn ngay trên thư mục cục bộ của máy tính, đảm bảo tính bảo mật tuyệt đối theo quy định quản lý thông tin y tế.
- **Phần mềm có cần kết nối internet không?** Không. Ứng dụng hoạt động hoàn toàn ngoại tuyến (offline) ngay cả khi phòng xét nghiệm ngắt kết nối mạng nội bộ.

---

## 5. Tài liệu tham khảo

[1] Bộ Y tế, *Quy định về quản lý chất lượng phòng xét nghiệm vi sinh, huyết học, sinh hóa và miễn dịch*, Thông tư hướng dẫn chuyên môn xét nghiệm y học, 2024.  
[2] Westgard J.O., *Basic QC Practices: Training in Statistical Quality Control for Medical Laboratories*, Westgard QC Inc., 4th Edition, 2016.

---
*Tài liệu hướng dẫn được biên soạn bởi **ThinhxuQB** cho hệ thống **IQC Lab by ThinhXu** phục vụ công tác quản lý chất lượng xét nghiệm y khoa.*
