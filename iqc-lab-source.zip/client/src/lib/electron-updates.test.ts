import { describe, expect, it } from "vitest";
import { getElectronUpdatesApi } from "./electron-updates";

describe("Electron update bridge", () => {
  it("returns null in the regular browser runtime", () => {
    expect(getElectronUpdatesApi()).toBeNull();
  });
});
