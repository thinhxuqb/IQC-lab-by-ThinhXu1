import { describe, expect, it } from "vitest";
import { activateLicense, createAuditLog } from "./db";

describe("backend runtime exports", () => {
  it("exposes audit and offline license procedures for the router", () => {
    expect(createAuditLog).toBeTypeOf("function");
    expect(activateLicense).toBeTypeOf("function");
  });
});
