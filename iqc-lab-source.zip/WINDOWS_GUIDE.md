# Hướng dẫn Cài đặt và Sử dụng IQC Lab by ThinhXu trên Windows

Phần mềm **IQC Lab by ThinhXu** cung cấp giải pháp quản lý nội kiểm xét nghiệm y học chuyên nghiệp, hoạt động độc lập ngoại tuyến trên máy tính Windows mà không phụ thuộc vào kết nối mạng Internet.

## Các phiên bản phát hành (Artifacts)
Quy trình tự động hóa GitHub Actions trên kho lưu trữ [thinhxuqb/IQC-lab-by-ThinhXu1](https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1) đóng gói hai định dạng tệp chính:
1. **Bộ cài đặt chuyên nghiệp (.exe)**: Phù hợp cho máy tính chính tại phòng xét nghiệm, tự động tạo lối tắt trên màn hình Desktop và thực đơn Start.
2. **Bản Portable (.zip)**: Phiên bản chạy ngay không cần cài đặt, thích hợp để sao chép vào USB hoặc chạy trực tiếp từ thư mục bất kỳ.

## Các bước tải và cài đặt
1. Truy cập trang quản lý mã nguồn và phát hành: [GitHub Actions – IQC Lab by ThinhXu](https://github.com/thinhxuqb/IQC-lab-by-ThinhXu1/actions)
2. Nhấp vào bản build gần nhất đã hoàn tất trạng thái **Success** (màu xanh lá).
3. Cuộn xuống mục **Artifacts** và tải xuống gói nén `iqc-lab-windows-build`.
4. Giải nén tệp tải về để nhận bộ cài `.exe` hoặc thư mục ứng dụng Portable.

## Tính năng nổi bật trên phiên bản Desktop
- **Biểu đồ Levey-Jennings chuẩn hóa Z-score**: Tự động hiển thị đường Mean, các dải $\pm1SD, \pm2SD, \pm3SD$ chung và nhóm các mức QC cùng ngày trên cùng một trục X.
- **Kiểm tra quy tắc Westgard tự động**: Phát hiện tức thời các vi phạm từ $1_{2s}$ đến $10_x$, đi kèm cảnh báo âm thanh và thông báo trên màn hình máy tính.
- **Bảo mật và sao lưu dữ liệu cục bộ**: Cơ sở dữ liệu SQLite cục bộ được mã hóa AES-256, hỗ trợ xuất/nhập tệp sao lưu an toàn.
- **Phím tắt toàn cục**: Nhấn nhanh tổ hợp phím `Ctrl + Shift + N` từ bất kỳ màn hình nào để mở giao diện nhập kết quả kiểm soát chất lượng.
- **Xuất báo cáo PDF vector**: Tạo báo cáo kiểm soát chất lượng chuẩn y tế, tích hợp biểu đồ Levey-Jennings, font Unicode tiếng Việt và chữ ký xác nhận.


## Tự động cập nhật

Bản cập nhật tự động áp dụng cho **bản cài đặt NSIS**, không áp dụng cho bản Portable. Khi có bản phát hành mới, ứng dụng sẽ kiểm tra nền qua GitHub Releases sau khi khởi động. Nếu phát hiện phiên bản mới, một banner sẽ xuất hiện trong giao diện với các nút **Tải cập nhật** và **Khởi động lại và cập nhật**.

Người dùng có thể tiếp tục làm việc trong thời gian kiểm tra. Việc tải chỉ bắt đầu sau khi người dùng xác nhận. Khi tải xong, ứng dụng sẽ khởi động lại và cài đặt bản mới; dữ liệu cục bộ không bị xóa. Nếu mạng bị gián đoạn, ứng dụng vẫn có thể chạy với phiên bản hiện tại và hiển thị nút thử lại.

> Không nên đổi tên hoặc di chuyển thư mục dữ liệu cục bộ trong lúc cập nhật. Trước khi cập nhật phiên bản lớn, hãy tạo một bản sao lưu AES-256 từ chức năng sao lưu của phần mềm.

## Quy trình phát hành phiên bản mới

Để phát hành bản cập nhật, tăng trường `version` trong `package.json`, commit thay đổi, sau đó tạo và đẩy tag dạng `v1.0.1` hoặc cao hơn lên nhánh `main`. Workflow `Build Windows App` sẽ tạo GitHub Release, bộ cài NSIS, metadata `latest.yml`, tệp blockmap và artifact Portable ZIP. Máy đã cài phiên bản cũ sẽ dùng `latest.yml` để phát hiện bản phát hành mới.

```bash
pnpm install --frozen-lockfile
pnpm check
pnpm test
pnpm build
git tag v1.0.1
git push origin main --tags
```

Chỉ tạo tag sau khi đã kiểm tra thay đổi và xác nhận workflow thành công. Bản Portable cần được tải thủ công từ artifact hoặc GitHub Release vì không tự cài đặt cập nhật.
