import sys
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import os

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 generate_chart_pdf.py <json_input_path> <output_png_path>")
        sys.exit(1)
        
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    
    with open(input_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
        
    results = data.get('results', [])
    
    plt.figure(figsize=(10, 4.2), dpi=150)
    plt.axhline(0, color='#14314a', linestyle='-', linewidth=1.2, label='Mean')
    plt.axhline(1, color='#e0a030', linestyle='--', linewidth=0.8, label='+1SD / -1SD')
    plt.axhline(-1, color='#e0a030', linestyle='--', linewidth=0.8)
    plt.axhline(2, color='#e67e22', linestyle='--', linewidth=0.9, label='+2SD / -2SD')
    plt.axhline(-2, color='#e67e22', linestyle='--', linewidth=0.9)
    plt.axhline(3, color='#e74c3c', linestyle=':', linewidth=1.0, label='+3SD / -3SD')
    plt.axhline(-3, color='#e74c3c', linestyle=':', linewidth=1.0)
    
    levels = {}
    for item in results:
        level = item.get('level', 'Level 1')
        if level not in levels:
            levels[level] = {'dates': [], 'z_scores': []}
        # Parse date to short string
        dt = item.get('recordedAt', '')
        short_dt = dt[5:10] + ' ' + dt[11:16] if len(dt) >= 16 else dt
        levels[level]['dates'].append(short_dt)
        levels[level]['z_scores'].append(item.get('zScore', 0.0))
        
    colors = {'Level 1': '#2f7f80', 'Level 2': '#cf8d2e', 'Level 3': '#8e44ad'}
    
    for level, group in levels.items():
        if group['z_scores']:
            x = range(len(group['z_scores']))
            c = colors.get(level, '#2f7f80')
            plt.plot(x, group['z_scores'], marker='o', color=c, linewidth=1.8, markersize=5, label=level)
            
    plt.title('Biểu đồ Levey-Jennings chuẩn hóa Z-score', fontsize=12, fontweight='bold', color='#14314a', pad=12)
    plt.ylabel('Z-score (SD)', fontsize=10, color='#14314a')
    plt.ylim(-3.8, 3.8)
    plt.grid(True, linestyle='--', alpha=0.4, color='#cbd5e1')
    plt.legend(loc='upper right', fontsize=8, framealpha=0.9)
    plt.tight_layout()
    plt.savefig(output_path, format='png', dpi=150)
    plt.close()

if __name__ == '__main__':
    main()
