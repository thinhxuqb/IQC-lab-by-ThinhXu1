import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
  createControlMaterial,
  createInstrumentConfig,
  createInstrumentMapping,
  createTest,
  exportFullDatabaseBackup,
  listInstrumentLogs,
  listIqcResults,
} from "./db";
import { ingestInstrumentPayload } from "./instrument-runtime";

describe("offline instrument interface", () => {
  const originalDatabaseUrl = process.env.DATABASE_URL;
  const originalDataDir = process.env.IQC_DATA_DIR;
  let dataDir = "";

  beforeEach(() => {
    delete process.env.DATABASE_URL;
    dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "iqc-instrument-"));
    process.env.IQC_DATA_DIR = dataDir;
  });

  afterEach(() => {
    if (originalDatabaseUrl === undefined) delete process.env.DATABASE_URL;
    else process.env.DATABASE_URL = originalDatabaseUrl;
    if (originalDataDir === undefined) delete process.env.IQC_DATA_DIR;
    else process.env.IQC_DATA_DIR = originalDataDir;
    fs.rmSync(dataDir, { recursive: true, force: true });
  });

  it("imports a mapped result and ignores the same frame on the second receipt", async () => {
    const test = await createTest({ code: "GLU", name: "Glucose", unit: "mg/dL", category: "Sinh hóa", description: null });
    const material = await createControlMaterial({ name: "Control GLU", lotNumber: "L-01", testId: test!.id, level: "Level 1", targetMean: 100, targetSd: 5, expirationDate: null, isActive: 1 });
    const config = await createInstrumentConfig({ name: "Máy demo", enabled: 0, connectionType: "tcp", protocol: "delimited", host: "127.0.0.1", port: 5000, serialPort: null, baudRate: null, dataBits: 8, stopBits: 1, parity: "none", delimiter: "\\n", codeFieldIndex: 0, valueFieldIndex: 1, receiveTimeoutMs: 1000 });
    await createInstrumentMapping({ configId: config!.id, instrumentCode: "GLU", testId: test!.id, controlMaterialId: material!.material.id, enabled: 1 });

    await ingestInstrumentPayload(config!.id, "GLU|105|mg/dL\\n");
    await ingestInstrumentPayload(config!.id, "GLU|105|mg/dL\\n");

    const results = await listIqcResults({ controlMaterialId: material!.material.id });
    const logs = await listInstrumentLogs(config!.id, 10);
    expect(results).toHaveLength(1);
    expect(results[0].result.value).toBe(105);
    expect(logs.map((log) => log.parseStatus)).toEqual(["duplicate", "imported"]);
    expect(logs[0].rawText).toContain("GLU|105");
  });

  it("keeps unmapped machine codes in the log without creating QC data", async () => {
    const test = await createTest({ code: "ALT", name: "ALT", unit: "U/L", category: "Sinh hóa", description: null });
    const material = await createControlMaterial({ name: "Control ALT", lotNumber: "L-02", testId: test!.id, level: "Level 2", targetMean: 30, targetSd: 2, expirationDate: null, isActive: 1 });
    const config = await createInstrumentConfig({ name: "Máy chưa mapping", enabled: 0, connectionType: "tcp", protocol: "delimited", host: "127.0.0.1", port: 5001, serialPort: null, baudRate: null, dataBits: 8, stopBits: 1, parity: "none", delimiter: "\\n", codeFieldIndex: 0, valueFieldIndex: 1, receiveTimeoutMs: 1000 });

    await ingestInstrumentPayload(config!.id, "UNKNOWN|12|U/L\\n");
    const results = await listIqcResults({ controlMaterialId: material!.material.id });
    const logs = await listInstrumentLogs(config!.id, 10);
    expect(results).toHaveLength(0);
    expect(logs[0].parseStatus).toBe("unmapped");
    expect(logs[0].errorMessage).toContain("UNKNOWN");
  });

  it("includes interface configuration, mapping, and logs in a full offline backup", async () => {
    const config = await createInstrumentConfig({ name: "Backup machine", enabled: 1, connectionType: "serial", protocol: "astm", host: null, port: null, serialPort: "COM4", baudRate: 9600, dataBits: 8, stopBits: 1, parity: "even", delimiter: "\\n", codeFieldIndex: 0, valueFieldIndex: 1, receiveTimeoutMs: 1500 });
    const backup = await exportFullDatabaseBackup();
    expect(backup.data.instrumentConfigs).toHaveLength(1);
    expect(backup.data.instrumentConfigs[0].serialPort).toBe("COM4");
    expect(backup.data.instrumentMappings).toEqual([]);
    expect(backup.data.instrumentLogs).toEqual([]);
  });
});
