import { useMemo, useState } from "react";
import { Activity, CalendarDays, ClipboardList, Filter, ShieldCheck } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const actionLabels: Record<string, string> = {
  CREATE: "Tạo mới",
  UPDATE: "Cập nhật",
  DELETE: "Xóa",
  UPDATE_ROLE: "Đổi vai trò",
  UPLOAD_LOGO: "Tải logo",
};

const targetLabels: Record<string, string> = {
  TEST: "Xét nghiệm",
  CONTROL_MATERIAL: "Vật liệu kiểm soát",
  IQC_RESULT: "Kết quả IQC",
  LAB_SETTINGS: "Cài đặt lab",
  USER: "Người dùng",
};

const actionClass: Record<string, string> = {
  CREATE: "border-emerald-200 bg-emerald-50 text-emerald-700",
  UPDATE: "border-sky-200 bg-sky-50 text-sky-700",
  DELETE: "border-rose-200 bg-rose-50 text-rose-700",
  UPDATE_ROLE: "border-violet-200 bg-violet-50 text-violet-700",
  UPLOAD_LOGO: "border-amber-200 bg-amber-50 text-amber-700",
};

function formatDate(date: Date | string | null | undefined) {
  if (!date) return "—";
  return new Date(date).toLocaleString("vi-VN", { dateStyle: "medium", timeStyle: "short" });
}

function summarize(details: string | null) {
  if (!details) return "—";
  try {
    const parsed = JSON.parse(details) as Record<string, unknown>;
    return Object.entries(parsed).map(([key, value]) => `${key}: ${typeof value === "object" ? JSON.stringify(value) : String(value)}`).join(" · ");
  } catch {
    return details;
  }
}

export default function AuditTrailPage() {
  const { user } = useAuth();
  const canView = user?.role === "manager" || user?.role === "admin";
  const [action, setAction] = useState("all");
  const [targetType, setTargetType] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const filter = useMemo(() => ({
    action: action === "all" ? undefined : action,
    targetType: targetType === "all" ? undefined : targetType,
    from: from ? new Date(`${from}T00:00:00`).toISOString() : undefined,
    to: to ? new Date(`${to}T23:59:59`).toISOString() : undefined,
    limit: 500,
  }), [action, targetType, from, to]);
  const logsQuery = trpc.audit.list.useQuery(filter, { enabled: canView });
  const logs = logsQuery.data ?? [];

  if (!canView) {
    return <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center bg-[#f5f9f9] p-6"><Card className="max-w-md border-0 shadow-[0_12px_35px_rgba(20,49,74,0.08)]"><CardContent className="space-y-3 p-8 text-center"><ShieldCheck className="mx-auto h-10 w-10 text-primary" /><h1 className="text-xl font-semibold text-[#14314a]">Audit Trail được bảo vệ</h1><p className="text-sm leading-6 text-muted-foreground">Chỉ quản lý hoặc quản trị viên mới có thể xem lịch sử thao tác của hệ thống.</p></CardContent></Card></div>;
  }

  return <div className="min-h-[calc(100vh-2rem)] bg-[#f5f9f9] px-1 py-1 sm:px-3 lg:px-6"><div className="mx-auto max-w-[1440px] space-y-7 py-4">
    <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between"><div><div className="mb-2 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary/80"><span className="h-1.5 w-1.5 rounded-full bg-primary" />Governance · 09</div><h1 className="text-3xl font-semibold tracking-[-0.03em] text-[#14314a] md:text-4xl">Audit Trail</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">Theo dõi minh bạch các thao tác tạo, cập nhật, xóa dữ liệu và thay đổi quyền trong IQC Lab by ThinhXu.</p></div><Badge variant="outline" className="w-fit gap-2 rounded-full border-[#bde8df] bg-[#e9f5f3] px-3 py-1.5 text-primary"><Activity className="h-3.5 w-3.5" />{logs.length} bản ghi</Badge></div>

    <Card className="border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="border-b border-[#edf3f3] pb-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#e9f5f3] p-2.5 text-primary"><Filter className="h-5 w-5" /></div><div><CardTitle className="text-base text-[#14314a]">Bộ lọc truy vết</CardTitle><p className="mt-1 text-xs text-muted-foreground">Thu hẹp lịch sử theo hành động, đối tượng và khoảng ngày.</p></div></div></CardHeader><CardContent className="grid gap-4 p-5 md:grid-cols-4"><div><p className="mb-2 text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">Hành động</p><Select value={action} onValueChange={setAction}><SelectTrigger className="rounded-xl border-[#dcebea] bg-white"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Tất cả hành động</SelectItem><SelectItem value="CREATE">Tạo mới</SelectItem><SelectItem value="UPDATE">Cập nhật</SelectItem><SelectItem value="DELETE">Xóa</SelectItem><SelectItem value="UPDATE_ROLE">Đổi vai trò</SelectItem><SelectItem value="UPLOAD_LOGO">Tải logo</SelectItem></SelectContent></Select></div><div><p className="mb-2 text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">Đối tượng</p><Select value={targetType} onValueChange={setTargetType}><SelectTrigger className="rounded-xl border-[#dcebea] bg-white"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Tất cả đối tượng</SelectItem><SelectItem value="TEST">Xét nghiệm</SelectItem><SelectItem value="CONTROL_MATERIAL">Vật liệu kiểm soát</SelectItem><SelectItem value="IQC_RESULT">Kết quả IQC</SelectItem><SelectItem value="LAB_SETTINGS">Cài đặt lab</SelectItem><SelectItem value="USER">Người dùng</SelectItem></SelectContent></Select></div><div><p className="mb-2 text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">Từ ngày</p><div className="relative"><CalendarDays className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" /><Input type="date" value={from} onChange={(event) => setFrom(event.target.value)} className="rounded-xl border-[#dcebea] bg-white pl-9" /></div></div><div><p className="mb-2 text-xs font-semibold uppercase tracking-[0.08em] text-[#31556a]">Đến ngày</p><div className="relative"><CalendarDays className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" /><Input type="date" value={to} onChange={(event) => setTo(event.target.value)} className="rounded-xl border-[#dcebea] bg-white pl-9" /></div></div></CardContent></Card>

    <Card className="overflow-hidden border-0 bg-white shadow-[0_10px_30px_rgba(20,49,74,0.06)]"><CardHeader className="border-b border-[#edf3f3] pb-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#eef4fb] p-2.5 text-[#3b6e95]"><ClipboardList className="h-5 w-5" /></div><div><CardTitle className="text-base text-[#14314a]">Lịch sử thao tác</CardTitle><p className="mt-1 text-xs text-muted-foreground">Bản ghi được sắp xếp từ mới nhất đến cũ nhất.</p></div></div></CardHeader><CardContent className="p-0">{logsQuery.isLoading ? <div className="p-8 text-sm text-muted-foreground">Đang tải audit trail...</div> : logs.length ? <div className="overflow-x-auto"><Table><TableHeader><TableRow className="hover:bg-transparent"><TableHead className="pl-6">Thời gian</TableHead><TableHead>Người thực hiện</TableHead><TableHead>Hành động</TableHead><TableHead>Đối tượng</TableHead><TableHead>Chi tiết</TableHead><TableHead className="pr-6">IP</TableHead></TableRow></TableHeader><TableBody>{logs.map((log) => <TableRow key={log.id}><TableCell className="whitespace-nowrap pl-6 text-xs text-muted-foreground">{formatDate(log.createdAt)}</TableCell><TableCell><p className="text-sm font-medium text-[#18364b]">{log.userName || "—"}</p><p className="text-xs text-muted-foreground">{log.userRole || "—"}</p></TableCell><TableCell><Badge variant="outline" className={`whitespace-nowrap ${actionClass[log.action] ?? ""}`}>{actionLabels[log.action] ?? log.action}</Badge></TableCell><TableCell><p className="text-sm text-[#18364b]">{targetLabels[log.targetType] ?? log.targetType}</p><p className="text-xs text-muted-foreground">ID: {log.targetId ?? "—"}</p></TableCell><TableCell className="max-w-[420px] text-xs leading-5 text-muted-foreground">{summarize(log.details)}</TableCell><TableCell className="pr-6 font-mono text-xs text-muted-foreground">{log.ipAddress || "—"}</TableCell></TableRow>)}</TableBody></Table></div> : <div className="flex flex-col items-center justify-center px-6 py-16 text-center"><ClipboardList className="h-10 w-10 text-[#9bb9bf]" /><h3 className="mt-4 text-base font-semibold text-[#18364b]">Chưa có bản ghi phù hợp</h3><p className="mt-2 max-w-md text-sm leading-6 text-muted-foreground">Các thao tác dữ liệu quan trọng sẽ xuất hiện tại đây sau khi người dùng thực hiện.</p></div>}</CardContent></Card>
  </div></div>;
}
