import { describe, expect, it } from "vitest";

describe("website branding configuration", () => {
  it("loads the configured IQC Lab by ThinhXu title", () => {
    expect(process.env.VITE_APP_TITLE).toBe("IQC Lab by ThinhXu");
  });
});
