const express = require('express');
const path = require('path');
const fs = require('fs');

function startProductionServer(port = 3000) {
  const app = express();
  
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Mount tRPC and API routes if available in bundle
  try {
    // Try to load compiled routers and trpc adapters if bundled
    const trpcExpress = require('@trpc/server/adapters/express');
    // We check if we can require compiled routers or if we need to load from relative paths
    // In production build, server files might be compiled or required via tsx/node
    console.log('[IQC Server] Attempting to mount tRPC middleware...');
    
    // Check possible locations for routers and context
    let appRouter, createContext;
    try {
      const routersModule = require('./routers');
      appRouter = routersModule.appRouter;
    } catch (e1) {
      try {
        const routersModule = require('../dist-server/routers');
        appRouter = routersModule.appRouter;
      } catch (e2) {
        console.warn('[IQC Server] appRouter not found directly in CommonJS bundle:', e2.message);
      }
    }

    try {
      const contextModule = require('./_core/context');
      createContext = contextModule.createContext;
    } catch (e1) {
      try {
        const contextModule = require('../dist-server/_core/context');
        createContext = contextModule.createContext;
      } catch (e2) {
        // Fallback context creator
        createContext = ({ req, res }) => ({ req, res, user: null });
      }
    }

    if (appRouter && trpcExpress) {
      app.use(
        '/api/trpc',
        trpcExpress.createExpressMiddleware({
          router: appRouter,
          createContext: createContext || (({ req, res }) => ({ req, res, user: null })),
        })
      );
      console.log('[IQC Server] tRPC middleware successfully mounted at /api/trpc');
    } else {
      console.warn('[IQC Server] Warning: tRPC middleware could not be mounted due to missing appRouter');
      // Fallback API error handler returning JSON instead of HTML SPA fallback
      app.use('/api/trpc', (req, res) => {
        res.status(500).json({ error: { message: 'tRPC router not loaded in production bundle' } });
      });
    }
  } catch (err) {
    console.error('[IQC Server] Error setting up tRPC middleware:', err);
    app.use('/api/trpc', (req, res) => {
      res.status(500).json({ error: { message: 'Internal Server Error in tRPC setup: ' + err.message } });
    });
  }

  // Serve static files from dist/public
  const possiblePaths = [
    path.join(__dirname, 'public'),
    path.join(process.resourcesPath || '', 'app', 'dist', 'public'),
    path.join(process.resourcesPath || '', 'app.asar.unpacked', 'dist', 'public'),
    path.join(__dirname, '..', 'dist', 'public')
  ];

  let staticDir = possiblePaths.find(p => fs.existsSync(p)) || possiblePaths[0];
  console.log('[IQC Server] Serving static files from:', staticDir);

  app.use(express.static(staticDir));

  // Fallback to index.html for SPA routing (EXCEPT /api routes)
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) {
      return res.status(404).json({ error: { message: `API route not found: ${req.path}` } });
    }
    const indexPath = path.join(staticDir, 'index.html');
    if (fs.existsSync(indexPath)) {
      res.sendFile(indexPath);
    } else {
      res.status(404).send('IQC Lab by ThinhXu - Static files not found at: ' + indexPath);
    }
  });

  return new Promise((resolve, reject) => {
    const server = app.listen(port, '127.0.0.1', () => {
      const actualPort = server.address().port;
      console.log(`[IQC Server] Running on http://127.0.0.1:${actualPort}`);
      
      // Write port file for Electron
      try {
        const portFilePath = path.join(require('os').tmpdir(), 'iqc-lab-port.txt');
        fs.writeFileSync(portFilePath, String(actualPort));
      } catch (e) {
        console.error('Failed to write port file:', e);
      }
      
      resolve({ app, server, port: actualPort });
    }).on('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        console.log(`Port ${port} in use, trying random port...`);
        const fallbackServer = app.listen(0, '127.0.0.1', () => {
          const actualPort = fallbackServer.address().port;
          try {
            const portFilePath = path.join(require('os').tmpdir(), 'iqc-lab-port.txt');
            fs.writeFileSync(portFilePath, String(actualPort));
          } catch (e) {}
          resolve({ app, server: fallbackServer, port: actualPort });
        });
      } else {
        reject(err);
      }
    });
  });
}

if (require.main === module) {
  startProductionServer(3000).catch(console.error);
}

module.exports = { startProductionServer };
