export type UpdateStatus =
  | "unsupported"
  | "idle"
  | "checking"
  | "available"
  | "downloading"
  | "downloaded"
  | "error";

export type UpdateState = {
  status: UpdateStatus;
  version: string | null;
  progress: number;
  message: string | null;
};

type ElectronUpdatesApi = {
  getState: () => Promise<UpdateState>;
  check: () => Promise<UpdateState>;
  download: () => Promise<UpdateState>;
  install: () => Promise<boolean>;
  onState: (callback: (state: UpdateState) => void) => () => void;
};

declare global {
  interface Window {
    electronAPI?: {
      updates?: ElectronUpdatesApi;
    };
  }
}

export function getElectronUpdatesApi(): ElectronUpdatesApi | null {
  if (typeof window === "undefined") return null;
  return window.electronAPI?.updates ?? null;
}
