import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

describe("Electron production packaging", () => {
  it("loads the production server from the packaged dist entry", () => {
    const electronSource = fs.readFileSync(path.join(projectRoot, "electron.cjs"), "utf8");
    expect(electronSource).toContain("path.join(__dirname, 'dist', 'index.cjs')");
    expect(electronSource).not.toContain("require('./server/production-server.cjs')");
  });

  it("copies the CommonJS production server into dist/index.cjs", () => {
    const packageJson = JSON.parse(fs.readFileSync(path.join(projectRoot, "package.json"), "utf8"));
    const buildFiles = packageJson.build.files as string[];
    expect(buildFiles).toContain("dist/**/*");
    expect(packageJson.scripts.build).toContain("server/production-entry.ts");
    expect(packageJson.scripts.build).toContain("--bundle");
    expect(packageJson.scripts.build).toContain("dist/index.cjs");
    expect(buildFiles).toContain("dist/index.cjs");
  });

  it("does not ship the obsolete unbundled production server entry", () => {
    const packageJson = JSON.parse(fs.readFileSync(path.join(projectRoot, "package.json"), "utf8"));
    const buildFiles = packageJson.build.files as string[];
    expect(buildFiles).not.toContain("server/**/*");
    expect(fs.existsSync(path.join(projectRoot, "server/production-entry.ts"))).toBe(true);
  });

  it("unpacks the native serialport binding and enables the desktop interface runtime", () => {
    const packageJson = JSON.parse(fs.readFileSync(path.join(projectRoot, "package.json"), "utf8"));
    expect(packageJson.build.asarUnpack).toContain("node_modules/@serialport/bindings-cpp/**/*");
    expect(packageJson.build.npmRebuild).toBe(false);
    const electronSource = fs.readFileSync(path.join(projectRoot, "electron.cjs"), "utf8");
    expect(electronSource).toContain("process.env.IQC_DESKTOP = '1'");
  });
});

export {};
