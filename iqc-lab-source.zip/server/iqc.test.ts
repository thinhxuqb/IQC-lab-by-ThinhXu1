import { describe, expect, it } from "vitest";
import {
  calculateStatistics,
  calculateWestgardViolations,
  classifyStatus,
  zScore,
} from "../shared/iqc";

describe("IQC calculations", () => {
  it("calculates z-score and rejects invalid SD", () => {
    expect(zScore(105, 100, 5)).toBe(1);
    expect(zScore(105, 100, 0)).toBeNull();
  });

  it("calculates sample SD and CV from valid values", () => {
    const stats = calculateStatistics([98, 100, 102]);
    expect(stats.count).toBe(3);
    expect(stats.mean).toBe(100);
    expect(stats.sd).toBe(2);
    expect(stats.cv).toBe(2);
  });

  it("detects 1-2s, 1-3s and 2-2s signals", () => {
    expect(calculateWestgardViolations([0, 2.1])).toContain("1-2s");
    expect(calculateWestgardViolations([0, 3.1])).toContain("1-3s");
    expect(calculateWestgardViolations([2.1, 2.2])).toContain("2-2s");
    expect(classifyStatus(["1-2s"])).toBe("Warning");
    expect(classifyStatus(["1-3s"])).toBe("Rejected");
  });

  it("detects R-4s, 4-1s and 10x signals", () => {
    expect(calculateWestgardViolations([2.1, -2.1])).toContain("R-4s");
    expect(calculateWestgardViolations([1.1, 1.2, 1.3, 1.4])).toContain("4-1s");
    expect(calculateWestgardViolations([0.2, 0.3, 0.4, 0.1, 0.5, 0.2, 0.6, 0.3, 0.4, 0.2])).toContain("10x");
  });
});
