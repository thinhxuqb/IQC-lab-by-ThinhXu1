import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";

const testContext = {
  req: {} as never,
  res: {} as never,
  user: {
    id: 1,
    openId: "offline-verification",
    name: "Offline verification",
    email: null,
    loginMethod: "offline",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  },
};

describe("IQC PDF report integration", () => {
  it("generates a PDF containing an embedded image object for the default logo", async () => {
    const report = await appRouter.createCaller(testContext).reports.pdf(undefined);
    const pdf = Buffer.from(report.base64, "base64");

    expect(pdf.subarray(0, 4).toString("ascii")).toBe("%PDF");
    expect(pdf.toString("latin1")).toContain("/Subtype /Image");
    expect(pdf.length).toBeGreaterThan(10_000);
  }, 30_000);
});
