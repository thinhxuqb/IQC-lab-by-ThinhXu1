# QA findings — Levey–Jennings đa mức/lô

Ngày kiểm tra: 2026-08-13.

Màn hình `/analytics` đã được chụp ở trạng thái bộ lọc `Tất cả mức / lô`, với dữ liệu hiển thị từ ít nhất hai nhóm: `Level 2 · Lot 1234` và `Level 1 · Lot 1234`. Phần chú giải hiển thị hai màu riêng biệt tương ứng với hai nhóm. Biểu đồ hiển thị các đường Mean và các dải SD theo màu của từng nhóm; mô tả trên giao diện xác nhận các nhóm khác nhau không nối với nhau.

Kiểm tra kỹ thuật: `pnpm check` không có lỗi TypeScript; `pnpm test` đạt 5/5 tests. Logic dùng một dataKey riêng cho từng material và `connectNulls={false}`, nên các điểm thuộc nhóm khác sẽ tạo khoảng trống thay vì nối chéo.

## Xác minh yêu cầu Mean chung

Ảnh chụp `/analytics` sau bản sửa hiển thị đồng thời `Level 1` và `Level 2` trong chú giải bằng hai màu khác nhau. Phần mô tả xác nhận các mức QC nằm trên cùng hệ trục và dùng chung Mean/SD. Trên vùng đồ thị chỉ có một đường ngang màu xanh được gắn nhãn `Mean chung`, cùng một bộ dải ±1SD, ±2SD và ±3SD. Các series dữ liệu được tạo bằng dataKey theo mức (`level_level_1`, `level_level_2`) và dùng `connectNulls={false}`, bảo đảm điểm cùng mức nối với nhau còn điểm khác mức không bị nối chéo.
