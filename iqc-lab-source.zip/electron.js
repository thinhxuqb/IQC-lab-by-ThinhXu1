const { app, BrowserWindow, dialog, globalShortcut } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const fs = require('fs');

let mainWindow;
let serverProcess = null;

function startServer() {
  const serverPath = path.join(__dirname, 'dist', 'index.js');
  if (!fs.existsSync(serverPath)) {
    dialog.showErrorBox('Lỗi khởi động', 'Không tìm thấy tệp máy chủ backend tại: ' + serverPath);
    app.quit();
    return;
  }

  // Khởi chạy tệp ESM bundle bằng Node.js tích hợp trong Electron
  serverProcess = spawn(process.execPath, [serverPath], {
    env: {
      ...process.env,
      PORT: '3000',
      NODE_ENV: 'production'
    },
    stdio: 'inherit'
  });

  serverProcess.on('error', (err) => {
    console.error('Không thể khởi động server nội bộ:', err);
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    title: 'IQC Lab by ThinhXu',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  mainWindow.loadURL('http://localhost:3000');

  // Đăng ký phím tắt toàn cục Ctrl+Shift+N để chuyển nhanh đến trang nhập kết quả
  globalShortcut.register('CommandOrControl+Shift+N', () => {
    if (mainWindow) {
      mainWindow.loadURL('http://localhost:3000/results');
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  startServer();
  // Đợi server Express sẵn sàng
  setTimeout(createWindow, 1800);
});

app.on('window-all-closed', () => {
  if (serverProcess) {
    try {
      serverProcess.kill();
    } catch (e) {
      // ignore
    }
  }
  app.quit();
});
