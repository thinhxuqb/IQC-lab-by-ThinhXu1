export const ENV = {
  appId: process.env.VITE_APP_ID || "com.thinhxu.iqclab",
  // Desktop builds do not receive the web platform's JWT_SECRET. Keep a stable
  // local-only secret so the offline session can be signed without OAuth.
  cookieSecret: process.env.JWT_SECRET || "iqc-lab-by-thinhxu-offline-session-secret-v1",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
};
