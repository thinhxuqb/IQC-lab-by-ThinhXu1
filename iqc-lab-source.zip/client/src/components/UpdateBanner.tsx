import { useEffect, useState } from "react";
import { Download, Loader2, RefreshCw, RotateCcw } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { getElectronUpdatesApi, type UpdateState } from "@/lib/electron-updates";

const initialState: UpdateState = {
  status: "unsupported",
  version: null,
  progress: 0,
  message: null,
};

export function UpdateBanner() {
  const [state, setState] = useState<UpdateState>(initialState);
  const [busy, setBusy] = useState(false);
  const api = getElectronUpdatesApi();

  useEffect(() => {
    const updates = getElectronUpdatesApi();
    if (!updates) return;

    let mounted = true;
    updates.getState().then((nextState) => {
      if (mounted) setState(nextState);
    });
    const unsubscribe = updates.onState((nextState) => {
      if (mounted) setState(nextState);
    });

    return () => {
      mounted = false;
      unsubscribe();
    };
  }, []);

  if (!api || state.status === "unsupported" || state.status === "idle") return null;

  const run = async (action: () => Promise<UpdateState | boolean>) => {
    setBusy(true);
    try {
      const result = await action();
      if (typeof result !== "boolean") setState(result);
    } finally {
      setBusy(false);
    }
  };

  if (state.status === "checking") {
    return (
      <Alert className="mb-4 border-sky-200 bg-sky-50 text-sky-950">
        <Loader2 className="h-4 w-4 animate-spin" />
        <AlertTitle>Đang kiểm tra bản cập nhật</AlertTitle>
        <AlertDescription>{state.message ?? "Đang kết nối máy chủ phát hành…"}</AlertDescription>
      </Alert>
    );
  }

  if (state.status === "error") {
    return (
      <Alert className="mb-4 border-amber-200 bg-amber-50 text-amber-950">
        <RefreshCw className="h-4 w-4" />
        <AlertTitle>Không thể cập nhật tự động</AlertTitle>
        <AlertDescription className="flex flex-wrap items-center gap-3">
          <span>{state.message ?? "Vui lòng thử lại sau."}</span>
          <Button size="sm" variant="outline" onClick={() => run(() => api.check())} disabled={busy}>
            Thử lại
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  if (state.status === "available") {
    return (
      <Alert className="mb-4 border-indigo-200 bg-indigo-50 text-indigo-950">
        <Download className="h-4 w-4" />
        <AlertTitle>Có bản cập nhật mới{state.version ? ` ${state.version}` : ""}</AlertTitle>
        <AlertDescription className="flex flex-wrap items-center gap-3">
          <span>{state.message ?? "Tải bản cập nhật để sử dụng các cải tiến mới."}</span>
          <Button size="sm" onClick={() => run(() => api.download())} disabled={busy}>
            {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
            Tải cập nhật
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  if (state.status === "downloading") {
    return (
      <Alert className="mb-4 border-indigo-200 bg-indigo-50 text-indigo-950">
        <Download className="h-4 w-4" />
        <AlertTitle>Đang tải bản cập nhật</AlertTitle>
        <AlertDescription>
          <div className="mt-2 flex items-center gap-3">
            <Progress value={state.progress} className="max-w-md" />
            <span className="text-xs font-semibold">{state.progress}%</span>
          </div>
        </AlertDescription>
      </Alert>
    );
  }

  if (state.status === "downloaded") {
    return (
      <Alert className="mb-4 border-emerald-200 bg-emerald-50 text-emerald-950">
        <RotateCcw className="h-4 w-4" />
        <AlertTitle>Bản cập nhật đã sẵn sàng</AlertTitle>
        <AlertDescription className="flex flex-wrap items-center gap-3">
          <span>{state.message ?? "Khởi động lại ứng dụng để hoàn tất cập nhật."}</span>
          <Button size="sm" onClick={() => run(() => api.install())} disabled={busy}>
            <RotateCcw className="mr-2 h-4 w-4" />
            Khởi động lại và cập nhật
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  return null;
}
