import crypto from "node:crypto";
import net from "node:net";
import {
  calculateWestgardViolations,
  classifyStatus,
  zScore,
} from "@shared/iqc";
import { parseInstrumentMessage } from "./instrument-parser";
import {
  createInstrumentLog,
  createIqcResult,
  findInstrumentLogByDedupKey,
  getControlMaterialById,
  getInstrumentConfigById,
  listInstrumentConfigs,
  listInstrumentMappings,
  listIqcResults,
} from "./db";
import type {
  InstrumentConfig,
  InstrumentRuntimeState,
  ParsedInstrumentResult,
} from "@shared/instrument";

// Runtime state is intentionally process-local. Configuration and audit data remain durable in JSON/MySQL.
type ActiveConnection = {
  config: InstrumentConfig;
  close: () => Promise<void>;
  buffer: string;
};

const activeConnections = new Map<number, ActiveConnection>();
const runtimeStates = new Map<number, InstrumentRuntimeState>();

function setState(configId: number, state: Partial<InstrumentRuntimeState>) {
  const previous = runtimeStates.get(configId) ?? {
    configId,
    status: "stopped",
    message: "Chưa kết nối",
    connectedAt: null,
    lastMessageAt: null,
  };
  runtimeStates.set(configId, { ...previous, ...state, configId });
}

function dedupKey(configId: number, result: ParsedInstrumentResult) {
  const identity = [configId, result.instrumentCode, result.value, result.sampleId || "", result.measuredAt?.toISOString() || ""].join("|");
  return crypto.createHash("sha256").update(identity).digest("hex");
}

async function importResult(config: InstrumentConfig, result: ParsedInstrumentResult, rawText: string) {
  const mappings = await listInstrumentMappings(config.id);
  const mapping = mappings.find((item) => item.mapping.enabled === 1 && item.mapping.instrumentCode.toUpperCase() === result.instrumentCode.toUpperCase());
  const key = dedupKey(config.id, result);
  const existing = await findInstrumentLogByDedupKey(key);
  if (existing) {
    await createInstrumentLog({ configId: config.id, direction: "inbound", rawText, protocol: config.protocol, messageId: result.messageId, receivedAt: new Date(), parseStatus: "duplicate", dedupKey: key, resultId: existing.resultId ?? null, errorMessage: "Bỏ qua kết quả trùng." });
    return { status: "duplicate" as const };
  }

  if (!mapping) {
    await createInstrumentLog({ configId: config.id, direction: "inbound", rawText, protocol: config.protocol, messageId: result.messageId, receivedAt: new Date(), parseStatus: "unmapped", dedupKey: key, resultId: null, errorMessage: `Chưa mapping mã máy ${result.instrumentCode}.` });
    return { status: "unmapped" as const };
  }

  const material = await getControlMaterialById(mapping.mapping.controlMaterialId);
  if (!material || material.test.id !== mapping.mapping.testId) {
    await createInstrumentLog({ configId: config.id, direction: "inbound", rawText, protocol: config.protocol, messageId: result.messageId, receivedAt: new Date(), parseStatus: "error", dedupKey: key, resultId: null, errorMessage: "Mapping đang trỏ tới vật liệu hoặc xét nghiệm không hợp lệ." });
    return { status: "error" as const };
  }

  const history = await listIqcResults({ controlMaterialId: mapping.mapping.controlMaterialId });
  const previousScores = history
    .map((item) => item.result.zScore)
    .filter((score): score is number => score !== null && score !== undefined);
  const score = zScore(result.value, material.material.targetMean, material.material.targetSd);
  const violations = score === null ? [] : calculateWestgardViolations([...previousScores, score]);
  const created = await createIqcResult({
    testId: mapping.mapping.testId,
    controlMaterialId: mapping.mapping.controlMaterialId,
    value: result.value,
    recordedAt: result.measuredAt ?? new Date(),
    zScore: score,
    violations: JSON.stringify(violations),
    status: classifyStatus(violations),
    note: `Tự động nhận từ ${config.name}`,
    technician: "Interface máy xét nghiệm",
  });
  const resultId = created?.result.id ?? null;
  await createInstrumentLog({ configId: config.id, direction: "inbound", rawText, protocol: config.protocol, messageId: result.messageId, receivedAt: new Date(), parseStatus: "imported", dedupKey: key, resultId, errorMessage: null });
  return { status: "imported" as const, resultId };
}

async function processRaw(config: InstrumentConfig, raw: string) {
  const parsedFrames = parseInstrumentMessage(raw, {
    protocol: config.protocol,
    delimiter: config.delimiter,
    codeFieldIndex: config.codeFieldIndex,
    valueFieldIndex: config.valueFieldIndex,
  });
  let imported = 0;
  let duplicates = 0;
  let unmapped = 0;
  let errors = 0;
  for (const frame of parsedFrames) {
    for (const result of frame.results) {
      const outcome = await importResult(config, result, raw);
      if (outcome.status === "imported") imported += 1;
      else if (outcome.status === "duplicate") duplicates += 1;
      else if (outcome.status === "unmapped") unmapped += 1;
      else errors += 1;
    }
  }
  setState(config.id, { lastMessageAt: new Date(), message: `Đã nhận ${imported} kết quả, trùng ${duplicates}, chưa mapping ${unmapped}, lỗi ${errors}.` });
}

async function openTcp(config: InstrumentConfig): Promise<ActiveConnection> {
  if (!config.host || !config.port) throw new Error("Thiếu địa chỉ IP hoặc cổng TCP.");
  const socket = new net.Socket();
  let buffer = "";
  const active: ActiveConnection = { config, buffer, close: async () => new Promise((resolve) => { socket.once("close", () => resolve()); socket.destroy(); }) };
  activeConnections.set(config.id, active);
  await new Promise<void>((resolve, reject) => {
    const onError = (error: Error) => { socket.removeListener("connect", onConnect); reject(error); };
    const onConnect = () => { socket.removeListener("error", onError); resolve(); };
    socket.once("error", onError);
    socket.once("connect", onConnect);
    socket.connect(config.port!, config.host!);
  });
  socket.on("data", (chunk) => {
    buffer += chunk.toString("utf8");
    active.buffer = buffer;
    const delimiter = config.protocol === "delimited" ? config.delimiter.replace("\\n", "\n").replace("\\r", "\r") : "\u001c";
    if (buffer.includes(delimiter) || config.protocol !== "delimited") {
      const raw = buffer;
      buffer = "";
      void processRaw(config, raw).catch((error) => setState(config.id, { status: "error", message: error instanceof Error ? error.message : "Không thể xử lý dữ liệu." }));
    }
  });
  socket.on("close", () => {
    activeConnections.delete(config.id);
    if (runtimeStates.get(config.id)?.status !== "error") setState(config.id, { status: "stopped", message: "Kết nối đã đóng." });
  });
  socket.on("error", (error) => setState(config.id, { status: "error", message: error.message }));
  return active;
}

async function openSerial(config: InstrumentConfig): Promise<ActiveConnection> {
  if (!config.serialPort || !config.baudRate) throw new Error("Thiếu cổng COM hoặc Baud Rate.");
  const serialport = await import("serialport");
  const port = new serialport.SerialPort({
    path: config.serialPort,
    baudRate: config.baudRate,
    dataBits: config.dataBits as 5 | 6 | 7 | 8,
    stopBits: config.stopBits as 1 | 2,
    parity: config.parity,
    autoOpen: false,
  });
  let buffer = "";
  const active: ActiveConnection = { config, buffer, close: async () => new Promise((resolve) => { if (!port.isOpen) return resolve(); port.close(() => resolve()); }) };
  activeConnections.set(config.id, active);
  await new Promise<void>((resolve, reject) => port.open((error) => error ? reject(error) : resolve()));
  port.on("data", (chunk: Buffer) => {
    buffer += chunk.toString("utf8");
    active.buffer = buffer;
    const delimiter = config.protocol === "delimited" ? config.delimiter.replace("\\n", "\n").replace("\\r", "\r") : "\u001c";
    if (buffer.includes(delimiter) || config.protocol !== "delimited") {
      const raw = buffer;
      buffer = "";
      void processRaw(config, raw).catch((error) => setState(config.id, { status: "error", message: error instanceof Error ? error.message : "Không thể xử lý dữ liệu." }));
    }
  });
  port.on("close", () => {
    activeConnections.delete(config.id);
    if (runtimeStates.get(config.id)?.status !== "error") setState(config.id, { status: "stopped", message: "Cổng COM đã đóng." });
  });
  port.on("error", (error) => setState(config.id, { status: "error", message: error.message }));
  return active;
}

export async function connectInstrument(configId: number) {
  const config = await getInstrumentConfigById(configId);
  if (!config) throw new Error("Không tìm thấy cấu hình interface.");
  if (activeConnections.has(configId)) return runtimeStates.get(configId);
  setState(configId, { status: "connecting", message: "Đang kết nối…", connectedAt: null });
  try {
    if (config.connectionType === "tcp") await openTcp(config);
    else await openSerial(config);
    setState(configId, { status: "connected", message: "Đã kết nối và sẵn sàng nhận dữ liệu.", connectedAt: new Date() });
  } catch (error) {
    activeConnections.delete(configId);
    setState(configId, { status: "error", message: error instanceof Error ? error.message : "Không thể kết nối." });
  }
  return runtimeStates.get(configId);
}

export async function disconnectInstrument(configId: number) {
  const active = activeConnections.get(configId);
  if (active) await active.close();
  activeConnections.delete(configId);
  setState(configId, { status: "stopped", message: "Đã ngắt kết nối.", connectedAt: null });
  return runtimeStates.get(configId);
}

export async function testInstrumentConnection(configId: number) {
  await disconnectInstrument(configId);
  const state = await connectInstrument(configId);
  await disconnectInstrument(configId);
  return state;
}

export function listRuntimeStates() {
  return Array.from(runtimeStates.values());
}

export async function startEnabledInstrumentConnections() {
  const configs = await listInstrumentConfigs(true);
  await Promise.all(configs.map((config) => connectInstrument(config.id)));
}

export async function stopAllInstrumentConnections() {
  await Promise.all(Array.from(activeConnections.keys()).map((configId) => disconnectInstrument(configId)));
}

// Exported for focused parser/runtime tests without opening a real hardware port.
export async function ingestInstrumentPayload(configId: number, raw: string) {
  const config = await getInstrumentConfigById(configId);
  if (!config) throw new Error("Không tìm thấy cấu hình interface.");
  await processRaw(config, raw);
}
