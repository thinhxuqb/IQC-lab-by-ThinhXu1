import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import {
  createControlMaterial,
  createIqcResult,
  createTest,
  exportFullDatabaseBackup,
  importFullDatabaseBackup,
  listControlMaterials,
  listIqcResults,
  listTests,
} from "./db";

function managerContext(): TrpcContext {
  const now = new Date();
  return {
    user: {
      id: 1,
      openId: "offline-test-manager",
      name: "Offline test manager",
      email: null,
      loginMethod: "offline-license",
      role: "manager",
      createdAt: now,
      updatedAt: now,
      lastSignedIn: now,
    },
    req: { protocol: "http", headers: {}, ip: "127.0.0.1" } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

let dataDir = "";
let originalDataDir: string | undefined;
let originalDatabaseUrl: string | undefined;

beforeEach(() => {
  originalDataDir = process.env.IQC_DATA_DIR;
  originalDatabaseUrl = process.env.DATABASE_URL;
  delete process.env.DATABASE_URL;
  dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "iqc-offline-backup-"));
  process.env.IQC_DATA_DIR = dataDir;
});

afterEach(() => {
  if (originalDataDir === undefined) delete process.env.IQC_DATA_DIR;
  else process.env.IQC_DATA_DIR = originalDataDir;
  if (originalDatabaseUrl === undefined) delete process.env.DATABASE_URL;
  else process.env.DATABASE_URL = originalDatabaseUrl;
  fs.rmSync(dataDir, { recursive: true, force: true });
});

describe("IQC Backup and Restore .iqc-backup", () => {
  it("should export full database backup structure correctly", async () => {
    const backup = await exportFullDatabaseBackup();
    expect(backup.app).toBe("iqc-lab-manager");
    expect(backup.version).toBeDefined();
    expect(backup.exportedAt).toBeDefined();
    expect(Array.isArray(backup.data.tests)).toBe(true);
    expect(Array.isArray(backup.data.controlMaterials)).toBe(true);
    expect(Array.isArray(backup.data.iqcResults)).toBe(true);
    expect(Array.isArray(backup.data.auditLogs)).toBe(true);
  });

  it("should save a test through the tRPC procedure without a database", async () => {
    const caller = appRouter.createCaller(managerContext());
    const created = await caller.tests.create({ code: "TST-TRPC", name: "Test via tRPC", unit: "mg/dL" });
    expect(created?.code).toBe("TST-TRPC");
    expect((await listTests()).some((item) => item.code === "TST-TRPC")).toBe(true);
  });

  it("should persist offline tests, materials and results and restore them", async () => {
    const test = await createTest({
      code: "GLU-OFFLINE",
      name: "Glucose offline",
      unit: "mmol/L",
      category: "Sinh hóa",
      description: "Kiểm thử lưu cục bộ",
    });
    const material = await createControlMaterial({
      name: "QC Level 1",
      lotNumber: "LOT-OFFLINE",
      testId: test.id,
      level: "Level 1",
      targetMean: 5.5,
      targetSd: 0.2,
      expirationDate: new Date("2027-12-31"),
      isActive: 1,
    });
    await createIqcResult({
      testId: test.id,
      controlMaterialId: material.material.id,
      value: 5.6,
      recordedAt: new Date("2026-09-13T08:00:00.000Z"),
      zScore: 0.5,
      violations: "[]",
      status: "Accepted",
      note: "Nhận từ giao diện",
      technician: "Kỹ thuật viên",
    });

    const backup = await exportFullDatabaseBackup();
    expect(backup.data.tests).toHaveLength(1);
    expect(backup.data.controlMaterials).toHaveLength(1);
    expect(backup.data.iqcResults).toHaveLength(1);

    await importFullDatabaseBackup({ data: { tests: [], controlMaterials: [], iqcResults: [], auditLogs: [] } });
    expect(await listTests()).toHaveLength(0);
    expect(await listControlMaterials()).toHaveLength(0);
    expect(await listIqcResults()).toHaveLength(0);

    const result = await importFullDatabaseBackup(backup);
    expect(result.success).toBe(true);
    expect(await listTests()).toHaveLength(1);
    expect(await listControlMaterials()).toHaveLength(1);
    expect(await listIqcResults()).toHaveLength(1);
  });
});
