import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type Role = "user" | "technician" | "manager" | "admin";

function createContext(role: Role): TrpcContext {
  return {
    user: {
      id: 10,
      openId: `rbac-${role}`,
      email: `${role}@example.com`,
      name: `${role} user`,
      loginMethod: "test",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {}, ip: "127.0.0.1" } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("role-based access control", () => {
  it("allows a technician to submit a QC result but blocks deletion", async () => {
    const caller = appRouter.createCaller(createContext("technician"));
    await expect(caller.results.delete({ id: 1 })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("blocks technicians from changing master data and viewing the audit trail", async () => {
    const caller = appRouter.createCaller(createContext("technician"));
    await expect(caller.tests.create({ code: "GLU", name: "Glucose", unit: "mmol/L" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.audit.list({ limit: 10 })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("allows manager-level procedures to pass the role guard before reaching data access", async () => {
    const caller = appRouter.createCaller(createContext("manager"));
    await expect(caller.users.list()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
